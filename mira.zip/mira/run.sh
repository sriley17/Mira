#!/usr/bin/env bash
# MIRA — Medical Intelligent Rehabilitation Assistant — запуск на macOS / Linux
set -e
cd "$(dirname "$0")"
# останавливаем старые копии на портах 8000/8501, чтобы не работала старая версия
for port in 8000 8501; do
  pids=$(lsof -ti tcp:$port 2>/dev/null || true)
  [ -n "$pids" ] && kill $pids 2>/dev/null || true
done
python3 -m pip install -r backend/requirements.txt -r frontend/requirements.txt
(cd backend && python3 -m uvicorn app.main:app --port 8000) &
sleep 6
(cd frontend && python3 -m streamlit run app.py)
