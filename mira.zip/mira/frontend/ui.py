"""
ui.py — ОБЩИЕ ЭЛЕМЕНТЫ ИНТЕРФЕЙСА
================================
Стили (CSS), переключение темы, сохранение сессии в cookie, карточки показателей, графики,
браузерные уведомления, форматирование времени.

Безопасность: всё, что пришло от пользователя (имена, email, тексты) и выводится через
unsafe_allow_html, пропускается через esc() — иначе можно было бы внедрить свой HTML/JS (XSS).
"""
import html
import json
import secrets

import plotly.graph_objects as go
import streamlit as st
import streamlit.components.v1 as components

COOKIE = "mira_sid"
CRIT, WARN = "#B4534B", "#B7862F"   # приглушённые красный и янтарный — без ярких цветов


def esc(text) -> str:
    """Экранирование HTML: <script> превращается в безопасный текст &lt;script&gt;."""
    return html.escape(str(text if text is not None else ""))


# ---------- server-side session store (survives page reload / theme switch) ----------
@st.cache_resource
def _sessions() -> dict:
    return {}


def save_session():
    sid = st.session_state.get("_sid") or secrets.token_urlsafe(24)
    st.session_state["_sid"] = sid
    _sessions()[sid] = {k: st.session_state.get(k) for k in ("token", "user", "lang", "page", "patient_id")}
    return sid


def restore_session() -> None:
    if st.session_state.get("token"):
        return
    sid = st.context.cookies.get(COOKIE)
    data = _sessions().get(sid) if sid else None
    if data and data.get("token"):
        st.session_state.update({k: v for k, v in data.items() if v is not None})
        st.session_state["_sid"] = sid
    lang = st.context.cookies.get("mira_lang")
    if lang in ("ru", "uz", "en") and "lang" not in st.session_state:
        st.session_state["lang"] = lang


def ensure_device_id() -> str:
    """Постоянный случайный id этого браузера (cookie на 10 лет). Сервер хранит только его SHA-256
    и по нему применяет правило «один аккаунт — одно устройство»."""
    dev = st.session_state.get("_device_id") or st.context.cookies.get("mira_dev")
    if not dev:
        dev = secrets.token_urlsafe(24)
        set_cookie("mira_dev", dev, days=3650)
    st.session_state["_device_id"] = dev
    return dev


def drop_session():
    sid = st.session_state.get("_sid")
    _sessions().pop(sid, None)
    run_js(f"document.cookie='{COOKIE}=; path=/; max-age=0';")


def run_js(code: str) -> None:
    """Execute JS in a same-origin, zero-height component (can reach the parent page)."""
    components.html(f"<script>{code}</script>", height=0)


def set_cookie(name: str, value: str, days: int = 7) -> None:
    run_js(f"document.cookie='{name}={value}; path=/; max-age={days * 86400}; SameSite=Strict';")


# ---------- theme ----------
def is_dark() -> bool:
    try:
        return st.context.theme.type == "dark"
    except Exception:
        return False


def switch_theme() -> None:
    target = "Light" if is_dark() else "Dark"
    if st.session_state.get("token"):
        set_cookie(COOKIE, save_session())
    run_js(
        "const k='stActiveTheme-'+window.parent.location.pathname+'-v2';"
        f"window.parent.localStorage.setItem(k, JSON.stringify('{target}'));"
        "setTimeout(()=>window.parent.location.reload(), 150);"
    )


PALETTE = {
    "light": {"accent": "#2A7D6B", "accent_soft": "rgba(42,125,107,.09)", "card": "#ffffff", "border": "#E3E7E5",
              "muted": "#66736F", "text": "#1C2321", "hero": "#EEF3F1"},
    "dark": {"accent": "#5FB3A1", "accent_soft": "rgba(95,179,161,.12)", "card": "#172020", "border": "#28332F",
             "muted": "#98A6A1", "text": "#E3E8E6", "hero": "#141C1B"},
}


def pal() -> dict:
    return PALETTE["dark" if is_dark() else "light"]



EXTRA_CSS = """
<style>
  /* ---------- крупнее шрифт и больше воздуха (ТЗ: «трудно читать, всё вместе») ---------- */
  html {font-size: 17.5px;}
  .block-container {max-width: 1500px; padding-top: 1.6rem; padding-left: 2.2rem; padding-right: 2.2rem;}
  /* ---------- ничего не «наезжает»: длинные надписи переносятся, а не перекрывают соседей ---------- */
  .stButton button p, .stDownloadButton button p, [data-testid="stPopover"] button p,
  [data-testid="stBaseButton-segmented_control"] p, [data-testid="stBaseButton-segmented_controlActive"] p {
      white-space: normal !important; line-height: 1.25; overflow-wrap: anywhere;}
  [data-testid="stMarkdownContainer"], .mb-card, .mb-notif {overflow-wrap: anywhere;}
  .mb-card .hd {flex-wrap: wrap; row-gap: 4px;}
  .mb-card .lb {white-space: normal !important;}
  .mb-kv {gap: 1rem; align-items: baseline;}
  .mb-kv span {flex: 0 1 45%;} .mb-kv b {flex: 1 1 55%; text-align: right; overflow-wrap: anywhere;}
  .mb-hello h2 {font-size: 1.9rem !important; line-height: 1.25;} .mb-hello {margin: .2rem 0 .4rem;}
  .mb-stats {flex-wrap: wrap; row-gap: .4rem;}
  /* вкладки (segmented control) переносятся на новую строку, а не обрезаются */
  [data-testid="stButtonGroup"] [role="radiogroup"], [data-testid="stButtonGroup"] > div {flex-wrap: wrap !important;}
  .block-container {padding-bottom: 7rem !important;}   /* место под круглой кнопкой ИИ */
  [data-testid="stVerticalBlock"] {gap: 1.15rem;}
  [data-testid="stMarkdownContainer"] p, [data-testid="stMarkdownContainer"] li {line-height: 1.65;}
  h1 {font-size: 2.1rem !important;} h2 {font-size: 1.7rem !important;} h3 {font-size: 1.35rem !important;}
  .stButton button, .stDownloadButton button, .stLinkButton a {min-height: 2.9rem; font-size: 1rem;}
  [data-testid="stCaptionContainer"] {font-size: .92rem;}
  section[data-testid="stSidebar"] .stButton button {min-height: 2.6rem; font-size: 1rem;}
  section[data-testid="stSidebar"] .stButton {margin-bottom: -.35rem;}

  /* ---------- анимации ---------- */
  @keyframes mbFadeUp {from {opacity: 0; transform: translateY(14px);} to {opacity: 1; transform: none;}}
  @keyframes mbFade {from {opacity: 0;} to {opacity: 1;}}
  @keyframes mbDraw {from {stroke-dashoffset: 420;} to {stroke-dashoffset: 0;}}
  @keyframes mbFloat {0%, 100% {transform: translateY(0);} 50% {transform: translateY(-10px);}}
  @keyframes mbPulse {0% {box-shadow: 0 0 0 0 ACCENT_SOFT_STRONG;} 70% {box-shadow: 0 0 0 16px rgba(0,0,0,0);}
                      100% {box-shadow: 0 0 0 0 rgba(0,0,0,0);}}
  .mb-card, .mb-pending, .mb-rolecard {animation: mbFadeUp .45s ease both;}
  [data-testid="stVerticalBlockBorderWrapper"] {animation: mbFade .4s ease both;}
  .mb-hero, .mb-feat, .mb-fact, .mb-step, .mb-role, .mb-why, .mb-shot, .mb-uniq {animation: mbFadeUp .7s ease both;}
  .mb-feat:nth-child(2), .mb-step:nth-child(2), .mb-uniq:nth-child(2), .mb-shot:nth-child(2) {animation-delay: .08s;}
  .mb-feat:nth-child(3), .mb-step:nth-child(3), .mb-uniq:nth-child(3), .mb-shot:nth-child(3) {animation-delay: .16s;}
  .mb-feat:nth-child(4), .mb-step:nth-child(4), .mb-uniq:nth-child(4), .mb-shot:nth-child(4) {animation-delay: .24s;}
  .mb-uniq:nth-child(5) {animation-delay: .32s;} .mb-uniq:nth-child(6) {animation-delay: .4s;}
  .mb-hero svg .pulse {stroke-dasharray: 420; animation: mbDraw 2.2s ease-in-out infinite alternate;}
  .mb-hero svg .device {animation: mbFloat 5s ease-in-out infinite;}
  .mb-feat, .mb-step, .mb-role, .mb-uniq, .mb-shot {transition: transform .25s ease, box-shadow .25s ease;}
  .mb-feat:hover, .mb-step:hover, .mb-role:hover, .mb-uniq:hover, .mb-shot:hover {
      transform: translateY(-4px); box-shadow: 0 12px 28px rgba(20,40,35,.10);}
  @media (prefers-reduced-motion: reduce) {* {animation: none !important; transition: none !important;}}

  /* ---------- плавающая круглая кнопка ИИ (правый нижний угол) ---------- */
  .st-key-fab {position: fixed; right: 28px; bottom: 28px; z-index: 1000; width: auto !important;}
  .st-key-fab [data-testid="stPopover"] > div > button, .st-key-fab button {
      width: 66px; height: 66px; min-height: 66px; border-radius: 50%; padding: 0; background: ACCENT; color: #fff;
      border: none; font-weight: 800; font-size: 1.05rem; animation: mbPulse 2.6s ease-out infinite;
      box-shadow: 0 10px 24px rgba(20,40,35,.25);}
  .st-key-fab button svg, .st-key-fab button [data-testid="stIconMaterial"] {display: none;}   /* без стрелки */

  /* ---------- верхняя панель: колокольчик и имя ---------- */
  .st-key-topbar [data-testid="stPopover"] button {min-height: 2.9rem;}
  .mb-notif {padding: .7rem .2rem; border-bottom: 1px solid BORDER;}
  .mb-notif b {display: block; font-size: .95rem;} .mb-notif span {color: MUTED; font-size: .9rem;}
  .mb-notif small {color: MUTED; font-size: .78rem;}
  .mb-notif.unread b::before {content: ""; display: inline-block; width: 8px; height: 8px; border-radius: 50%;
      background: ACCENT; margin-right: 7px; vertical-align: middle;}
  .mb-count {display: inline-block; min-width: 1.4rem; padding: 0 .4rem; border-radius: 999px; background: ACCENT;
      color: #fff; font-size: .78rem; font-weight: 700; text-align: center; margin-left: .3rem;}
  @media (max-width: 768px) {
    html {font-size: 16.5px;}
    /* шапка лендинга и кабинета на телефоне: логотип во всю ширину, кнопки — в ряд */
    [data-testid="stHorizontalBlock"]:has(.mb-logo), .st-key-topbar [data-testid="stHorizontalBlock"] {
        flex-direction: row !important; flex-wrap: wrap !important; gap: .5rem !important;}
    [data-testid="stHorizontalBlock"]:has(.mb-logo) > [data-testid="stColumn"],
    .st-key-topbar [data-testid="stHorizontalBlock"] > [data-testid="stColumn"] {
        flex: 1 1 auto !important; width: auto !important; min-width: 0 !important;}
    [data-testid="stHorizontalBlock"]:has(.mb-logo) > [data-testid="stColumn"]:first-child,
    .st-key-topbar [data-testid="stHorizontalBlock"] > [data-testid="stColumn"]:first-child {flex: 1 1 100% !important;}
    .st-key-fab {right: 16px; bottom: 16px;}
  }
</style>
"""


def inject_css() -> None:
    p = pal()
    css = """
        <style>
          #MainMenu, footer, [data-testid="stStatusWidget"] {visibility: hidden;}
          .block-container {padding-top: 1.6rem; padding-bottom: 3rem; max-width: 1240px;}
          h1, h2, h3, h4 {letter-spacing: -0.01em;}
          .mb-brand {font-weight: 700; font-size: 1.35rem; line-height: 2.4rem; white-space: nowrap;}
          .mb-brand span {opacity: .55; font-weight: 500;}
          .mb-logo {display:flex; align-items:center; gap:.6rem; margin:-.5rem 0 1.2rem .25rem;}
          .mb-logo i {width:34px; height:34px; border-radius:10px; background:ACCENT; color:#fff; font-style:normal;
                      display:flex; align-items:center; justify-content:center; font-weight:800; font-size:1.05rem;}
          .mb-logo b {font-size:1.15rem; line-height:1.1;} .mb-logo small {display:block; color:MUTED; font-size:.72rem;}
          .mb-hello h2 {margin:0; padding:0; font-size:1.75rem; font-weight:700;}
          .mb-hello p {margin:.15rem 0 0; color:MUTED; font-size:.92rem;}
          .mb-badge {display:inline-block; padding:1px 9px; border-radius:999px; font-size:.72rem; font-weight:600;
                     white-space:nowrap;}
          .mb-ok {color:ACCENT; background:ACCENT_SOFT;} .mb-warn {color:#B7862F; background:rgba(183,134,47,.12);}
          .mb-crit {color:#B4534B; background:rgba(180,83,75,.12);} .mb-info {color:MUTED; background:rgba(120,130,125,.12);}
          .mb-muted {color:MUTED; font-size:.85rem;}
          .mb-dot {display:inline-block; width:8px; height:8px; border-radius:50%; margin-right:6px;}
          .mb-dot-on {background:ACCENT; box-shadow:0 0 0 3px ACCENT_SOFT;} .mb-dot-off {background:#B7862F;}
          .mb-alert {border:1px solid #B4534B; background:rgba(180,83,75,.06); border-radius:12px; padding:.7rem 1rem;
                     margin:.4rem 0 .8rem; color:#B4534B; font-weight:600;}
          /* welcome hero */
          .mb-hero {display:grid; grid-template-columns: 1.15fr .85fr; gap:2rem; align-items:center;
                    background:HERO; border:1px solid BORDER; border-radius:22px; padding:2.4rem 2.4rem 2rem; margin:.4rem 0 1.4rem;}
          .mb-hero h1 {font-size:2.35rem; line-height:1.15; margin:0 0 .8rem; font-weight:750; color:TEXT;}
          .mb-hero p.lead {color:MUTED; font-size:1.02rem; line-height:1.55; margin:0 0 1.3rem;}
          .mb-eyebrow {font-size:.75rem; letter-spacing:.14em; text-transform:uppercase; color:ACCENT; font-weight:700; margin-bottom:.7rem;}
          .mb-feats {display:grid; grid-template-columns:1fr 1fr; gap:.7rem;}
          .mb-feat {background:CARD; border:1px solid BORDER; border-radius:14px; padding:.75rem .9rem;}
          .mb-feat b {display:block; font-size:.9rem; color:TEXT;} .mb-feat span {font-size:.8rem; color:MUTED;}
          .mb-feat i {display:block; width:22px; height:3px; border-radius:2px; background:ACCENT; margin-bottom:.5rem;}
          .mb-hero svg {width:100%; height:auto; max-height:320px;}
          .mb-rolecard {background:CARD; border:1px solid BORDER; border-radius:16px; padding:1rem 1.1rem .4rem; margin-bottom:.5rem;}
          .mb-rolecard b {font-size:1.05rem;} .mb-rolecard p {color:MUTED; font-size:.85rem; margin:.25rem 0 .2rem;}
          .mb-pending {max-width:560px; margin:3rem auto; text-align:center; background:CARD; border:1px solid BORDER;
                       border-radius:20px; padding:2.2rem 2rem;}
          .mb-pending h2 {margin:.8rem 0 .5rem;} .mb-pending p {color:MUTED;}
          /* progress bar for goals and sleep */
          .mb-bar {height:8px; border-radius:6px; background:ACCENT_SOFT; overflow:hidden; margin:.35rem 0 .2rem;}
          .mb-bar div {height:100%; background:ACCENT; border-radius:6px;}
          .mb-kv {display:flex; justify-content:space-between; font-size:.88rem; padding:.28rem 0; border-bottom:1px dashed BORDER;}
          .mb-kv span {color:MUTED;}
          .mb-big {font-size:2.1rem; font-weight:750; line-height:1.1; color:TEXT;} .mb-big small {font-size:.9rem; color:MUTED; font-weight:500;}
          /* metric card */
          .mb-card {background:CARD; border:1px solid BORDER; border-radius:14px; padding:14px 16px 10px;
                    margin-bottom:.1rem; min-height:132px;}
          .mb-card .hd {display:flex; justify-content:space-between; align-items:center; gap:6px;}
          .mb-card .lb {font-size:.82rem; color:MUTED; font-weight:500; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;}
          .mb-card .val {font-size:1.7rem; font-weight:700; margin:4px 0 2px; line-height:1.2; color:TEXT;}
          .mb-card .val small {font-size:.78rem; font-weight:500; color:MUTED; margin-left:4px;}
          .mb-card svg {display:block; width:100%; height:34px;}
          .mb-stats {display:flex; gap:1.6rem; justify-content:flex-end;}
          .mb-stats div {display:flex; flex-direction:column; align-items:flex-end;}
          .mb-stats span {font-size:.72rem; color:MUTED;} .mb-stats b {font-size:1.05rem;}
          /* sidebar navigation */
          section[data-testid="stSidebar"] {border-right:1px solid BORDER;}
          section[data-testid="stSidebar"] .stButton button {justify-content:flex-start; border:none; box-shadow:none;
                     padding:.5rem .8rem; border-radius:10px; font-weight:500;}
          section[data-testid="stSidebar"] .stButton button[kind="primary"] {background:ACCENT_SOFT; color:ACCENT;}
          section[data-testid="stSidebar"] .stButton button[kind="tertiary"]:hover {background:ACCENT_SOFT;}
          section[data-testid="stSidebar"] .stButton {margin-bottom:-.55rem;}
          section[data-testid="stSidebar"] .stButton button > div {justify-content:flex-start; width:100%;}
          section[data-testid="stSidebar"] .stButton button p {text-align:left;}
          .st-key-detailbox {background:CARD; border-color:BORDER !important; border-radius:14px !important;}
          /* mobile: nav pills instead of sidebar */
          .st-key-mobnav {display:none;}
          @media (max-width: 768px) {
            .st-key-mobnav {display:block;}
            .block-container {padding-left: .8rem; padding-right: .8rem; padding-top: 3rem;}
            .mb-hello h2 {font-size:1.35rem;}
            .mb-card .val {font-size:1.35rem;} .mb-card {padding:12px 12px 8px; min-height:118px;}
            .mb-brand {font-size: 1.1rem;} .mb-brand span {display:none;}
            .mb-stats {justify-content:flex-start;}
            [data-testid="stHorizontalBlock"]:has(.mb-hello), [data-testid="stHorizontalBlock"]:has(.mb-brand) {
              flex-direction: row !important; flex-wrap: wrap !important; gap: .5rem !important;}
            [data-testid="stHorizontalBlock"]:has(.mb-hello) > [data-testid="stColumn"],
            [data-testid="stHorizontalBlock"]:has(.mb-brand) > [data-testid="stColumn"] {
              flex: 0 1 auto !important; width: auto !important; min-width: 0 !important;}
            [data-testid="stHorizontalBlock"]:has(.mb-hello) > [data-testid="stColumn"]:first-child,
            [data-testid="stHorizontalBlock"]:has(.mb-brand) > [data-testid="stColumn"]:first-child {flex: 1 1 100% !important;}
            /* cards: 2 per row on phones */
            [data-testid="stHorizontalBlock"]:has(.mb-card) {flex-direction: row !important; flex-wrap: wrap !important; gap: .6rem !important;}
            [data-testid="stHorizontalBlock"]:has(.mb-card) > [data-testid="stColumn"] {
              flex: 1 1 calc(50% - .6rem) !important; min-width: calc(50% - .6rem) !important; width: calc(50% - .6rem) !important;}
            .mb-card {margin-bottom:.6rem;}
            .mb-hero {grid-template-columns: 1fr; padding:1.4rem 1.2rem; gap:1rem;}
            .mb-hero h1 {font-size:1.6rem;} .mb-hero svg {max-height:180px;}
            .mb-feats {grid-template-columns: 1fr 1fr;}
          }
        </style>
    """
    css += EXTRA_CSS.replace("ACCENT_SOFT_STRONG", p["accent_soft"].replace(".09", ".35").replace(".12", ".35"))
    for k, v in (("HERO", p["hero"]), ("ACCENT_SOFT", p["accent_soft"]), ("ACCENT", p["accent"]), ("CARD", p["card"]),
                 ("BORDER", p["border"]), ("MUTED", p["muted"]), ("TEXT", p["text"])):
        css = css.replace(k, v)
    st.markdown(css, unsafe_allow_html=True)


def sparkline_svg(values, color: str) -> str:
    vals = [float(v) for v in values if v is not None and v == v][-60:]
    if len(vals) < 2:
        return '<svg viewBox="0 0 100 34"></svg>'
    lo, hi = min(vals), max(vals)
    span = (hi - lo) or 1
    n = len(vals) - 1
    pts = [(i / n * 100, 30 - (v - lo) / span * 26) for i, v in enumerate(vals)]
    line = " ".join(f"{x:.1f},{y:.1f}" for x, y in pts)
    area = f"0,34 {line} 100,34"
    return (f'<svg viewBox="0 0 100 34" preserveAspectRatio="none">'
            f'<polygon points="{area}" fill="{color}" opacity=".08"/>'
            f'<polyline points="{line}" fill="none" stroke="{color}" stroke-width="1.6" '
            f'vector-effect="non-scaling-stroke" stroke-linejoin="round" stroke-linecap="round"/></svg>')


def patient_level(lvl: str | None) -> str | None:
    """Пациенту не показываем «Критично» (ТЗ: не пугать) — только спокойное «Вне нормы».
    Врач видит настоящий уровень."""
    if lvl == "critical" and st.session_state.get("user", {}).get("role") == "patient":
        return "warning"
    return lvl


def level_text(lvl: str) -> str:
    from i18n import t
    if lvl == "warning" and st.session_state.get("user", {}).get("role") == "patient":
        return t("out_of_range")
    return t(lvl)


def card_html(label: str, value: str, unit_: str, lvl: str | None, series) -> str:
    lvl = patient_level(lvl)
    color = {"critical": CRIT, "warning": WARN}.get(lvl or "", pal()["accent"])
    b = badge(lvl, level_text(lvl)) if lvl else ""
    return (f'<div class="mb-card"><div class="hd"><span class="lb">{label}</span>{b}</div>'
            f'<div class="val">{value}<small>{unit_}</small></div>{sparkline_svg(list(series), color)}</div>')


# ---------- charts ----------
def accent() -> str:
    return pal()["accent"]


def style_fig(fig: go.Figure, height: int = 260, title: str | None = None) -> go.Figure:
    dark = is_dark()
    grid = "rgba(255,255,255,0.08)" if dark else "rgba(0,0,0,0.07)"
    fig.update_layout(
        template="plotly_dark" if dark else "plotly_white",
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        height=height, margin=dict(l=8, r=8, t=36 if title else 8, b=8),
        title=dict(text=title, font=dict(size=14), x=0, xanchor="left") if title else None,
        showlegend=False, hovermode="x unified",
        font=dict(family="sans-serif", size=12),
    )
    fig.update_xaxes(showgrid=False, zeroline=False)
    fig.update_yaxes(gridcolor=grid, zeroline=False)
    return fig


def line_fig(x, y, title=None, height=240, band: tuple | None = None, color: str | None = None,
             y2=None) -> go.Figure:
    fig = go.Figure()
    if band:
        lo, hi = band
        fig.add_hrect(y0=lo, y1=hi, line_width=0, fillcolor=accent(), opacity=0.06)
    fig.add_trace(go.Scatter(x=x, y=y, mode="lines", line=dict(color=color or accent(), width=2)))
    if y2 is not None:
        fig.add_trace(go.Scatter(x=x, y=y2, mode="lines", line=dict(color=color or accent(), width=2, dash="dot")))
    return style_fig(fig, height, title)


def plot(fig: go.Figure, key: str | None = None):
    st.plotly_chart(fig, width="stretch", config={"displayModeBar": False}, key=key)


# ---------- notifications ----------
def browser_notify(title: str, body: str) -> None:
    run_js(
        "try{const N=window.parent.Notification||Notification;"
        f"if(N.permission==='granted'){{new N({json.dumps(title)},{{body:{json.dumps(body)}}});}}}}catch(e){{}}"
    )


def request_push_permission_button(label: str) -> None:
    components.html(
        f"""<button id="b" style="font:13px sans-serif;padding:6px 10px;border-radius:8px;width:100%;
        border:1px solid #9ca3af;background:transparent;color:#6b7280;cursor:pointer;min-height:44px;font-size:15px">{label}</button>
        <script>
        const b=document.getElementById('b');
        const N=window.parent.Notification||window.Notification;
        if(N && N.permission==='granted'){{b.textContent={json.dumps(label)}+' — OK';}}
        b.onclick=()=>N.requestPermission().then(p=>{{b.textContent={json.dumps(label)}+' — '+(p==='granted'?'OK':p);}});
        </script>""",
        height=60,
    )


def badge(level: str, text: str) -> str:
    cls = {"critical": "mb-crit", "warning": "mb-warn", "info": "mb-info"}.get(level, "mb-ok")
    return f'<span class="mb-badge {cls}">{esc(text)}</span>'


# ---------- time ----------
def to_local(series):
    """UTC naive timestamps from API -> browser's local time (naive, for display)."""
    import pandas as pd
    s = pd.to_datetime(series, format="ISO8601")
    tz = st.context.timezone or "UTC"
    try:
        return s.dt.tz_localize("UTC").dt.tz_convert(tz).dt.tz_localize(None)
    except Exception:
        return s


def fmt_local(ts: str, fmt: str = "%d.%m %H:%M:%S") -> str:
    import pandas as pd
    return to_local(pd.Series([ts])).iloc[0].strftime(fmt)


def progress_bar(pct: float) -> str:
    """Тонкая полоска прогресса (HTML) — спокойнее стандартного st.progress."""
    pct = max(0.0, min(100.0, float(pct or 0)))
    return f'<div class="mb-bar"><div style="width:{pct:.0f}%"></div></div>'


def kv(label: str, value) -> str:
    """Строка «подпись — значение» для компактных таблиц в карточках."""
    return f'<div class="mb-kv"><span>{esc(label)}</span><b>{esc(value)}</b></div>'
