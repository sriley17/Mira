"""
api.py — КЛИЕНТ ДЛЯ BACKEND (HTTP + WebSocket)
=============================================
Все запросы фронтенда к FastAPI идут через функции get/post/put/delete этого модуля:
  • один общий пул соединений (быстро: нет нового TCP-подключения на каждый запрос);
  • токен JWT автоматически добавляется в заголовок Authorization;
  • ошибки сервера превращаются в ApiError с понятным текстом;
  • 401 (токен истёк или отозван) -> сессия очищается, пользователь попадает на экран входа.

LiveStream — фоновый поток, который держит WebSocket открытым и складывает входящие
события (измерения, состояние устройства, напоминания, тревоги для врача) в буферы.
"""
import json
import os
import threading
import time
from collections import deque

import httpx
import streamlit as st
from websockets.sync.client import connect

API_URL = os.getenv("MIRA_API_URL", "http://127.0.0.1:8000").rstrip("/")
WS_URL = API_URL.replace("https://", "wss://").replace("http://", "ws://")


class ApiError(Exception):
    def __init__(self, status: int, detail: str):
        super().__init__(detail)
        self.status, self.detail = status, detail


@st.cache_resource
def _client() -> httpx.Client:
    """One shared keep-alive connection pool instead of a new TCP connection per request."""
    return httpx.Client(timeout=30, limits=httpx.Limits(max_connections=50, max_keepalive_connections=20))


def _headers() -> dict:
    """Токен + id устройства. X-Device-Id нужен серверу для правила «один аккаунт — одно устройство»."""
    h = {"X-Device-Id": st.session_state.get("_device_id", "")}
    # Запросы к API делает сервер Streamlit, поэтому передаём браузер и IP пользователя явно:
    # из них сервер строит понятное имя устройства («Chrome · Windows») и пишет IP в журнал аудита.
    try:
        h["X-Device-Label"] = (st.context.headers.get("User-Agent") or "")[:300]
        if st.context.ip_address:
            h["X-Forwarded-For"] = st.context.ip_address
    except Exception:  # noqa: BLE001 — вне контекста запроса (фоновый поток)
        pass
    tok = st.session_state.get("token")
    if tok:
        h["Authorization"] = f"Bearer {tok}"
    return h


def _handle(r: httpx.Response):
    if r.status_code == 401 and st.session_state.get("token"):
        # токен истёк, отозван (выход) или устройство отключено -> на экран входа
        keep = {k: st.session_state.get(k) for k in ("lang", "_device_id")}
        st.session_state.clear()
        st.session_state.update({k: v for k, v in keep.items() if v})
        st.rerun()
    if r.status_code == 403 and st.session_state.get("token") and "device_pending" in r.text \
            and st.session_state["user"].get("device_status") != "pending":
        # устройство ещё не подтверждено -> app.py покажет «ограниченный» кабинет
        st.session_state["user"]["device_status"] = "pending"
        st.rerun()
    if r.status_code == 403 and st.session_state.get("token") and "identity_required" in r.text:
        # личность не подтверждена -> app.py покажет экран проверки MyID
        st.session_state["user"]["identity_status"] = "none"
        st.rerun()
    if not r.is_success:
        try:
            detail = r.json().get("detail")
            if isinstance(detail, list):
                detail = "; ".join(d.get("msg", "") for d in detail)
        except Exception:
            detail = r.text
        raise ApiError(r.status_code, str(detail))
    ctype = r.headers.get("content-type", "")
    return r.json() if ctype.startswith("application/json") else r.content


def get(path: str, **params):
    params = {k: v for k, v in params.items() if v is not None}
    return _handle(_client().get(API_URL + path, params=params, headers=_headers()))


def post(path: str, json_body: dict | None = None, data: dict | None = None):
    return _handle(_client().post(API_URL + path, json=json_body, data=data, headers=_headers(), timeout=60))


def upload(path: str, filename: str, content: bytes, mime: str):
    """Загрузка файла (multipart/form-data) — для фото профиля."""
    return _handle(_client().post(API_URL + path, files={"file": (filename, content, mime)}, headers=_headers(),
                                  timeout=60))


def put(path: str, json_body: dict | None = None):
    return _handle(_client().put(API_URL + path, json=json_body, headers=_headers()))


def delete(path: str):
    return _handle(_client().delete(API_URL + path, headers=_headers()))


def is_up() -> bool:
    try:
        return _client().get(API_URL + "/api/health", timeout=3).is_success
    except httpx.HTTPError:
        return False


@st.cache_data(ttl=300, show_spinner=False)
def server_info() -> dict:
    """Версия backend и его настройки для интерфейса (например, обязателен ли ПИНФЛ). Кэш 5 минут."""
    try:
        return _client().get(API_URL + "/api/health", timeout=3).json()
    except Exception:  # noqa: BLE001
        return {}


@st.cache_data(ttl=15, show_spinner=False)
def patients(token: str) -> list:
    """Doctor's patient list, cached briefly (it is needed on every page for the selector)."""
    return get("/api/admin/patients")


def login(email: str, password: str, role: str) -> dict:
    return post("/api/auth/login", data={"username": email, "password": password, "scope": role})


def register(payload: dict) -> dict:
    return post("/api/auth/register", json_body=payload)


def logout_remote() -> None:
    """Отзыв токена на сервере (после этого он недействителен, даже если его кто-то скопировал)."""
    try:
        _client().post(API_URL + "/api/auth/logout", headers=_headers(), timeout=5)
    except httpx.HTTPError:
        pass


class LiveStream:
    """Background thread keeping a WebSocket open and buffering incoming messages."""

    def __init__(self, token: str, patient_id: int | None = None, maxlen: int = 300):
        q = f"?token={token}" + (f"&patient_id={patient_id}" if patient_id else "")
        self.url = f"{WS_URL}/ws/live{q}"
        self.measurements: deque = deque(maxlen=maxlen)
        self.alerts: deque = deque(maxlen=50)          # приходят только врачу
        self.reminders: deque = deque(maxlen=20)       # напоминания о лекарствах (пациенту)
        self.events: deque = deque(maxlen=20)          # прочее: одобрение, записи к врачу
        self.device: dict | None = None
        self.connected = False
        self.new_messages = 0
        self._stop = threading.Event()
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        while not self._stop.is_set():
            try:
                with connect(self.url, open_timeout=5) as ws:
                    self.connected = True
                    last_ping = time.time()
                    while not self._stop.is_set():
                        try:
                            raw = ws.recv(timeout=1)
                        except TimeoutError:
                            if time.time() - last_ping > 20:
                                ws.send("ping")
                                last_ping = time.time()
                            continue
                        msg = json.loads(raw)
                        kind = msg.get("type")
                        if kind == "measurement":
                            self.measurements.append({"patient_id": msg.get("patient_id"), **msg["data"]})
                        elif kind == "alert":
                            self.alerts.append({"patient_id": msg.get("patient_id"),
                                                "patient_name": msg.get("patient_name"), "seen": False,
                                                **msg["data"]})
                        elif kind == "device":
                            self.device = msg["data"]
                        elif kind == "message":
                            self.new_messages += 1
                        elif kind == "reminder":
                            self.reminders.append({"seen": False, **msg["data"]})
                        elif kind in ("status", "appointment"):
                            self.events.append({"type": kind, "seen": False, **msg.get("data", {})})
            except Exception:
                self.connected = False
                time.sleep(2)  # reconnect
        self.connected = False

    def stop(self):
        self._stop.set()


def stream(patient_id: int | None = None) -> LiveStream:
    """One stream per (session, channel), reused across reruns."""
    streams = st.session_state.setdefault("_streams", {})
    key = patient_id or "self"
    if key not in streams:
        streams[key] = LiveStream(st.session_state["token"], patient_id)
    return streams[key]


def stop_streams():
    for s in st.session_state.get("_streams", {}).values():
        s.stop()
    st.session_state["_streams"] = {}
