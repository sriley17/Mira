"""
i18n_extra.py — ПЕРЕВОДЫ ДЛЯ ВЕРСИИ 2.2 (RU, UZ, EN)
Подключаются в i18n.py: T.update(EXTRA). Вынесены отдельно, чтобы основной словарь не разрастался.
"""

EXTRA: dict[str, tuple[str, str, str]] = {
    # --- группы меню
    "g_health": ("Здоровье", "Salomatlik", "Health"),
    "g_treat": ("Лечение", "Davolash", "Treatment"),
    "g_device": ("Устройство и GPS", "Qurilma va GPS", "Device & GPS"),
    "g_account": ("Профиль и настройки", "Profil va sozlamalar", "Profile & settings"),
    "g_patients": ("Пациенты", "Bemorlar", "Patients"),
    "g_pmetrics": ("Показатели пациента", "Bemor ko'rsatkichlari", "Patient metrics"),
    "sub_signals": ("Сигналы", "Signallar", "Signals"),
    "sub_messages": ("Сообщения пациенту", "Bemorga xabarlar", "Messages to patient"),
    "api_old": ("Сервер MIRA запущен в старой версии. Закройте окно «MIRA API» и запустите run_windows.bat заново "
                "(или остановите старый процесс uvicorn на порту 8000).",
                "MIRA serverining eski versiyasi ishlayapti. «MIRA API» oynasini yoping va run_windows.bat ni qayta ishga "
                "tushiring (yoki 8000-portdagi eski uvicorn jarayonini to'xtating).",
                "An old version of the MIRA server is running. Close the “MIRA API” window and start run_windows.bat "
                "again (or stop the old uvicorn process on port 8000)."),
    "api_error": ("Ошибка сервера", "Server xatosi", "Server error"),
    "pinfl_req": ("ПИНФЛ (14 цифр)", "JShShIR (14 raqam)", "PINFL (14 digits)"),
    "pinfl_bad": ("ПИНФЛ — ровно 14 цифр", "JShShIR — aynan 14 ta raqam", "PINFL must be exactly 14 digits"),
    # --- меню
    "m_inbox": ("Уведомления", "Bildirishnomalar", "Notifications"),
    "m_inbox_doc": ("Сигналы и сообщения", "Signallar va xabarlar", "Signals and messages"),
    "m_mydoc": ("Мой врач", "Mening shifokorim", "My doctor"),
    "m_settings": ("Настройки", "Sozlamalar", "Settings"),
    "m_docs": ("Документы", "Hujjatlar", "Documents"),
    "m_support": ("Техподдержка", "Texnik yordam", "Support"),
    "m_chat": ("Чат с врачом", "Shifokor bilan chat", "Chat with doctor"),
    # --- плавающая кнопка
    "fab": ("ИИ", "AI", "AI"),
    "fab_title": ("Чем помочь?", "Qanday yordam kerak?", "How can we help?"),
    "fab_ai": ("Чат с ИИ-ассистентом", "AI-yordamchi bilan chat", "Chat with AI assistant"),
    "fab_ai_doc": ("ИИ-аналитик по пациенту", "Bemor bo'yicha AI-tahlilchi", "AI analyst for a patient"),
    "fab_doc": ("Чат с врачом", "Shifokor bilan chat", "Chat with doctor"),
    "fab_pat": ("Сообщения пациенту", "Bemorga xabarlar", "Messages to patient"),
    # --- верхняя панель
    "notifications": ("Уведомления", "Bildirishnomalar", "Notifications"),
    "no_notifications": ("Новых уведомлений нет", "Yangi bildirishnomalar yo'q", "No new notifications"),
    "mark_read": ("Отметить прочитанным", "O'qilgan deb belgilash", "Mark as read"),
    "open_all": ("Все уведомления", "Barcha bildirishnomalar", "All notifications"),
    "allow": ("Разрешить", "Ruxsat berish", "Allow"),
    "personal_info": ("Личные данные", "Shaxsiy ma'lumotlar", "Personal info"),
    "unread": ("новых", "yangi", "new"),
    # --- вход
    "or": ("или", "yoki", "or"),
    "oneid_btn": ("Войти через OneID", "OneID orqali kirish", "Sign in with OneID"),
    "oneid_off": ("Вход через OneID будет доступен после подключения клиники к OneID (ключи задаёт администратор).",
                  "OneID orqali kirish klinika OneID ga ulangandan so'ng ishlaydi (kalitlarni administrator kiritadi).",
                  "OneID sign-in becomes available once the clinic is connected to OneID (keys are set by the admin)."),
    "oneid_fail": ("Не удалось войти через OneID. Попробуйте ещё раз.", "OneID orqali kirib bo'lmadi. Qayta urinib ko'ring.",
                   "OneID sign-in failed. Please try again."),
    "device_pending": ("Это новое устройство. Для защиты аккаунта вход нужно подтвердить на устройстве, с которого вы "
                       "вошли впервые: откройте «Уведомления» и нажмите «Разрешить». Затем войдите снова.",
                       "Bu yangi qurilma. Akkauntni himoya qilish uchun kirishni birinchi kirgan qurilmangizda tasdiqlang: "
                       "«Bildirishnomalar»ni oching va «Ruxsat berish»ni bosing. So'ng qayta kiring.",
                       "This is a new device. To protect your account, confirm this sign-in on the device you used first: "
                       "open “Notifications” and press “Allow”. Then sign in again."),
    "device_revoked": ("Доступ с этого устройства отключён владельцем аккаунта.",
                       "Bu qurilmadan kirish akkaunt egasi tomonidan o'chirilgan.",
                       "Access from this device was revoked by the account owner."),
    # --- новое устройство: ограниченный режим
    "dev_limited_title": ("Новое устройство — нужно подтверждение", "Yangi qurilma — tasdiqlash kerak",
                          "New device — confirmation needed"),
    "dev_limited_text": ("Вы вошли с нового устройства. Для защиты ваших медицинских данных кабинет пока пустой. "
                         "Подтвердите устройство в разделе «Профиль» — после этого всё заработает полностью.",
                         "Siz yangi qurilmadan kirdingiz. Tibbiy ma'lumotlaringizni himoya qilish uchun kabinet hozircha bo'sh. "
                         "Qurilmani «Profil» bo'limida tasdiqlang — shundan so'ng hammasi to'liq ishlaydi.",
                         "You signed in from a new device. To protect your medical data the dashboard is empty for now. "
                         "Confirm this device in “Profile” — then everything will work fully."),
    "go_profile": ("Перейти в профиль", "Profilga o'tish", "Go to profile"),
    "dev_way1": ("Способ 1. Подтвердить лицом (MyID) прямо на этом устройстве",
                 "1-usul. Shu qurilmaning o'zida yuz orqali (MyID) tasdiqlash",
                 "Option 1. Confirm with your face (MyID) on this device"),
    "dev_way2": ("Способ 2. Разрешить с первого устройства: «Уведомления» или «Настройки → Мои устройства» → «Разрешить»",
                 "2-usul. Birinchi qurilmadan ruxsat berish: «Bildirishnomalar» yoki «Sozlamalar → Mening qurilmalarim» → «Ruxsat berish»",
                 "Option 2. Allow it from your first device: “Notifications” or “Settings → My devices” → “Allow”"),
    "dev_ok": ("Устройство подтверждено", "Qurilma tasdiqlandi", "Device confirmed"),
    "dev_check": ("Я разрешил(а) на другом устройстве — проверить", "Boshqa qurilmada ruxsat berdim — tekshirish",
                  "I allowed it on another device — check"),
    "dev_still": ("Устройство ещё не подтверждено", "Qurilma hali tasdiqlanmagan", "Device is not confirmed yet"),
    # --- согласие
    "consent_title": ("Согласие на обработку персональных данных", "Shaxsiy ma'lumotlarni qayta ishlashga rozilik",
                      "Consent to personal data processing"),
    "consent_text": (
        "Регистрируясь в MIRA, вы соглашаетесь, что:\n\n"
        "1. MIRA обрабатывает ваши персональные данные (ФИО, возраст, пол, email, телефон, ПИНФЛ, адрес, место работы, "
        "фото паспорта) и медицинские показатели с устройства (пульс, давление, сахар, дыхание, SpO₂, температура, сон, "
        "геолокация) для наблюдения лечащим врачом и реабилитации.\n"
        "2. Данные хранятся в зашифрованном виде на серверах клиники и доступны только вам и вашему лечащему врачу. "
        "Каждый просмотр ваших данных врачом записывается в журнал.\n"
        "3. Для вашей безопасности личность подтверждается по лицу (MyID), а вход разрешён с одного устройства.\n"
        "4. При критических показателях система автоматически передаёт ваши данные и координаты врачу и службе скорой помощи.\n"
        "5. ИИ-ассистент работает локально, ваши данные не передаются сторонним сервисам ИИ.\n"
        "6. Вы можете отозвать согласие и запросить удаление данных, обратившись в техподдержку клиники.\n\n"
        "Обработка ведётся в соответствии с Законом Республики Узбекистан «О персональных данных».",
        "MIRA da ro'yxatdan o'tib, siz quyidagilarga rozilik bildirasiz:\n\n"
        "1. MIRA shaxsiy ma'lumotlaringizni (F.I.Sh., yosh, jins, email, telefon, JShShIR, manzil, ish joyi, pasport "
        "surati) va qurilmadagi tibbiy ko'rsatkichlarni (puls, bosim, qand, nafas, SpO₂, harorat, uyqu, geolokatsiya) "
        "davolovchi shifokor kuzatuvi va reabilitatsiya uchun qayta ishlaydi.\n"
        "2. Ma'lumotlar klinika serverlarida shifrlangan holda saqlanadi va faqat sizga hamda davolovchi shifokoringizga "
        "ochiq. Shifokorning har bir ko'rishi jurnalga yoziladi.\n"
        "3. Xavfsizligingiz uchun shaxs yuz orqali (MyID) tasdiqlanadi, kirish esa bitta qurilmadan ruxsat etiladi.\n"
        "4. Kritik ko'rsatkichlarda tizim ma'lumotlaringiz va koordinatalaringizni shifokor va tez yordamga avtomatik yuboradi.\n"
        "5. AI-yordamchi mahalliy ishlaydi, ma'lumotlaringiz uchinchi tomon AI xizmatlariga berilmaydi.\n"
        "6. Klinikaning texnik yordamiga murojaat qilib, rozilikni qaytarib olishingiz va ma'lumotlarni o'chirishni so'rashingiz mumkin.\n\n"
        "Qayta ishlash O'zbekiston Respublikasining «Shaxsga doir ma'lumotlar to'g'risida»gi Qonuniga muvofiq amalga oshiriladi.",
        "By registering in MIRA you agree that:\n\n"
        "1. MIRA processes your personal data (name, age, gender, email, phone, PINFL, address, workplace, passport photo) "
        "and health readings from the device (pulse, blood pressure, glucose, breathing, SpO₂, temperature, sleep, location) "
        "for monitoring by your doctor and rehabilitation.\n"
        "2. Data is stored encrypted on the clinic's servers and is available only to you and your doctor. Every view of "
        "your data by a doctor is logged.\n"
        "3. For your safety, your identity is confirmed by face (MyID) and sign-in is allowed from one device.\n"
        "4. In critical situations the system automatically sends your data and location to your doctor and emergency services.\n"
        "5. The AI assistant runs locally; your data is not sent to third-party AI services.\n"
        "6. You can withdraw consent and request deletion of your data via the clinic's technical support.\n\n"
        "Processing follows the Law of the Republic of Uzbekistan “On Personal Data”."),
    "consent_check": ("Я прочитал(а) и согласен(на) на обработку моих персональных и медицинских данных",
                      "O'qib chiqdim va shaxsiy hamda tibbiy ma'lumotlarimni qayta ishlashga roziman",
                      "I have read and agree to the processing of my personal and medical data"),
    "consent_agree": ("Согласен, зарегистрироваться", "Roziman, ro'yxatdan o'tish", "I agree, create account"),
    "consent_need": ("Нужно отметить согласие", "Rozilikni belgilash kerak", "Please confirm your consent"),
    # --- проверка личности
    "id_title": ("Подтверждение личности (MyID)", "Shaxsni tasdiqlash (MyID)", "Identity check (MyID)"),
    "id_text": ("Перед первым доступом к медицинским данным нужно подтвердить, что это действительно вы. "
                "MyID сравнит ваше лицо с фотографией из паспорта. Это защищает ваши данные, если кто-то узнает пароль.",
                "Tibbiy ma'lumotlarga birinchi kirishdan oldin bu haqiqatan siz ekaningizni tasdiqlash kerak. "
                "MyID yuzingizni pasportdagi surat bilan solishtiradi. Bu parolingizni kimdir bilib olsa ham ma'lumotlarni himoya qiladi.",
                "Before your first access to medical data, please confirm it is really you. MyID compares your face with "
                "your passport photo. This protects your data even if someone learns your password."),
    "id_cam_title": ("Разрешите доступ к камере", "Kameraga ruxsat bering", "Allow camera access"),
    "id_cam_text": ("Камера нужна только для одного снимка лица. Снимок передаётся в MyID в зашифрованном виде и "
                    "не используется ни для чего другого. Сейчас браузер спросит разрешение — нажмите «Разрешить».",
                    "Kamera faqat yuzni bir marta suratga olish uchun kerak. Surat MyID ga shifrlangan holda yuboriladi va "
                    "boshqa maqsadda ishlatilmaydi. Hozir brauzer ruxsat so'raydi — «Ruxsat berish»ni bosing.",
                    "The camera is used only for a single face photo. It is sent to MyID encrypted and not used for "
                    "anything else. Your browser will now ask for permission — press “Allow”."),
    "id_cam_ok": ("Понятно, включить камеру", "Tushunarli, kamerani yoqish", "Got it, turn on camera"),
    "id_start": ("Пройти проверку", "Tekshiruvdan o'tish", "Start check"),
    "id_tips": ("Хорошее освещение, лицо в центре кадра, без очков и головного убора, в кадре только вы.",
                "Yaxshi yorug'lik, yuz kadr markazida, ko'zoynak va bosh kiyimsiz, kadrda faqat siz.",
                "Good lighting, face centred, no glasses or hat, only you in the frame."),
    "id_ok": ("Личность подтверждена", "Shaxs tasdiqlandi", "Identity confirmed"),
    "id_fail": ("Не удалось подтвердить: {r}. Попробуйте ещё раз.", "Tasdiqlab bo'lmadi: {r}. Qayta urinib ko'ring.",
                "Could not confirm: {r}. Please try again."),
    "id_demo": ("Демо-режим: MyID не подключён, проверяется только наличие одного лица в кадре.",
                "Demo rejim: MyID ulanmagan, faqat kadrda bitta yuz borligi tekshiriladi.",
                "Demo mode: MyID is not connected; only one face in the frame is checked."),
    "id_status": ("Проверка личности", "Shaxsni tekshirish", "Identity check"),
    "id_verified": ("пройдена", "o'tildi", "passed"),
    # --- разрешение на уведомления
    "notif_title": ("Разрешите уведомления", "Bildirishnomalarga ruxsat bering", "Allow notifications"),
    "notif_text": ("Уведомления нужны, чтобы вовремя получать напоминания о лекарствах и сразу узнавать, если кто-то "
                   "пытается войти в ваш аккаунт с другого устройства (защита от мошенничества).",
                   "Bildirishnomalar dori eslatmalarini o'z vaqtida olish va kimdir akkauntingizga boshqa qurilmadan "
                   "kirmoqchi bo'lsa darhol bilish uchun kerak (firibgarlikdan himoya).",
                   "Notifications let you get medicine reminders on time and know immediately if someone tries to sign "
                   "in to your account from another device (fraud protection)."),
    "later": ("Позже", "Keyinroq", "Later"),
    "done_btn": ("Готово", "Tayyor", "Done"),
    # --- настройки / документы / поддержка
    "devices": ("Мои устройства", "Mening qurilmalarim", "My devices"),
    "device_current": ("это устройство", "shu qurilma", "this device"),
    "device_pending_st": ("ожидает разрешения", "ruxsat kutmoqda", "awaiting approval"),
    "revoke": ("Отключить", "O'chirish", "Revoke"),
    "one_device_note": ("Вход разрешён только с одобренных устройств. Новое устройство подтверждается здесь или в уведомлениях.",
                        "Kirish faqat tasdiqlangan qurilmalardan mumkin. Yangi qurilma shu yerda yoki bildirishnomalarda tasdiqlanadi.",
                        "Sign-in is allowed only from approved devices. Approve a new device here or in notifications."),
    "change_pwd": ("Смена пароля", "Parolni almashtirish", "Change password"),
    "old_pwd": ("Текущий пароль", "Joriy parol", "Current password"),
    "new_pwd": ("Новый пароль", "Yangi parol", "New password"),
    "interface": ("Интерфейс", "Interfeys", "Interface"),
    "security_h": ("Безопасность", "Xavfsizlik", "Security"),
    "docs_consent": ("Согласие на обработку данных", "Ma'lumotlarni qayta ishlashga rozilik", "Data processing consent"),
    "docs_accepted": ("Принято", "Qabul qilingan", "Accepted"),
    "docs_reports": ("Отчёты о здоровье", "Salomatlik hisobotlari", "Health reports"),
    "docs_privacy": ("Как мы защищаем данные", "Ma'lumotlarni qanday himoya qilamiz", "How we protect data"),
    "privacy_list": ("Шифрование данных на сервере · JWT с привязкой к устройству · проверка лица MyID · журнал доступа · "
                     "локальный ИИ без облака · тревоги видит только врач",
                     "Serverda shifrlash · qurilmaga bog'langan JWT · MyID yuz tekshiruvi · kirish jurnali · "
                     "bulutsiz mahalliy AI · signallarni faqat shifokor ko'radi",
                     "Server-side encryption · device-bound JWT · MyID face check · access log · local AI without cloud · "
                     "alerts visible only to the doctor"),
    # --- аналитика
    "details": ("Подробнее", "Batafsil", "Details"),
    "zoom_hint": ("Выделите область мышью или пальцами, чтобы приблизить; двойной щелчок — вернуть масштаб.",
                  "Kattalashtirish uchun sichqoncha yoki barmoqlar bilan hududni belgilang; ikki marta bosish — asl holat.",
                  "Drag to zoom in (or pinch on a phone); double-click to reset."),
    # --- мой врач
    "doc_card": ("Профиль врача", "Shifokor profili", "Doctor profile"),
    "write_doc": ("Написать врачу", "Shifokorga yozish", "Message doctor"),
    "book_doc": ("Записаться на приём", "Qabulga yozilish", "Book appointment"),
    "recs": ("Рекомендации", "Tavsiyalar", "Recommendations"),
    # --- заметки врача
    "notes_h": ("Закрытые заметки врача", "Shifokorning yopiq qaydlari", "Private doctor notes"),
    "notes_hint": ("Видны только вам. Пациент их не видит: прогноз, подозрения, план лечения.",
                   "Faqat sizga ko'rinadi. Bemor ko'rmaydi: prognoz, gumonlar, davolash rejasi.",
                   "Visible only to you. The patient never sees them: prognosis, suspicions, treatment plan."),
    "add_note": ("Добавить заметку", "Qayd qo'shish", "Add note"),
    "delete": ("Удалить", "O'chirish", "Delete"),
}
