"""История: показатели за любой период. История тревог видна ТОЛЬКО врачу (ТЗ)."""
from datetime import date, datetime, time, timedelta

import pandas as pd
import streamlit as st

import api
import ui
from i18n import mname, t, unit
from views.analyses import BANDS, export_block

METRICS = ["heart_rate", "systolic", "diastolic", "glucose", "resp_rate", "spo2", "calories", "body_temp", "room_temp"]


def render(patient_id: int | None = None):
    st.header(t("m_history"))
    c1, c2, c3 = st.columns([1, 1, 2])
    d_from = c1.date_input(t("from"), date.today() - timedelta(days=3), format="DD.MM.YYYY")
    d_to = c2.date_input(t("to"), date.today(), format="DD.MM.YYYY")
    chosen = c3.multiselect(t("metrics"), METRICS, default=["heart_rate", "systolic", "glucose"], format_func=mname)

    start = datetime.combine(d_from, time.min) - timedelta(hours=14)  # widen for timezone, trimmed below
    end = datetime.combine(d_to, time.max) + timedelta(hours=14)
    try:
        rows = api.get("/api/measurements/history", start=start.isoformat(), end=end.isoformat(),
                       limit=20000, patient_id=patient_id)
    except api.ApiError as e:
        st.error(e.detail)
        return
    df = pd.DataFrame(rows)
    if df.empty:
        st.info(t("no_data"))
    else:
        df["ts"] = ui.to_local(df["ts"])
        df = df[(df["ts"].dt.date >= d_from) & (df["ts"].dt.date <= d_to)]
        st.caption(f"{len(df)} {t('records')}")
        for m in chosen:
            ui.plot(ui.line_fig(df["ts"], df[m], f"{mname(m)}, {unit(m)}", band=BANDS.get(m), height=220),
                    key=f"h_{m}")
        show = df.sort_values("ts", ascending=False).rename(columns={"ts": t("time"), **{m: mname(m) for m in METRICS}})
        st.dataframe(show, hide_index=True, width="stretch", height=320)

    if st.session_state["user"]["role"] == "doctor":
        _alerts(patient_id)

    export_block("month", patient_id, key="hexp")


def _alerts(patient_id):
    st.subheader(t("alert_history"))
    try:
        alerts = api.get("/api/measurements/alerts", limit=100, patient_id=patient_id)
    except api.ApiError:
        alerts = []
    if not alerts:
        st.caption("—")
    else:
        a = pd.DataFrame(alerts)
        a["ts"] = ui.to_local(a["ts"]).dt.strftime("%d.%m.%Y %H:%M:%S")
        a["metric"] = a["metric"].map(mname)
        a["level"] = a["level"].map(t)
        a["ambulance_called"] = a["ambulance_called"].map({True: t("done"), False: ""})
        a["acknowledged"] = a["acknowledged"].map({True: t("done"), False: ""})
        st.dataframe(a[["ts", "metric", "value", "level", "ambulance_called", "acknowledged"]].rename(columns={
            "ts": t("time"), "metric": t("metric"), "value": t("value"), "level": t("level"),
            "ambulance_called": t("ambulance"), "acknowledged": t("ack")}), hide_index=True, width="stretch")

