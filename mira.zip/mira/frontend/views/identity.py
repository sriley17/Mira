"""
Экран проверки личности (MyID) при первом входе в кабинет.

Порядок (ТЗ: «сперва спросить разрешение на камеру»):
  1. объясняем, зачем нужна проверка;
  2. окно «Разрешите доступ к камере» — зачем камера и что будет со снимком;
  3. только после «Понятно» показываем st.camera_input — в этот момент браузер сам
     спрашивает системное разрешение на камеру;
  4. снимок уходит на сервер (/api/identity/verify) -> MyID (или демо-проверка).
"""
import streamlit as st

import api
import ui
from i18n import t


@st.dialog(" ")
def _camera_permission():
    st.markdown(f"### {t('id_cam_title')}")
    st.write(t("id_cam_text"))
    if st.button(t("id_cam_ok"), type="primary", width="stretch"):
        st.session_state["_cam_ok"] = True
        st.rerun()


def render(user: dict, logout):
    _, mid, _ = st.columns([1, 2, 1])
    with mid:
        try:
            status = api.get("/api/identity/status")
        except api.ApiError:
            status = {"mode": "demo"}
        st.markdown(f'<div class="mb-pending" style="margin-top:1.5rem">{ui.badge("info", "MyID")}'
                    f'<h2>{t("id_title")}</h2><p>{t("id_text")}</p></div>', unsafe_allow_html=True)
        if status.get("mode") == "demo":
            st.caption(t("id_demo"))
        if not st.session_state.get("_cam_ok"):
            if st.button(t("id_start"), type="primary", width="stretch"):
                _camera_permission()
        else:
            st.caption(t("id_tips"))
            shot = st.camera_input(t("id_title"), label_visibility="collapsed")
            if shot is not None:
                try:
                    res = api.upload("/api/identity/verify", "selfie.jpg", shot.getvalue(), "image/jpeg")
                except api.ApiError as e:
                    st.error(e.detail)
                    return
                if res["result"] == "verified":
                    st.session_state["user"]["identity_status"] = "verified"
                    ui.save_session()
                    st.toast(t("id_ok"))
                    st.rerun()
                else:
                    st.warning(t("id_fail").format(r=res.get("reason") or res["result"]))
        st.button(t("logout"), width="stretch", on_click=logout)
