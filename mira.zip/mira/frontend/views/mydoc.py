"""
Раздел «Мой врач» (пациент).

ТЗ: сначала пациент попадает в ПРОФИЛЬ врача (фото в форме, специальность, клиника, часы приёма),
а уже там — кнопки «Написать врачу», «Записаться на приём», «Рекомендации».
Так всё общение с врачом собрано в одной категории.
"""
import streamlit as st

import api
import ui
from i18n import t
from views import appointments, messages
from views.profile import DOCTOR_FIELDS, _kv_table, _show_photo

TABS = ["profile", "chat", "book", "recs"]


def _doctor_card(user: dict):
    try:
        d = api.get(f"/api/profile/{user['doctor_id']}")
    except api.ApiError as e:
        st.error(e.detail)
        return
    c1, c2 = st.columns([1, 2.2])
    with c1:
        _show_photo(d, t("photo_uniform"))
    with c2, st.container(border=True):
        st.markdown(f"### {ui.esc(d['last_name'])} {ui.esc(d['first_name'])}")
        st.markdown(_kv_table(d["fields"], list(DOCTOR_FIELDS), DOCTOR_FIELDS), unsafe_allow_html=True)
        b1, b2, b3 = st.columns(3)
        b1.button(t("write_doc"), type="primary", width="stretch",
                  on_click=lambda: st.session_state.update(mydoc_tab="chat"))
        b2.button(t("book_doc"), width="stretch", on_click=lambda: st.session_state.update(mydoc_tab="book"))
        b3.button(t("recs"), width="stretch", on_click=lambda: st.session_state.update(mydoc_tab="recs"))


def _recs(user: dict):
    """Только рекомендации врача (без переписки) — удобно перечитать назначения."""
    recs = [m for m in api.get("/api/messages") if m["kind"] == "recommendation"]
    if not recs:
        st.info(t("no_messages"))
    for m in recs:
        with st.container(border=True):
            st.markdown(f"<span class='mb-muted'>{ui.fmt_local(m['created_at'], '%d.%m.%Y %H:%M')}</span>",
                        unsafe_allow_html=True)
            st.write(m["body"])


def render():
    user = st.session_state["user"]
    st.header(t("m_mydoc"))
    if not user.get("doctor_id"):
        st.warning(t("no_doctor"))
        return
    labels = {"profile": t("doc_card"), "chat": t("m_chat"), "book": t("book_doc"), "recs": t("recs")}
    tab = st.session_state.get("mydoc_tab", "profile")
    choice = st.segmented_control(" ", TABS, format_func=labels.get, default=tab, key=f"mydoc_seg_{tab}",
                                  label_visibility="collapsed")
    if choice and choice != tab:
        st.session_state["mydoc_tab"] = choice
        st.rerun()
    if tab == "profile":
        _doctor_card(user)
    elif tab == "chat":
        messages.render_patient(show_header=False)
    elif tab == "book":
        appointments.render(show_header=False)
    else:
        _recs(user)
