"""
Единый раздел «Уведомления» (пациент) / «Сигналы и сообщения» (врач).

ТЗ: сигналы и сообщения — в одном месте, без повторов, чётко и структурированно.
  • Пациент: ответы врача, решения по записи, напоминания о лекарствах, погода, устройство,
    безопасность (новое устройство), обновления. Тревог о критическом состоянии здесь НЕТ.
  • Врач: сверху — тревоги пациентов (таблица с отметкой «принято»), ниже — лента:
    сообщения пациентов, заявки на регистрацию и приём, безопасность, обновления.
Лента собирается сервером (routers/notifications.py) и уже очищена от дублей.
"""
import pandas as pd
import streamlit as st

import api
import ui
from i18n import lang, mname, t

LEVEL = {"critical": "critical", "warning": "warning", "info": "info"}
KIND_NAME = {"message": ("Сообщения", "Xabarlar", "Messages"), "reminder": ("Лекарства", "Dorilar", "Medicines"),
             "weather": ("Погода", "Ob-havo", "Weather"), "device": ("Устройство", "Qurilma", "Device"),
             "security": ("Безопасность", "Xavfsizlik", "Security"), "update": ("Обновления", "Yangilanishlar", "Updates"),
             "alert": ("Тревоги", "Signallar", "Alerts"), "approval": ("Заявки", "Arizalar", "Approvals"),
             "appointment": ("Запись", "Qabul", "Appointments")}


def _kind(k: str) -> str:
    from i18n import _IDX
    return KIND_NAME.get(k, (k, k, k))[_IDX[lang()]]


def _alerts_table():
    alerts = api.get("/api/admin/alerts", limit=100)
    st.markdown(f"#### {t('m_alerts')}")
    ui.request_push_permission_button(t("enable_push"))
    if not alerts:
        st.caption("—")
        return
    df = pd.DataFrame(alerts)
    df["ts"] = ui.to_local(df["ts"]).dt.strftime("%d.%m %H:%M")
    df["metric"] = df["metric"].map(mname)
    df["level"] = df["level"].map(t)
    df["ambulance_called"] = df["ambulance_called"].map({True: "103", False: ""})
    df["acknowledged"] = df["acknowledged"].map({True: t("done"), False: ""})
    st.dataframe(df[["ts", "patient", "metric", "value", "level", "ambulance_called", "acknowledged"]].rename(columns={
        "ts": t("time"), "patient": t("patient"), "metric": t("metric"), "value": t("value"), "level": t("level"),
        "ambulance_called": t("ambulance"), "acknowledged": t("ack")}), hide_index=True, width="stretch")
    open_ids = [a["id"] for a in alerts if not a["acknowledged"]]
    if open_ids and st.button(f"{t('ack')} ({len(open_ids)})", type="primary"):
        for i in open_ids:
            api.post(f"/api/admin/alerts/{i}/ack")
        st.rerun()


def render(is_doc: bool):
    st.header(t("m_inbox_doc") if is_doc else t("m_inbox"))
    if is_doc:
        _alerts_table()
    data = api.get("/api/notifications", lang=lang())
    items = [i for i in data["items"] if not (is_doc and i["kind"] == "alert")]   # тревоги уже в таблице выше
    kinds = list(dict.fromkeys(i["kind"] for i in items))
    pick = st.pills(" ", kinds, format_func=_kind, selection_mode="multi", default=kinds, key="inbox_filter",
                    label_visibility="collapsed")
    shown = [i for i in items if i["kind"] in (pick or kinds)]
    if not shown:
        st.info(t("no_notifications"))
    for i, it in enumerate(shown):
        with st.container(border=True):
            c1, c2 = st.columns([5, 1.3], vertical_alignment="center")
            new = f" {ui.badge('normal', t('unread'))}" if it["unread"] else ""
            c1.markdown(f"**{ui.esc(it['title'])}** {ui.badge(LEVEL.get(it['level'], 'info'), _kind(it['kind']))}{new}  \n"
                        f"{ui.esc(it['text'])}  \n<span class='mb-muted'>{ui.fmt_local(it['ts'], '%d.%m.%Y %H:%M')}</span>",
                        unsafe_allow_html=True)
            action = it.get("action") or {}
            if action.get("type") == "approve_device":
                if c2.button(t("allow"), key=f"ib_dev{i}", type="primary", width="stretch"):
                    api.post(f"/api/auth/devices/{action['id']}/approve")
                    st.rerun()
            elif it.get("page"):
                c2.button(t("open_patient") if is_doc and it["kind"] == "alert" else t("details"), key=f"ib_go{i}",
                          width="stretch", on_click=lambda p=it["page"]: st.session_state.update(page=p))
    if data["unread"]:
        api.post("/api/notifications/seen")      # раз пользователь открыл раздел — всё прочитано
