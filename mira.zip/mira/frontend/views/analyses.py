"""
Раздел «Анализы»: 8 карточек с мини-графиками (в реальном времени по WebSocket или отчёт за
день / неделю / месяц). Большого общего графика больше нет: кнопка «Подробнее» под карточкой
открывает окно с увеличенным графиком этого показателя — его можно приближать (колесо мыши,
выделение области, жест на телефоне) и двигать ползунком диапазона. Ниже — таблица отчёта и экспорт.
"""
from datetime import datetime, timedelta

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

import api
import ui
from i18n import lang, mname, t, unit

BANDS = {"heart_rate": (60, 100), "systolic": (90, 140), "diastolic": (60, 90), "glucose": (3.9, 7.8),
         "resp_rate": (12, 20), "spo2": (95, 100), "body_temp": (36.1, 37.2), "room_temp": (20, 25)}
LEVEL_RULES = {"heart_rate": (40, 50, 110, 140), "systolic": (80, 90, 140, 180), "diastolic": (None, None, 90, 120),
               "glucose": (3.0, 3.9, 10.0, 16.7), "resp_rate": (8, 10, 24, 30), "spo2": (90, 94, None, None),
               "body_temp": (35.0, 35.5, 37.8, 39.5)}
CARDS = ["heart_rate", "bp", "glucose", "resp_rate", "spo2", "calories", "body_temp", "room_temp"]
ORDER = ["normal", "warning", "critical"]


def level(metric: str, v: float | None) -> str:
    b = LEVEL_RULES.get(metric)
    if not b or v is None or pd.isna(v):
        return "normal"
    lc, lw, hw, hc = b
    if (lc is not None and v < lc) or (hc is not None and v > hc):
        return "critical"
    if (lw is not None and v < lw) or (hw is not None and v > hw):
        return "warning"
    return "normal"


@st.cache_data(ttl=60, show_spinner=False)
def _day_report(token: str, patient_id: int | None) -> dict:
    return api.get("/api/measurements/report", period="day", patient_id=patient_id)


def _fmt(v: float, digits: int) -> str:
    return f"{v:,.{digits}f}".replace(",", " ")


def _cards(df: pd.DataFrame, values: dict, kcal_series=None, kcal_total=None, ctx: str = "live",
           bars_for_calories: bool = False):
    """8 карточек, по 4 в ряд (на телефоне — по 2). Под каждой — «Подробнее»: открывает
    увеличенный график этого показателя в отдельном окне (вместо одного большого графика внизу)."""
    html = []
    for m in CARDS:
        if m == "bp":
            s_, d = values["systolic"], values["diastolic"]
            lvl = max(level("systolic", s_), level("diastolic", d), key=ORDER.index)
            html.append(ui.card_html(mname("bp"), f"{s_:.0f}/{d:.0f}", unit("bp"), lvl, df["systolic"]))
        elif m == "calories":
            series = kcal_series if kcal_series is not None else df["calories"].cumsum()
            total = kcal_total if kcal_total is not None else float(df["calories"].sum())
            html.append(ui.card_html(mname(m), _fmt(total, 0), unit(m), None, series))
        else:
            digits = 1 if m in ("glucose", "body_temp", "room_temp") else 0
            lvl = level(m, values[m]) if m in LEVEL_RULES else None
            html.append(ui.card_html(mname(m), _fmt(values[m], digits), unit(m), lvl, df[m]))
    for i in range(0, len(html), 4):
        for col, h, m in zip(st.columns(4), html[i:i + 4], CARDS[i:i + 4]):
            col.markdown(h, unsafe_allow_html=True)
            if col.button(t("details"), key=f"det_{ctx}_{m}", width="stretch", type="tertiary"):
                # сохраняем снимок данных и перезапускаем страницу целиком: окно открывается вне
                # «живого» фрагмента, поэтому не закрывается при обновлении данных каждые 3 секунды
                st.session_state["_detail"] = {"metric": m, "bars": bars_for_calories,
                                               "rows": df.to_dict(orient="list")}
                st.rerun()


@st.dialog(" ", width="large")
def _detail_dialog(d: dict):
    """Увеличенный график одного показателя: масштаб колесом/выделением, ползунок диапазона внизу."""
    df = pd.DataFrame(d["rows"])
    m = d["metric"]
    st.markdown(f"### {mname(m)} <span class='mb-muted'>{unit(m)}</span>", unsafe_allow_html=True)
    col = "systolic" if m == "bp" else m
    s_ = df[col].dropna()
    if len(s_):
        if m == "bp":
            dd = df["diastolic"].dropna()
            stats = [(t("min"), f"{s_.min():.0f}/{dd.min():.0f}"), (t("avg"), f"{s_.mean():.0f}/{dd.mean():.0f}"),
                     (t("max"), f"{s_.max():.0f}/{dd.max():.0f}")]
        else:
            digits = 1 if m in ("glucose", "body_temp", "room_temp") else 0
            stats = [(t("min"), _fmt(s_.min(), digits)), (t("avg"), _fmt(s_.mean(), digits)),
                     (t("max"), _fmt(s_.max(), digits))]
        st.markdown("<div class='mb-stats' style='justify-content:flex-start'>" + "".join(
            f"<div><span>{a}</span><b>{v}</b></div>" for a, v in stats) + "</div>", unsafe_allow_html=True)
    if m == "calories" and d["bars"]:
        fig = ui.style_fig(go.Figure(go.Bar(x=df["ts"], y=df["calories"], marker_color=ui.accent())), 420)
    elif m == "calories":
        fig = ui.line_fig(df["ts"], df["calories"].cumsum(), height=420)
    elif m == "bp":
        fig = ui.line_fig(df["ts"], df["systolic"], band=(60, 140), y2=df["diastolic"], height=420)
    else:
        fig = ui.line_fig(df["ts"], df[m], band=BANDS.get(m), height=420)
    fig.update_xaxes(rangeslider=dict(visible=True, thickness=0.08))
    st.plotly_chart(fig, width="stretch", key="detail_zoom",
                    config={"scrollZoom": True, "displaylogo": False,
                            "modeBarButtonsToRemove": ["lasso2d", "select2d", "toImage"]})
    st.caption(t("zoom_hint"))


def _live(patient_id: int | None):
    @st.fragment(run_every="3s")
    def live_block():
        s = api.stream(patient_id)
        if not getattr(s, "prefilled", False):  # show the last 20 min from DB right away
            s.prefilled = True
            try:
                end = datetime.utcnow()
                hist = api.get("/api/measurements/history", start=(end - timedelta(minutes=20)).isoformat(),
                               end=end.isoformat(), patient_id=patient_id)
                # stored rows carry ~30 s of calories; scale to live tick size
                pts = [dict(h, patient_id=patient_id, calories=h["calories"] / 15) for h in hist]
                s.measurements.extendleft(reversed(pts))
            except api.ApiError:
                pass
        data = [m for m in list(s.measurements) if patient_id is None or m.get("patient_id") == patient_id]
        dot = "mb-dot-on" if s.connected else "mb-dot-off"
        state = t("connected_ws") if s.connected else t("connecting_ws")
        st.markdown(f'<span class="mb-muted"><span class="mb-dot {dot}"></span>{state}</span>',
                    unsafe_allow_html=True)
        if not data:
            st.info(t("waiting"))
            return
        df = pd.DataFrame(data)
        df["ts"] = ui.to_local(df["ts"])
        try:  # calories card: total for the last 24 h, sparkline by hour
            day = _day_report(st.session_state["token"], patient_id)
            kcal_rows = pd.DataFrame(day["rows"])
            kcal_series = kcal_rows["calories"] if len(kcal_rows) else None
            kcal_total = day["summary"].get("calories", {}).get("total")
        except api.ApiError:
            kcal_series = kcal_total = None
        _cards(df, data[-1], kcal_series, kcal_total, ctx="live")

    live_block()


def _report(period: str, patient_id: int | None):
    try:
        rep = api.get("/api/measurements/report", period=period, patient_id=patient_id)
    except api.ApiError as e:
        st.error(e.detail)
        return
    if not rep["rows"]:
        st.info(t("no_data"))
        return
    df = pd.DataFrame(rep["rows"])
    df["ts"] = ui.to_local(df["ts"])
    avgs = {m: v["avg"] for m, v in rep["summary"].items()}
    st.markdown(f'<span class="mb-muted">{t("avg")} · {t(period).lower()}</span>', unsafe_allow_html=True)
    _cards(df, avgs, kcal_series=df["calories"], kcal_total=rep["summary"]["calories"]["total"], ctx=period,
           bars_for_calories=True)

    with st.expander(t("report_table")):
        cols = ["heart_rate", "systolic", "diastolic", "glucose", "resp_rate", "spo2", "calories",
                "body_temp", "room_temp"]
        st.dataframe(df.rename(columns={"ts": t("time"), **{m: mname(m) for m in cols}}),
                     hide_index=True, width="stretch")
    export_block(period, patient_id)


def export_block(period: str, patient_id: int | None, key: str = "exp"):
    st.markdown(f"#### {t('export')}")
    c1, c2, _ = st.columns([1, 1, 2])
    for col, fmt, label, mime in ((c1, "pdf", "make_pdf", "application/pdf"),
                                  (c2, "xlsx", "make_xlsx",
                                   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")):
        with col:
            skey = f"_{key}_{fmt}_{period}_{patient_id}_{lang()}"
            if st.button(t(label), key=f"{key}{fmt}{period}", width="stretch"):
                with st.spinner("…"):
                    st.session_state[skey] = api.get(f"/api/export/{fmt}", period=period, lang=lang(),
                                                     patient_id=patient_id)
            if skey in st.session_state:
                st.download_button(f"{t('download')} {fmt.upper()}", st.session_state[skey],
                                   file_name=f"mira_{period}.{fmt}", mime=mime, width="stretch",
                                   key=f"dl{key}{fmt}{period}")


def render(patient_id: int | None = None):
    modes = {"live": t("live"), "day": t("day"), "week": t("week"), "month": t("month")}
    mode = st.segmented_control(" ", list(modes), format_func=modes.get, default="live",
                                key="an_mode", label_visibility="collapsed") or "live"
    if mode == "live":
        _live(patient_id)
    else:
        _report(mode, patient_id)
    detail = st.session_state.pop("_detail", None)
    if detail:
        _detail_dialog(detail)
