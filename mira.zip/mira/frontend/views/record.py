"""
Раздел «Медкарта (Dmed)»: группа крови, аллергии, диагнозы (МКБ-10), анализы, визиты, прививки.
Данные приходят через адаптер services/dmed.py. Без подключённого Dmed показывается
понятная пометка «демо-режим», чтобы тестовые данные нельзя было принять за настоящие.
Телефон и ПИНФЛ пациент указывает в разделе «Мой профиль» (хранятся зашифрованными).
"""
import pandas as pd
import streamlit as st

import api
import ui
from i18n import t


def render(patient_id: int | None = None):
    st.header(t("m_record"))
    try:
        r = api.get("/api/dmed/record", patient_id=patient_id)
    except api.ApiError as e:
        st.error(e.detail)
        return
    if r["source"] == "demo":
        st.markdown(ui.badge("info", t("dmed_demo")), unsafe_allow_html=True)

    c1, c2 = st.columns([1, 2])
    with c1, st.container(border=True):
        st.markdown(ui.kv(t("blood_type"), r.get("blood_type") or "—")
                    + ui.kv(t("allergies"), ", ".join(r.get("allergies") or []) or t("none")),
                    unsafe_allow_html=True)
        st.markdown(f"<br>**{t('vaccinations')}**", unsafe_allow_html=True)
        st.markdown("".join(ui.kv(v["name"], v["date"]) for v in r.get("vaccinations", [])), unsafe_allow_html=True)
    with c2, st.container(border=True):
        st.markdown(f"**{t('diagnoses')}**")
        st.markdown("".join(ui.kv(f"{d['code']} · {d['name']}", d["date"]) for d in r.get("diagnoses", [])),
                    unsafe_allow_html=True)
        st.markdown(f"<br>**{t('visits')}**", unsafe_allow_html=True)
        st.markdown("".join(ui.kv(f"{v['clinic']} · {v['doctor']}", v["date"]) for v in r.get("visits", [])),
                    unsafe_allow_html=True)

    labs = r.get("labs") or []
    if labs:
        st.markdown(f"#### {t('labs')}")
        df = pd.DataFrame(labs)
        st.dataframe(df.rename(columns={"name": t("metric"), "value": t("value"), "unit": "", "ref": t("ref"),
                                        "date": t("time")}), hide_index=True, width="stretch")

