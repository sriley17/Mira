"""«Ответы врача» (пациент) и «Сообщения» (врач). Тексты выводятся через st.write — HTML не исполняется."""
import streamlit as st

import api
import ui
from i18n import mname, t

KIND = {"recommendation": "recommendation", "message": "message", "alert": "alert_msg", "system": "system_msg"}


def _thread(msgs: list, me: int):
    if not msgs:
        st.info(t("no_messages"))
        return
    for m in msgs:
        mine = m["sender_id"] == me
        with st.container(border=True):
            who = t("you") if mine else m["sender_name"]
            lvl = "critical" if m["kind"] == "alert" else "info" if m["kind"] == "system" else "normal"
            head = f"**{ui.esc(who)}** · <span class='mb-muted'>{ui.fmt_local(m['created_at'], '%d.%m.%Y %H:%M')}</span>"
            if m["kind"] != "message":
                head += " " + ui.badge(lvl, t(KIND[m["kind"]]))
            st.markdown(head, unsafe_allow_html=True)
            body = m["body"]
            if m["kind"] == "alert":
                for k in ("heart_rate", "systolic", "diastolic", "glucose", "resp_rate", "spo2", "body_temp"):
                    body = body.replace(k, mname(k))
                body = body.replace("CRITICAL", t("critical"))
            st.write(body)


def render_patient(show_header: bool = True):
    user = st.session_state["user"]
    if show_header:
        st.header(t("m_doctor"))
    if not user.get("doctor_id"):
        st.warning(t("no_doctor"))
    with st.form("ask_doc", clear_on_submit=True):
        body = st.text_area(t("ask_doctor"), height=90)
        if st.form_submit_button(t("send")) and body.strip():
            try:
                api.post("/api/messages", {"body": body.strip()})
                st.toast(t("sent"))
            except api.ApiError as e:
                st.error(e.detail)
    msgs = [m for m in api.get("/api/messages") if m["kind"] != "alert"]
    _thread(msgs, user["id"])


def render_doctor(patient_id: int | None):
    st.header(t("m_messages"))
    if not patient_id:
        st.info(t("no_patients"))
        return
    kinds = {"recommendation": t("recommendation"), "message": t("message")}
    with st.form("doc_msg", clear_on_submit=True):
        kind = st.segmented_control(t("type"), list(kinds), format_func=kinds.get, default="recommendation")
        body = st.text_area(t("message"), height=100)
        if st.form_submit_button(t("send")) and body.strip():
            try:
                api.post("/api/messages", {"body": body.strip(), "receiver_id": patient_id,
                                           "kind": kind or "message"})
                st.toast(t("sent"))
            except api.ApiError as e:
                st.error(e.detail)
    _thread(api.get("/api/messages", with_user=patient_id), st.session_state["user"]["id"])
