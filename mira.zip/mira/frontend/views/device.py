"""GPS (карта обновляется раз в час) и состояние устройства (батарея, связь)."""
import pandas as pd
import streamlit as st

import api
import ui
from i18n import t


def _status(patient_id):
    try:
        return api.get("/api/device", patient_id=patient_id)
    except api.ApiError:
        return None


def render_gps(patient_id: int | None = None):
    st.header(t("m_gps"))
    st.caption(t("location"))

    # ТЗ: карта обновляется каждый час. Сервер тоже сохраняет координаты раз в час
    # (при критическом событии — сразу), поэтому чаще опрашивать нет смысла.
    @st.fragment(run_every="3600s")
    def gps_block():
        d = _status(patient_id)
        if not d:
            st.info(t("no_device"))
            return
        lat, lon = d["lat"], d["lon"]
        st.map(pd.DataFrame({"lat": [lat], "lon": [lon]}), zoom=15, size=25, color=ui.accent(), height=420)
        c1, c2 = st.columns([2, 1])
        upd = ui.fmt_local(d.get("gps_updated") or d["last_seen"], "%d.%m %H:%M")
        c1.markdown(f"**{t('coords')}:** `{lat:.5f}, {lon:.5f}` · {t('gps_updated')}: {upd}  \n"
                    f"<span class='mb-muted'>{t('gps_next')}</span>", unsafe_allow_html=True)
        c2.link_button(t("open_maps"), f"https://www.google.com/maps?q={lat},{lon}", width="stretch")

    gps_block()


def render_device(patient_id: int | None = None):
    st.header(t("m_device"))

    @st.fragment(run_every="10s")
    def dev_block():
        d = _status(patient_id)
        if not d:
            st.info(t("no_device"))
            return
        live = api.stream(patient_id).device
        battery = live["battery"] if live else d["battery"]
        online = d["connected"]
        c1, c2 = st.columns(2)
        with c1:
            with st.container(border=True):
                st.metric(t("battery"), f"{battery:.0f}%")
                st.markdown(ui.progress_bar(battery), unsafe_allow_html=True)
                if battery < 20:
                    st.markdown(ui.badge("warning", t("low_battery")), unsafe_allow_html=True)
        with c2:
            with st.container(border=True):
                st.metric(t("connection"), t("online") if online else t("offline"))
                st.markdown(f'<span class="mb-muted"><span class="mb-dot {"mb-dot-on" if online else "mb-dot-off"}"></span>'
                            f'{t("online") if online else t("offline")}</span>', unsafe_allow_html=True)
        with st.container(border=True):
            for label, val in ((t("serial"), d["serial"]), (t("firmware"), d["firmware"]),
                               (t("last_seen"), ui.fmt_local(d["last_seen"], "%d.%m.%Y %H:%M:%S"))):
                a, b = st.columns([1, 2])
                a.markdown(f'<span class="mb-muted">{label}</span>', unsafe_allow_html=True)
                b.markdown(f"**{val}**")

    dev_block()

    if st.session_state["user"]["role"] == "patient":
        ui.request_push_permission_button(t("enable_push"))
        with st.expander(t("hw_creds")):
            try:
                c = api.get("/api/device/credentials")
                st.code(f"POST {api.API_URL}/api/device/ingest\nX-Device-Serial: {c['serial']}\n"
                        f"X-Device-Key: {c['api_key']}", language="http")
            except api.ApiError as e:
                st.error(e.detail)
