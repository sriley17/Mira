"""
Раздел «Сон»: длительность и качество последней ночи, показатели во сне
(пульс, SpO₂, давление, сахар, температура тела и комнаты), погода и УФ-индекс,
график пульса за ночь (зелёная зона — сон), неделя в сравнении.
Сам анализ выполняет сервер (services/sleep.py); здесь — только отображение.
"""
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

import api
import ui
from i18n import mname, t

UV = {"low": ("низкий", "past", "low"), "moderate": ("умеренный", "o'rtacha", "moderate"),
      "high": ("высокий", "yuqori", "high"), "very_high": ("очень высокий", "juda yuqori", "very high"),
      "extreme": ("экстремальный", "ekstremal", "extreme"), "unknown": ("—", "—", "—")}


def _uv(level: str) -> str:
    from i18n import _IDX, lang
    return UV.get(level, UV["unknown"])[_IDX[lang()]]


def _h(hours: float) -> str:
    """7.58 -> '7 ч 35 мин' в компактном виде '7:35'."""
    m = round(hours * 60)
    return f"{m // 60}:{m % 60:02d}"


@st.cache_data(ttl=120, show_spinner=False)
def _load(token: str, patient_id: int | None) -> dict:
    return api.get("/api/sleep", nights=7, patient_id=patient_id)


def render(patient_id: int | None = None):
    st.header(t("m_sleep"))
    try:
        data = _load(st.session_state["token"], patient_id)
    except api.ApiError as e:
        st.error(e.detail)
        return
    s = data.get("summary")
    if not s:
        st.info(t("no_sleep"))
        return
    last = s["last"]
    v = last["vitals"]

    k1, k2, k3, k4 = st.columns(4)
    for col, label, value, small in ((k1, t("sleep_hours"), _h(last["hours"]), t("hours_short")),
                                     (k2, t("sleep_score"), last["score"], "/100"),
                                     (k3, t("efficiency"), last["efficiency"], "%"),
                                     (k4, t("awakenings"), last["awakenings"], "")):
        with col, st.container(border=True):
            st.markdown(f"<span class='mb-muted'>{label}</span><div class='mb-big'>{value}<small> {small}</small></div>",
                        unsafe_allow_html=True)
    st.caption(f"{t('last_night')} · {t('bedtime')}: {last['onset']} – {last['wake']}")

    left, right = st.columns([1.6, 1])
    with left, st.container(border=True):
        curve = pd.DataFrame(last["curve"])
        if len(curve):
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=curve["t"], y=curve["hr"], mode="lines", line=dict(color=ui.accent(), width=2)))
            asleep = curve[curve["asleep"]]
            fig.add_trace(go.Bar(x=asleep["t"], y=[curve["hr"].max() * 1.05] * len(asleep), marker_color=ui.accent(),
                                 opacity=0.08, hoverinfo="skip"))
            fig.update_layout(bargap=0)
            ui.plot(ui.style_fig(fig, 260, f"{mname('heart_rate')} · {t('last_night').lower()}"), key="sleep_hr")
    with right, st.container(border=True):
        st.markdown(f"**{t('night_vitals')}**")
        rows = [(mname("heart_rate"), f"{v['heart_rate']} ({t('hr_day')} {v['heart_rate_day']})"),
                ("SpO₂", f"{v['spo2_avg']} % · min {v['spo2_min']} %"),
                (mname("bp"), f"{v['systolic']:.0f}/{v['diastolic']:.0f}"),
                (mname("glucose"), v["glucose"]), (mname("resp_rate"), v["resp_rate"]),
                (mname("body_temp"), f"{v['body_temp']} °C"), (mname("room_temp"), f"{v['room_temp']} °C")]
        st.markdown("".join(ui.kv(a, b) for a, b in rows), unsafe_allow_html=True)
        w = last.get("weather") or {}
        st.markdown(f"<br>**{t('weather_uv')}**", unsafe_allow_html=True)
        st.markdown(ui.kv(t("night_min"), f"{w.get('night_min', '—')} °C") + ui.kv(t("day_max"), f"{w.get('day_max', '—')} °C")
                    + ui.kv(t("uv_index"), f"{w.get('uv_max', '—')} · {_uv(w.get('uv_level', 'unknown'))}"),
                    unsafe_allow_html=True)
        if data.get("weather_source") == "climate":
            st.caption(t("wx_source_climate"))

    c1, c2 = st.columns([1.6, 1])
    with c1, st.container(border=True):
        nights = [n for n in data["nights"] if n.get("detected")]
        df = pd.DataFrame({"d": [n["date"][5:] for n in nights], "h": [n["hours"] for n in nights],
                           "s": [n["score"] for n in nights]})
        fig = go.Figure(go.Bar(x=df["d"], y=df["h"], marker_color=ui.accent(), text=df["s"], textposition="outside"))
        fig.add_hrect(y0=7, y1=9, line_width=0, fillcolor=ui.accent(), opacity=0.06)
        ui.plot(ui.style_fig(fig, 240, f"{t('week_nights')} · {t('sleep_hours').lower()}, {t('hours_short')}"),
                key="sleep_week")
    with c2, st.container(border=True):
        st.markdown(f"**{t('score_parts')}**")
        for f in last["factors"]:
            st.markdown(ui.kv(t("sc_" + f["code"]), f"{f['points']}/{f['max']}") + ui.progress_bar(f["points"] / f["max"] * 100),
                        unsafe_allow_html=True)
