"""
Раздел «Лекарства».
Пациент: расписание на сегодня с кнопкой «Принял», соблюдение режима, назначения, журнал SMS;
         может сам (или его родственник) добавить напоминание — SMS придёт на телефон точно по времени.
Врач:    то же по выбранному пациенту + форма назначения и отмена препарата.
SMS-напоминания отправляет сервер (services/medications.py) — даже если портал закрыт.
"""
from datetime import date, timedelta

import pandas as pd
import streamlit as st

import api
import ui
from i18n import t

STATUS_LVL = {"taken": "normal", "due": "warning", "upcoming": "info", "missed": "info"}


def _today(data: dict, is_doc: bool):
    st.markdown(f"#### {t('today_doses')}")
    if not data["today"]:
        st.caption(t("no_meds"))
        return
    for i, d in enumerate(data["today"]):
        with st.container(border=True):
            c1, c2, c3 = st.columns([1, 4, 1.4], vertical_alignment="center")
            c1.markdown(f"<div class='mb-big' style='font-size:1.4rem'>{d['time']}</div>", unsafe_allow_html=True)
            course = f" · {t('antibiotic')}" if d["is_antibiotic"] else ""
            c2.markdown(f"**{ui.esc(d['name'])}** {ui.esc(d['dose'])}<span class='mb-muted'>{course}</span>  \n"
                        + ui.badge(STATUS_LVL[d["status"]], t(d["status"])), unsafe_allow_html=True)
            if not is_doc and d["status"] in ("due", "missed", "upcoming"):
                if c3.button(t("mark_taken"), key=f"take{i}", width="stretch",
                             type="primary" if d["status"] == "due" else "secondary"):
                    try:
                        api.post(f"/api/medications/{d['medication_id']}/take", {"scheduled_at": d["scheduled_at"]})
                        st.rerun()
                    except api.ApiError as e:
                        st.error(e.detail)


def _adherence(data: dict):
    a = data["adherence"]
    with st.container(border=True):
        st.markdown(f"<span class='mb-muted'>{t('adherence')}</span><div class='mb-big'>"
                    f"{a['pct'] if a['pct'] is not None else '—'}<small> %</small></div>"
                    + ui.progress_bar(a["pct"] or 0), unsafe_allow_html=True)
        for m in a["per_medication"]:
            st.markdown(ui.kv(m["name"], f"{m['taken']}/{m['planned']}"), unsafe_allow_html=True)


def _prescriptions(data: dict, is_doc: bool):
    st.markdown(f"#### {t('prescriptions')}")
    meds = data["medications"]
    if not meds:
        st.caption(t("no_meds"))
        return
    for m in meds:
        with st.container(border=True):
            c1, c2 = st.columns([4, 1], vertical_alignment="center")
            until = f" · {t('course_until')} {m['end_date']}" if m["end_date"] else ""
            extra = f"  \n<span class='mb-muted'>{ui.esc(m['notes'])}</span>" if m["notes"] else ""
            state = "" if m["active"] else " · " + t("st_cancelled")
            c1.markdown(f"**{ui.esc(m['name'])}** {ui.esc(m['dose'])} · {m['times'].replace(',', ', ')}"
                        f"<span class='mb-muted'>{until}{state}</span>{extra}", unsafe_allow_html=True)
            if m.get("by_patient"):
                c1.caption(t("by_patient"))
            can_stop = is_doc or m.get("by_patient")   # назначение врача пациент отменить не может
            if can_stop and m["active"] and c2.button(t("stop_med"), key=f"stop{m['id']}", width="stretch"):
                api.delete(f"/api/medications/{m['id']}")
                st.rerun()


def _prescribe_form(patient_id: int | None, is_doc: bool):
    """Врач — «Назначить» препарат пациенту. Пациент (или родственник) — «Добавить напоминание» себе."""
    with st.expander(t("prescribe") if is_doc else t("add_reminder"), expanded=False), st.form("rx", clear_on_submit=True):
        if not is_doc:
            st.caption(t("reminder_hint"))
        c1, c2 = st.columns(2)
        name = c1.text_input(t("med_name"), max_chars=120)
        dose = c2.text_input(t("dose"), placeholder="500 мг", max_chars=60)
        times = st.text_input(t("times"), value="08:00,20:00")
        c3, c4 = st.columns(2)
        start = c3.date_input(t("start"), value=date.today())
        abx = st.checkbox(t("antibiotic"))
        end = c4.date_input(t("end"), value=date.today() + timedelta(days=7))
        notes = st.text_input(t("notes"), max_chars=300)
        sms = st.checkbox(t("sms_on"), value=True)
        if st.form_submit_button(t("prescribe"), type="primary"):
            try:
                api.post("/api/medications", {"patient_id": patient_id, "name": name, "dose": dose, "times": times,
                                              "start_date": start.isoformat(),
                                              "end_date": end.isoformat() if abx else None,   # у обычных препаратов курс бессрочный
                                              "is_antibiotic": abx, "notes": notes or None, "sms_enabled": sms})
                st.toast(t("saved"))
                st.rerun()
            except api.ApiError as e:
                st.error(e.detail)


def render(patient_id: int | None = None):
    is_doc = st.session_state["user"]["role"] == "doctor"
    st.header(t("m_meds"))
    try:
        data = api.get("/api/medications", patient_id=patient_id)
    except api.ApiError as e:
        st.error(e.detail)
        return
    left, right = st.columns([2, 1])
    with left:
        _today(data, is_doc)
    with right:
        _adherence(data)
    _prescribe_form(patient_id, is_doc)
    _prescriptions(data, is_doc)
    with st.expander(t("sms_log")):
        log = api.get("/api/medications/sms-log", patient_id=patient_id)
        if log:
            df = pd.DataFrame(log)
            df["ts"] = ui.to_local(df["ts"]).dt.strftime("%d.%m %H:%M")
            st.dataframe(df.rename(columns={"ts": t("time"), "status": t("status"), "text": t("message")}),
                         hide_index=True, width="stretch")
        else:
            st.caption("—")
