"""
Раздел «Запись к врачу».
Пациент: выбирает день -> видит только СВОБОДНОЕ время -> отправляет заявку.
         Если время уже занято (кто-то успел раньше), сервер отвечает 409 и сразу присылает
         3 ближайших свободных варианта — они показываются кнопками.
Врач:    видит заявки, подтверждает или отклоняет; при отклонении пациенту автоматически
         уходит сообщение с вариантами свободного времени.
"""
from datetime import date, timedelta

import streamlit as st

import api
import ui
from i18n import t

LVL = {"requested": "warning", "approved": "normal", "declined": "info", "cancelled": "info"}


def _book(start: str, reason: str | None):
    try:
        api.post("/api/appointments", {"start": start, "reason": reason or None})
        st.session_state.pop("_appt_suggest", None)
        st.toast(t("booked"))
        st.rerun()
    except api.ApiError as e:
        if e.status == 409:
            st.session_state["_appt_suggest"] = True
        st.error(t("suggested") if e.status == 409 else e.detail)


def _patient():
    with st.container(border=True):
        st.markdown(f"**{t('appt_how')}**")
        st.caption(t("appt_steps"))
    c1, c2 = st.columns([1, 2])
    day = c1.date_input(t("pick_day"), value=date.today() + timedelta(days=1), min_value=date.today(),
                        max_value=date.today() + timedelta(days=30))
    reason = c2.text_input(t("reason"), max_chars=500)
    slots = api.get("/api/appointments/slots", day=day.isoformat())["slots"]
    st.markdown(f"**{t('free_slots')}**")
    if not slots:
        st.caption(t("no_slots"))
        # подсказка: ближайшие свободные дни
        for d in range(1, 8):
            alt = api.get("/api/appointments/slots", day=(day + timedelta(days=d)).isoformat())["slots"]
            if alt:
                st.caption(f"{alt[0]['date']}: " + ", ".join(s["local"] for s in alt[:6]))
                break
    else:
        cols = st.columns(6)
        for i, s in enumerate(slots):
            if cols[i % 6].button(s["local"], key=f"slot{s['start']}", width="stretch"):
                _book(s["start"], reason)

    st.markdown(f"#### {t('my_appts')}")
    _list(is_doc=False)


def _list(is_doc: bool):
    rows = api.get("/api/appointments")
    if not rows:
        st.caption("—")
        return
    for a in reversed(rows):
        with st.container(border=True):
            c1, c2, c3 = st.columns([3, 1, 1], vertical_alignment="center")
            who = a["patient"] if is_doc else a["doctor"]
            reason = f"  \n<span class='mb-muted'>{ui.esc(a['reason'])}</span>" if a["reason"] else ""
            c1.markdown(f"**{a['local_date']} {a['local_time']}** · {ui.esc(who)} "
                        f"{ui.badge(LVL[a['status']], t('st_' + a['status']))}{reason}", unsafe_allow_html=True)
            if is_doc and a["status"] == "requested":
                if c2.button(t("approve"), key=f"aa{a['id']}", type="primary", width="stretch"):
                    api.post(f"/api/appointments/{a['id']}/decision", {"status": "approved"})
                    st.rerun()
                if c3.button(t("reject"), key=f"ad{a['id']}", width="stretch"):
                    api.post(f"/api/appointments/{a['id']}/decision", {"status": "declined"})
                    st.rerun()
            if not is_doc and a.get("suggestions"):
                # отклонено -> свободное время прямо рядом с заявкой, запись в один клик
                st.caption(t("suggested"))
                sc = st.columns(3)
                for j, sg in enumerate(a["suggestions"]):
                    lbl = f"{sg['date'][8:10]}.{sg['date'][5:7]} {sg['local']}"
                    if sc[j].button(lbl, key=f"sg{a['id']}_{j}", width="stretch"):
                        _book(sg["start"], a.get("reason"))
            if not is_doc and a["status"] in ("requested", "approved"):
                if c3.button(t("cancel"), key=f"ac{a['id']}", width="stretch"):
                    api.post(f"/api/appointments/{a['id']}/cancel")
                    st.rerun()


def render(show_header: bool = True):
    is_doc = st.session_state["user"]["role"] == "doctor"
    if show_header:
        st.header(t("requests") if is_doc else t("m_appts"))
    if is_doc:
        _list(is_doc=True)
    else:
        if not st.session_state["user"].get("doctor_id"):
            st.warning(t("no_doctor"))
            return
        _patient()
