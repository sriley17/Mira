"""
Меню под именем пользователя (правый верхний угол): Настройки, Документы, Техподдержка.
(«Личные данные» ведут в раздел «Профиль» — views/profile.py.)

Настройки   — язык и тема, уведомления браузера, МОИ УСТРОЙСТВА (правило «одно устройство»:
              здесь разрешают вход с нового телефона/ноутбука или отключают старый), смена пароля.
Документы   — принятое согласие на обработку данных (дата и версия), как защищены данные,
              скачивание отчётов о здоровье (PDF / Excel).
Техподдержка — контакты столбцом.
"""
import streamlit as st

import api
import ui
from i18n import t
from views.analyses import export_block
from views.landing import LT, SUPPORT_EMAIL, SUPPORT_HOURS, SUPPORT_PHONE


def render_settings():
    st.header(t("m_settings"))
    with st.container(border=True):
        st.markdown(f"#### {t('notifications')}")
        st.caption(t("notif_text"))
        ui.request_push_permission_button(t("allow"))

    with st.container(border=True):
        st.markdown(f"#### {t('devices')}")
        st.caption(t("one_device_note"))
        for d in api.get("/api/auth/devices"):
            c1, c2 = st.columns([4, 1.3], vertical_alignment="center")
            state = t("device_current") if d["current"] else (t("device_pending_st") if d["status"] == "pending" else "")
            c1.markdown(f"**{ui.esc(d['label'] or '—')}** <span class='mb-muted'>· {state} · "
                        f"{ui.fmt_local(d['last_seen'], '%d.%m.%Y %H:%M')}</span>", unsafe_allow_html=True)
            if d["status"] == "pending":
                if c2.button(t("allow"), key=f"dv_ok{d['id']}", type="primary", width="stretch"):
                    api.post(f"/api/auth/devices/{d['id']}/approve")
                    st.rerun()
            elif not d["current"]:
                if c2.button(t("revoke"), key=f"dv_rv{d['id']}", width="stretch"):
                    api.post(f"/api/auth/devices/{d['id']}/revoke")
                    st.rerun()

    with st.container(border=True):
        st.markdown(f"#### {t('change_pwd')}")
        with st.form("pwd", clear_on_submit=True):
            old = st.text_input(t("old_pwd"), type="password")
            new = st.text_input(t("new_pwd"), type="password", help=t("pwd_short"))
            if st.form_submit_button(t("save"), type="primary"):
                try:
                    api.post("/api/auth/password", {"old_password": old, "new_password": new})
                    st.toast(t("saved"))
                except api.ApiError as e:
                    st.error(e.detail)


def render_documents(patient_id: int | None = None):
    st.header(t("m_docs"))
    with st.container(border=True):
        st.markdown(f"#### {t('docs_consent')}")
        st.markdown(ui.badge("normal", t("docs_accepted")), unsafe_allow_html=True)
        with st.expander(t("consent_title")):
            st.markdown(t("consent_text"))
    with st.container(border=True):
        st.markdown(f"#### {t('docs_privacy')}")
        for item in t("privacy_list").split(" · "):
            st.markdown(f"- {item}")
    if st.session_state["user"]["role"] == "patient" or patient_id:
        with st.container(border=True):
            st.markdown(f"#### {t('docs_reports')}")
            export_block("month", patient_id, key="docexp")


def render_support():
    """Техподдержка — компактно и столбцом (ТЗ)."""
    from i18n import lang
    L = LT[lang()]
    st.header(t("m_support"))
    _, mid, _ = st.columns([1, 1.4, 1])
    with mid, st.container(border=True):
        st.caption(L["support_text"])
        st.markdown(ui.kv(L["phone"], SUPPORT_PHONE) + ui.kv(L["email"], SUPPORT_EMAIL)
                    + ui.kv(L["hours"], SUPPORT_HOURS or L["hours_v"]), unsafe_allow_html=True)
