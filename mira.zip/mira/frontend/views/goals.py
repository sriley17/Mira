"""
Раздел «Задачи и цели» — ровно две цели: КАЛОРИИ и СОН.
Обе считаются устройством автоматически (калории — из измерений за сегодня, сон — из анализа
последней ночи), поэтому пациенту ничего не нужно вводить. Можно только поменять само целевое число.
Ниже — график выполнения за неделю: столбики — факт, линия — цель.
"""
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

import api
import ui
from i18n import t

META = {"calories": ("g_calories", "kcal_day", 200, 6000, 100.0),
        "sleep": ("g_sleep", "sleep_h_night", 4.0, 12.0, 0.5)}


def _num(v) -> str:
    if v is None:
        return "—"
    return f"{v:.0f}" if abs(v - round(v)) < 0.05 else f"{v:.1f}"


def _week_chart(hist: pd.DataFrame, kind: str):
    col, target = kind, f"{kind}_target"
    fig = go.Figure(go.Bar(x=hist["label"], y=hist[col], marker_color=ui.accent()))
    if hist[target].notna().any():
        fig.add_trace(go.Scatter(x=hist["label"], y=hist[target], mode="lines",
                                 line=dict(color=ui.pal()["muted"], width=2, dash="dot")))
    title, unit = t(META[kind][0]), t(META[kind][1])
    ui.plot(ui.style_fig(fig, 220, f"{title} · {unit}"), key=f"gw_{kind}")


def render(patient_id: int | None = None):
    st.header(t("m_goals"))
    try:
        data = api.get("/api/goals", patient_id=patient_id)
    except api.ApiError as e:
        st.error(e.detail)
        return
    hist = pd.DataFrame(data["history"])
    if len(hist):
        hist["label"] = pd.to_datetime(hist["date"]).dt.strftime("%d.%m")
    cols = st.columns(2)
    for col, g in zip(cols, data["today"]):
        title_key, unit_key, lo, hi, step = META[g["kind"]]
        with col, st.container(border=True):
            badge = ui.badge("normal", t("done")) if g["done"] else ""
            st.markdown(f"**{t(title_key)}** {badge}", unsafe_allow_html=True)
            st.markdown(f"<div class='mb-big'>{_num(g['value'])}<small> / {_num(g['target'])} {t(unit_key)}</small>"
                        f"</div>{ui.progress_bar(g['pct'])}", unsafe_allow_html=True)
            st.caption(t("auto_tracked"))
            if len(hist):
                _week_chart(hist, g["kind"])
            with st.popover(t("set_target"), width="stretch"):
                val = st.number_input(t(unit_key), min_value=float(lo), max_value=float(hi), value=float(g["target"]),
                                      step=step, key=f"gt_{g['kind']}")
                if st.button(t("save"), key=f"gs_{g['kind']}", type="primary"):
                    try:
                        api.put(f"/api/goals/{g['kind']}" + (f"?patient_id={patient_id}" if patient_id else ""),
                                {"target": val})
                        st.rerun()
                    except api.ApiError as e:
                        st.error(e.detail)
