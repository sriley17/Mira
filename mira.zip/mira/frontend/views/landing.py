"""
Первый слой сайта — ИНФОРМАЦИОННАЯ СТРАНИЦА (лендинг).

Сайт «двухслойный»:
  1 слой — эта страница: что такое MIRA (уникальные возможности), как это работает, скриншоты,
           роли и возможности, зачем создано, техподдержка (компактно, столбцом) и подвал
           «© 2026 MIRA. Все данные защищены». Карточки плавно появляются и приподнимаются при наведении,
           линия пульса на иллюстрации «рисуется» — анимации только здесь, кабинеты остаются строгими.
  2 слой — кнопки «Войти» / «Регистрация» справа вверху ведут в кабинет:
           выбор роли (пациент / врач) -> форма входа или регистрации.

Тексты страницы — в словаре LT на трёх языках. Контакты поддержки задаются переменными
окружения MIRA_SUPPORT_PHONE / MIRA_SUPPORT_EMAIL / MIRA_SUPPORT_HOURS (подставьте свои).
Все тексты — наши собственные константы, пользовательских данных здесь нет.
"""
import os

import streamlit as st

import ui
from i18n import lang

SUPPORT_PHONE = os.getenv("MIRA_SUPPORT_PHONE", "+998 (71) 000-00-00")
SUPPORT_EMAIL = os.getenv("MIRA_SUPPORT_EMAIL", "support@mira.uz")
SUPPORT_HOURS = os.getenv("MIRA_SUPPORT_HOURS", "")

LT = {
    "ru": {
        "nav": ["О MIRA", "Как это работает", "Роли", "Зачем", "Поддержка"],
        "login": "Войти", "register": "Регистрация",
        "uniq": [("Врач узнаёт первым", "При критических показателях сигнал сразу уходит врачу и в скорую 103 с координатами GPS — пациента не пугаем."),
                 ("SMS о лекарствах", "Напоминание приходит на телефон точно по расписанию — даже без интернета и смартфона."),
                 ("Сон + погода + УФ", "Анализ сна по пульсу и SpO₂ с учётом жары, ультрафиолета и воздуха в комнате."),
                 ("«Можно ли на улицу?»", "ИИ советует, выходить ли сегодня и нужна ли маска — по погоде, воздуху и состоянию."),
                 ("Локальный ИИ", "Искусственный интеллект работает на сервере клиники — данные не уходят в облако."),
                 ("Защита как в банке", "Проверка лица MyID, вход через OneID, одно устройство на аккаунт, шифрование.")],
        "shots_h": "Как это выглядит",
        "shots": ["Кабинет пациента: показатели в реальном времени", "Анализ сна с погодой и УФ",
                  "Лекарства и SMS-напоминания", "Кабинет врача: пациенты и тревоги"],
        "about_h": "Что такое MIRA",
        "about": "MIRA — Medical Intelligent Rehabilitation Assistant — портал домашней реабилитации. Носимое "
                 "устройство измеряет пульс, давление, сахар, дыхание, SpO₂, калории и температуру, а портал "
                 "превращает эти цифры в понятные графики, советы и сигналы для врача.",
        "facts": [("8", "показателей в реальном времени"), ("3", "языка: UZ · RU · EN"), ("24/7", "наблюдение и SMS-напоминания")],
        "how_h": "Как это работает",
        "steps": [("Регистрация", "Пациент создаёт аккаунт, врач проверяет и подтверждает его."),
                  ("Устройство", "Браслет MIRA отправляет показатели на защищённый сервер каждые несколько секунд."),
                  ("Анализ", "Система строит отчёты, анализирует сон, напоминает о лекарствах, локальный ИИ даёт советы."),
                  ("Врач рядом", "Врач видит пациентов онлайн и первым получает тревогу; при опасности вызывается скорая.")],
        "roles_h": "Роли и возможности",
        "patient": "Пациент", "doctor": "Врач",
        "p_list": ["Показатели онлайн и отчёты за день, неделю, месяц", "Анализ сна с погодой и УФ",
                   "Лекарства и SMS-напоминания", "Цели по калориям и сну", "Локальный ИИ-ассистент: советы и «можно ли на улицу»",
                   "Запись к врачу и ответы врача", "GPS и состояние устройства"],
        "d_list": ["Одобрение новых пациентов", "Критические тревоги и автоматический вызов скорой",
                   "Назначение лекарств и контроль приёма", "Клинический ИИ-аналитик: риск, тренды, находки",
                   "Анкеты пациентов и медкарта Dmed", "Управление записью на приём", "Экспорт отчётов PDF / Excel"],
        "why_h": "Почему мы это создали",
        "why": "После инсульта, инфаркта или операции самое сложное начинается дома: врач далеко, а изменения "
               "в самочувствии легко пропустить. Пожилые люди забывают о лекарствах, родственники не всегда рядом. "
               "MIRA соединяет пациента и врача каждый день: устройство следит, система напоминает, врач реагирует вовремя.",
        "why_points": ["Меньше повторных госпитализаций", "Спокойствие пациента: тревоги видит врач, а не он",
                       "Данные остаются в клинике — ИИ работает локально"],
        "support_h": "Техническая поддержка", "phone": "Телефон", "email": "Email", "hours": "Часы работы",
        "hours_v": "Пн–Сб, 09:00–18:00",
        "support_text": "Поможем подключить устройство, восстановить доступ и разобраться с порталом.",
        "footer": "© 2026 MIRA. Все данные защищены.",
        "cta": "Начать",
    },
    "uz": {
        "nav": ["MIRA haqida", "Qanday ishlaydi", "Rollar", "Nima uchun", "Yordam"],
        "login": "Kirish", "register": "Ro'yxatdan o'tish",
        "uniq": [("Shifokor birinchi biladi", "Kritik ko'rsatkichlarda signal darhol shifokorga va 103 ga GPS koordinatalari bilan ketadi — bemorni qo'rqitmaymiz."),
                 ("Dorilar haqida SMS", "Eslatma telefonga aynan jadval bo'yicha keladi — internet va smartfonsiz ham."),
                 ("Uyqu + ob-havo + UB", "Puls va SpO₂ bo'yicha uyqu tahlili, issiqlik, ultrabinafsha va xona havosi hisobga olinadi."),
                 ("«Tashqariga chiqsam bo'ladimi?»", "AI bugun chiqish kerakmi va niqob kerakmi — ob-havo, havo va holatga qarab maslahat beradi."),
                 ("Mahalliy AI", "Sun'iy intellekt klinika serverida ishlaydi — ma'lumotlar bulutga chiqmaydi."),
                 ("Bankdagidek himoya", "MyID yuz tekshiruvi, OneID orqali kirish, bitta qurilma, shifrlash.")],
        "shots_h": "Qanday ko'rinadi",
        "shots": ["Bemor kabineti: real vaqtdagi ko'rsatkichlar", "Ob-havo va UB bilan uyqu tahlili",
                  "Dorilar va SMS-eslatmalar", "Shifokor kabineti: bemorlar va signallar"],
        "about_h": "MIRA nima",
        "about": "MIRA — Medical Intelligent Rehabilitation Assistant — uyda reabilitatsiya portali. Taqiladigan "
                 "qurilma puls, bosim, qand, nafas, SpO₂, kaloriya va haroratni o'lchaydi, portal esa bu raqamlarni "
                 "tushunarli grafiklar, maslahatlar va shifokor uchun signallarga aylantiradi.",
        "facts": [("8", "ko'rsatkich real vaqtda"), ("3", "til: UZ · RU · EN"), ("24/7", "kuzatuv va SMS-eslatmalar")],
        "how_h": "Qanday ishlaydi",
        "steps": [("Ro'yxatdan o'tish", "Bemor akkaunt ochadi, shifokor uni tekshiradi va tasdiqlaydi."),
                  ("Qurilma", "MIRA bilaguzugi ko'rsatkichlarni har bir necha soniyada himoyalangan serverga yuboradi."),
                  ("Tahlil", "Tizim hisobotlar tuzadi, uyquni tahlil qiladi, dorilarni eslatadi, mahalliy AI maslahat beradi."),
                  ("Shifokor yonida", "Shifokor bemorlarni onlayn ko'radi va signalni birinchi oladi; xavfda tez yordam chaqiriladi.")],
        "roles_h": "Rollar va imkoniyatlar",
        "patient": "Bemor", "doctor": "Shifokor",
        "p_list": ["Onlayn ko'rsatkichlar va kun, hafta, oy hisobotlari", "Ob-havo va UB bilan uyqu tahlili",
                   "Dorilar va SMS-eslatmalar", "Kaloriya va uyqu maqsadlari", "Mahalliy AI: maslahatlar va «tashqariga chiqsam bo'ladimi»",
                   "Shifokor qabuliga yozilish va javoblar", "GPS va qurilma holati"],
        "d_list": ["Yangi bemorlarni tasdiqlash", "Kritik signallar va tez yordamni avtomatik chaqirish",
                   "Dori tayinlash va qabulni nazorat qilish", "Klinik AI-tahlilchi: xavf, trendlar, topilmalar",
                   "Bemor anketalari va Dmed tibbiy kartasi", "Qabulga yozilishni boshqarish", "PDF / Excel eksport"],
        "why_h": "Nega biz buni yaratdik",
        "why": "Insult, infarkt yoki operatsiyadan keyin eng qiyini uyda boshlanadi: shifokor uzoqda, holatdagi "
               "o'zgarishlarni o'tkazib yuborish oson. Keksalar dorilarni unutadi, yaqinlar har doim ham yonida emas. "
               "MIRA bemor va shifokorni har kuni bog'laydi: qurilma kuzatadi, tizim eslatadi, shifokor o'z vaqtida javob beradi.",
        "why_points": ["Qayta kasalxonaga yotqizish kamroq", "Bemor xotirjam: signallarni u emas, shifokor ko'radi",
                       "Ma'lumotlar klinikada qoladi — AI mahalliy ishlaydi"],
        "support_h": "Texnik yordam", "phone": "Telefon", "email": "Email", "hours": "Ish vaqti",
        "hours_v": "Du–Sh, 09:00–18:00",
        "support_text": "Qurilmani ulash, kirishni tiklash va portal bilan ishlashda yordam beramiz.",
        "footer": "© 2026 MIRA. Barcha ma'lumotlar himoyalangan.",
        "cta": "Boshlash",
    },
    "en": {
        "nav": ["About", "How it works", "Roles", "Why", "Support"],
        "login": "Sign in", "register": "Register",
        "uniq": [("The doctor knows first", "Critical readings instantly alert the doctor and emergency services (103) with GPS — the patient is not frightened."),
                 ("Medicine SMS", "Reminders reach the phone right on schedule — even without internet or a smartphone."),
                 ("Sleep + weather + UV", "Sleep analysis from pulse and SpO₂, taking heat, UV and room air into account."),
                 ("“Can I go outside?”", "The AI advises whether to go out today and whether a mask is needed — from weather, air and condition."),
                 ("Local AI", "The AI runs on the clinic's server — data never leaves for the cloud."),
                 ("Bank-grade protection", "MyID face check, OneID sign-in, one device per account, encryption.")],
        "shots_h": "What it looks like",
        "shots": ["Patient dashboard: live vitals", "Sleep analysis with weather and UV",
                  "Medicines and SMS reminders", "Doctor dashboard: patients and alerts"],
        "about_h": "What is MIRA",
        "about": "MIRA — Medical Intelligent Rehabilitation Assistant — is a home rehabilitation portal. A wearable "
                 "measures pulse, blood pressure, glucose, breathing, SpO₂, calories and temperature, and the portal "
                 "turns these numbers into clear charts, advice and signals for the doctor.",
        "facts": [("8", "vitals in real time"), ("3", "languages: UZ · RU · EN"), ("24/7", "monitoring and SMS reminders")],
        "how_h": "How it works",
        "steps": [("Sign-up", "The patient creates an account; the doctor reviews and approves it."),
                  ("Device", "The MIRA wristband sends readings to a secure server every few seconds."),
                  ("Analysis", "The system builds reports, analyses sleep, reminds about medicines; the local AI gives advice."),
                  ("Doctor nearby", "The doctor sees patients online and gets alerts first; emergencies trigger an ambulance call.")],
        "roles_h": "Roles and features",
        "patient": "Patient", "doctor": "Doctor",
        "p_list": ["Live vitals and daily, weekly, monthly reports", "Sleep analysis with weather and UV",
                   "Medicines and SMS reminders", "Calorie and sleep goals", "Local AI assistant: advice and “can I go outside”",
                   "Appointments and doctor's replies", "GPS and device status"],
        "d_list": ["Approving new patients", "Critical alerts and automatic ambulance call",
                   "Prescribing medicines and tracking intake", "Clinical AI analyst: risk, trends, findings",
                   "Patient profiles and Dmed record", "Managing appointments", "PDF / Excel export"],
        "why_h": "Why we built it",
        "why": "After a stroke, heart attack or surgery, the hardest part begins at home: the doctor is far away and "
               "changes are easy to miss. Older people forget their medicines and relatives are not always there. "
               "MIRA connects patient and doctor every day: the device watches, the system reminds, the doctor reacts in time.",
        "why_points": ["Fewer repeat hospitalisations", "Calm patients: alerts go to the doctor, not to them",
                       "Data stays in the clinic — the AI runs locally"],
        "support_h": "Technical support", "phone": "Phone", "email": "Email", "hours": "Hours",
        "hours_v": "Mon–Sat, 09:00–18:00",
        "support_text": "We help connect the device, restore access and get around the portal.",
        "footer": "© 2026 MIRA. All data is protected.",
        "cta": "Get started",
    },
}

CSS = """
<style>
.mb-sec {margin: 2.6rem 0 0;}
.mb-sec h2 {font-size:1.55rem; margin:0 0 1rem; font-weight:720;}
.mb-sec p.txt {color:MUTED; font-size:1rem; line-height:1.65; max-width:820px;}
.mb-uniqs {display:grid; grid-template-columns:repeat(3,1fr); gap:1rem; margin-top:1.2rem;}
.mb-uniq {background:CARD; border:1px solid BORDER; border-radius:18px; padding:1.2rem 1.3rem; position:relative; overflow:hidden;}
.mb-uniq::after {content:""; position:absolute; right:-30px; top:-30px; width:90px; height:90px; border-radius:50%;
                 background:ACCENT_SOFT;}
.mb-uniq b {display:block; font-size:1.08rem; margin-bottom:.35rem;} .mb-uniq span {color:MUTED; font-size:.95rem; line-height:1.55;}
.mb-uniq i {font-style:normal; color:ACCENT; font-weight:800; font-size:.85rem; letter-spacing:.1em;}
.mb-shots {display:grid; grid-template-columns:1fr 1fr; gap:1.2rem;}
.mb-shot {background:CARD; border:1px solid BORDER; border-radius:18px; padding:.6rem; overflow:hidden;}
.mb-shot img {width:100%; border-radius:12px; display:block;}
.mb-shot p {margin:.6rem .4rem .3rem; color:MUTED; font-size:.92rem;}
.mb-facts {display:grid; grid-template-columns:repeat(3,1fr); gap:.8rem; margin-top:1.1rem;}
.mb-fact {background:CARD; border:1px solid BORDER; border-radius:16px; padding:1rem 1.1rem;}
.mb-fact b {display:block; font-size:1.9rem; color:ACCENT; line-height:1.1;} .mb-fact span {color:MUTED; font-size:.88rem;}
.mb-steps {display:grid; grid-template-columns:repeat(4,1fr); gap:.8rem;}
.mb-step {background:CARD; border:1px solid BORDER; border-radius:16px; padding:1rem 1.1rem;}
.mb-step i {font-style:normal; display:inline-flex; width:30px; height:30px; border-radius:50%; align-items:center;
            justify-content:center; background:ACCENT_SOFT; color:ACCENT; font-weight:700; margin-bottom:.6rem;}
.mb-step b {display:block; margin-bottom:.3rem;} .mb-step span {color:MUTED; font-size:.88rem; line-height:1.5;}
.mb-roles {display:grid; grid-template-columns:1fr 1fr; gap:.8rem;}
.mb-role {background:CARD; border:1px solid BORDER; border-radius:16px; padding:1.1rem 1.3rem;}
.mb-role h3 {margin:0 0 .6rem; font-size:1.15rem;}
.mb-role li {color:MUTED; margin:.25rem 0; font-size:.93rem;}
.mb-why {background:HERO; border:1px solid BORDER; border-radius:20px; padding:1.6rem 1.8rem;}
.mb-why ul {margin:.8rem 0 0; padding-left:1.1rem;} .mb-why li {margin:.3rem 0;}
.mb-support {max-width:420px; display:flex; flex-direction:column; gap:.55rem;}
.mb-support div {background:CARD; border:1px solid BORDER; border-radius:14px; padding:.7rem 1rem;}
.mb-support span {display:block; color:MUTED; font-size:.8rem; margin-bottom:.2rem;} .mb-support b {font-size:1rem;}
.mb-support a {color:ACCENT; text-decoration:none;}
.mb-footer {margin:2.8rem 0 .5rem; padding-top:1.1rem; border-top:1px solid BORDER; display:flex;
            justify-content:space-between; color:MUTED; font-size:.85rem; flex-wrap:wrap; gap:.5rem;}
.mb-navlinks {display:flex; gap:1.2rem; flex-wrap:wrap; font-size:.9rem;}
.mb-navlinks a {color:MUTED; text-decoration:none;} .mb-navlinks a:hover {color:ACCENT;}
@media (max-width: 768px) {
  .mb-facts, .mb-steps, .mb-roles, .mb-uniqs, .mb-shots {grid-template-columns:1fr;}
  .mb-navlinks {display:none;}
}
</style>
"""


SHOTS = ["patient_live.jpg", "sleep.jpg", "medications.jpg", "doctor.jpg"]


@st.cache_data(show_spinner=False)
def _shots() -> list[str]:
    """Скриншоты портала в base64 (читаются с диска один раз и кэшируются)."""
    import base64
    from pathlib import Path
    folder = Path(__file__).resolve().parent.parent / "assets" / "screens"
    out = []
    for name in SHOTS:
        f = folder / name
        if f.exists():
            out.append(base64.b64encode(f.read_bytes()).decode())
    return out if len(out) == len(SHOTS) else []


def _css() -> None:
    p = ui.pal()
    css = CSS
    for k, v in (("HERO", p["hero"]), ("ACCENT_SOFT", p["accent_soft"]), ("ACCENT", p["accent"]), ("CARD", p["card"]),
                 ("BORDER", p["border"]), ("MUTED", p["muted"])):
        css = css.replace(k, v)
    st.markdown(css, unsafe_allow_html=True)


def render(hero_html: str, on_login, on_register, lang_theme) -> None:
    """hero_html — готовый блок героя (из app.py), on_login/on_register — переходы во второй слой."""
    L = LT[lang()]
    _css()
    # ---- шапка: бренд слева, язык/тема и «Войти / Регистрация» справа
    c1, c2, c3, c4, c5 = st.columns([3.2, 2.6, 1.2, 1.2, 1.5], vertical_alignment="center")
    c1.markdown('<div class="mb-logo" style="margin:0"><i>M</i><div><b>MIRA</b><small>Medical Intelligent<br>'
                'Rehabilitation Assistant</small></div></div>', unsafe_allow_html=True)
    lang_theme(c2, c3)
    c4.button(L["login"], key="land_login", width="stretch", on_click=on_login)
    c5.button(L["register"], key="land_reg", width="stretch", type="primary", on_click=on_register)
    ids = ["about", "how", "roles", "why", "support"]
    st.markdown('<div class="mb-navlinks">' + "".join(f'<a href="#{i}">{n}</a>' for i, n in zip(ids, L["nav"]))
                + "</div>", unsafe_allow_html=True)

    st.markdown(hero_html, unsafe_allow_html=True)
    _, b1, b2, _ = st.columns([1, 1, 1, 1])
    b1.button(L["cta"], key="land_cta", type="primary", width="stretch", on_click=on_register)
    b2.button(L["login"], key="land_login2", width="stretch", on_click=on_login)

    # ---- 1. Что такое MIRA
    # ТЗ: показывать не «языки и обычные элементы», а то, чего нет у других
    uniq = "".join(f'<div class="mb-uniq"><i>0{n}</i><b>{a}</b><span>{b}</span></div>'
                   for n, (a, b) in enumerate(L["uniq"], 1))
    st.markdown(f'<div class="mb-sec" id="about"><h2>{L["about_h"]}</h2><p class="txt">{L["about"]}</p>'
                f'<div class="mb-uniqs">{uniq}</div></div>', unsafe_allow_html=True)
    # ---- 2. Как это работает
    steps = "".join(f'<div class="mb-step"><i>{n}</i><b>{a}</b><span>{b}</span></div>'
                    for n, (a, b) in enumerate(L["steps"], 1))
    st.markdown(f'<div class="mb-sec" id="how"><h2>{L["how_h"]}</h2><div class="mb-steps">{steps}</div></div>',
                unsafe_allow_html=True)
    # ---- скриншоты портала (файлы в frontend/assets/screens/)
    shots = _shots()
    if shots:
        cards = "".join(f'<div class="mb-shot"><img src="data:image/jpeg;base64,{b64}" alt=""><p>{cap}</p></div>'
                        for b64, cap in zip(shots, L["shots"]))
        st.markdown(f'<div class="mb-sec" id="shots"><h2>{L["shots_h"]}</h2><div class="mb-shots">{cards}</div></div>',
                    unsafe_allow_html=True)
    # ---- 3. Роли и возможности
    pl = "".join(f"<li>{x}</li>" for x in L["p_list"])
    dl = "".join(f"<li>{x}</li>" for x in L["d_list"])
    st.markdown(f'<div class="mb-sec" id="roles"><h2>{L["roles_h"]}</h2><div class="mb-roles">'
                f'<div class="mb-role"><h3>{L["patient"]}</h3><ul>{pl}</ul></div>'
                f'<div class="mb-role"><h3>{L["doctor"]}</h3><ul>{dl}</ul></div></div></div>', unsafe_allow_html=True)
    # ---- 4. Почему мы это создали
    wp = "".join(f"<li>{x}</li>" for x in L["why_points"])
    st.markdown(f'<div class="mb-sec" id="why"><h2>{L["why_h"]}</h2><div class="mb-why"><p class="txt">{L["why"]}</p>'
                f'<ul>{wp}</ul></div></div>', unsafe_allow_html=True)
    # ---- 5. Техподдержка — компактно, столбцом (ТЗ)
    hours = SUPPORT_HOURS or L["hours_v"]
    st.markdown(f'<div class="mb-sec" id="support"><h2>{L["support_h"]}</h2>'
                f'<p class="txt" style="margin-bottom:.8rem">{L["support_text"]}</p><div class="mb-support">'
                f'<div><span>{L["phone"]}</span><b><a href="tel:{ui.esc(SUPPORT_PHONE)}">{ui.esc(SUPPORT_PHONE)}</a></b></div>'
                f'<div><span>{L["email"]}</span><b><a href="mailto:{ui.esc(SUPPORT_EMAIL)}">{ui.esc(SUPPORT_EMAIL)}</a></b></div>'
                f'<div><span>{L["hours"]}</span><b>{ui.esc(hours)}</b></div></div></div>', unsafe_allow_html=True)
    # ---- подвал
    st.markdown(f'<div class="mb-footer"><span>{L["footer"]}</span><span>Medical Intelligent Rehabilitation Assistant'
                f'</span></div>', unsafe_allow_html=True)
