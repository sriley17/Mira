"""
Профиль и личные данные.

render_own()           — «Профиль»:
                          пациент: анкета (кто он, где живёт и работает, контакт родственника, паспорт),
                                   фото паспорта, телефон для SMS, ПИНФЛ, статус проверки MyID
                                   (карточка врача вынесена в отдельный раздел «Мой врач»);
                          врач:    специальность, клиника, кабинет, стаж, часы приёма, фото в форме.
render_patient(pid)    — у врача «Данные пациента»: анкета и фото паспорта ВЫБРАННОГО пациента.

Кто что видит, решает сервер (routers/profile.py): пациент — только себя и своего врача,
врач — только своих пациентов. Интерфейс лишь показывает то, что сервер разрешил отдать.
"""
import streamlit as st

import api
import ui
from i18n import t

PATIENT_FIELDS = ["middle_name", "birth_date", "city", "address", "workplace", "position", "passport",
                  "emergency_name", "emergency_phone"]
DOCTOR_FIELDS = {"specialty": "specialty", "clinic": "clinic", "room": "room", "experience_years": "experience_years",
                 "hours": "hours_work", "phone": "work_phone"}


@st.cache_data(ttl=300, show_spinner=False)
def _photo(token: str, user_id: int, version: int) -> bytes | None:
    """Фото кэшируется в памяти сервера Streamlit на 5 минут (version сбрасывает кэш после загрузки)."""
    try:
        return api.get(f"/api/profile/{user_id}/photo")
    except api.ApiError:
        return None


def _show_photo(p: dict, caption: str):
    ver = st.session_state.get("_photo_ver", 0)
    img = _photo(st.session_state["token"], p["id"], ver) if p["has_photo"] else None
    if img:
        st.image(img, caption=caption, width="stretch")
    else:
        st.markdown(f"<div class='mb-card' style='min-height:180px;display:flex;align-items:center;justify-content:center'>"
                    f"<span class='mb-muted'>{t('no_photo')}</span></div>", unsafe_allow_html=True)


def _kv_table(fields: dict, keys: list[str], labels: dict | None = None) -> str:
    labels = labels or {}
    return "".join(ui.kv(t(labels.get(k, k)), fields.get(k) or "—") for k in keys)


def _upload(kind_label: str):
    f = st.file_uploader(t("upload_photo"), type=["jpg", "jpeg", "png", "webp"], key="photo_up")
    if f is not None and st.button(t("save"), key="photo_save", type="primary"):
        try:
            api.upload("/api/profile/photo", f.name, f.getvalue(), f.type or "image/jpeg")
            st.session_state["_photo_ver"] = st.session_state.get("_photo_ver", 0) + 1
            st.toast(t("saved"))
            st.rerun()
        except api.ApiError as e:
            st.error(e.detail)


def _patient_form(fields: dict, key: str, target: str):
    """Форма анкеты пациента. target — куда сохранять: '/api/profile' или '/api/profile/{id}'."""
    with st.form(key):
        c1, c2 = st.columns(2)
        vals = {}
        for i, k in enumerate(PATIENT_FIELDS):
            col = c1 if i % 2 == 0 else c2
            hint = "YYYY-MM-DD" if k == "birth_date" else "AA1234567" if k == "passport" else ""
            vals[k] = col.text_input(t(k), value=fields.get(k, ""), placeholder=hint)
        if st.form_submit_button(t("save"), type="primary"):
            body = {k: (v.strip().upper() if k == "passport" else v.strip()) for k, v in vals.items()}
            try:
                api.put(target, body)
                st.toast(t("saved"))
                st.rerun()
            except api.ApiError as e:
                st.error(e.detail)


def render_own():
    user = st.session_state["user"]
    st.header(t("personal_info"))
    p = api.get(f"/api/profile/{user['id']}")
    f = p["fields"]
    left, right = st.columns([1, 2])
    is_doc = user["role"] == "doctor"
    with left:
        _show_photo(p, t("photo_uniform") if is_doc else t("photo_passport"))
        _upload(t("photo_uniform") if is_doc else t("photo_passport"))
    with right, st.container(border=True):
        st.markdown(f"#### {ui.esc(p['last_name'])} {ui.esc(p['first_name'])} {ui.esc(f.get('middle_name', ''))}")
        st.markdown(ui.kv(t("age"), p["age"]) + ui.kv(t("gender"), t(p["gender"])) + ui.kv("Email", p["email"] or "—")
                    + ui.kv(t("phone"), p["phone_masked"] or "—")
                    + ui.kv(t("id_status"), "MyID · " + t("id_verified")), unsafe_allow_html=True)
        if is_doc:
            st.markdown(_kv_table(f, list(DOCTOR_FIELDS), DOCTOR_FIELDS), unsafe_allow_html=True)
        else:
            st.markdown(_kv_table(f, PATIENT_FIELDS[1:]), unsafe_allow_html=True)
        st.caption(t("privacy_note"))

    with st.expander(t("personal"), expanded=not f):
        if is_doc:
            with st.form("doc_prof"):
                c1, c2 = st.columns(2)
                vals = {k: (c1 if i % 2 == 0 else c2).text_input(t(lbl), value=str(f.get(k, "") or ""))
                        for i, (k, lbl) in enumerate(DOCTOR_FIELDS.items())}
                if st.form_submit_button(t("save"), type="primary"):
                    body = {k: v.strip() for k, v in vals.items() if v.strip()}
                    if "experience_years" in body:
                        body["experience_years"] = int(body["experience_years"]) if body["experience_years"].isdigit() else None
                    try:
                        api.put("/api/profile", body)
                        st.toast(t("saved"))
                        st.rerun()
                    except api.ApiError as e:
                        st.error(e.detail)
        else:
            _patient_form(f, "pat_prof", "/api/profile")
            with st.form("contacts"):
                phone = st.text_input(t("phone"), placeholder=p["phone_masked"] or "+998 ...")
                pinfl = st.text_input(t("pinfl"), max_chars=14)
                if st.form_submit_button(t("save")):
                    body = {k: v for k, v in (("phone", phone), ("pinfl", pinfl)) if v}
                    try:
                        st.session_state["user"] = api.put("/api/auth/profile", body)
                        st.toast(t("saved"))
                    except api.ApiError as e:
                        st.error(e.detail)



def render_patient(patient_id: int):
    """Врач: полные данные своего пациента (кто он, где живёт и работает, паспорт, контакты)."""
    st.header(t("m_pinfo"))
    try:
        p = api.get(f"/api/profile/{patient_id}")
    except api.ApiError as e:
        st.error(e.detail)
        return
    f = p["fields"]
    left, right = st.columns([1, 2])
    with left:
        _show_photo(p, t("photo_passport"))
    with right, st.container(border=True):
        st.markdown(f"#### {ui.esc(p['last_name'])} {ui.esc(p['first_name'])} {ui.esc(f.get('middle_name', ''))}")
        st.markdown(ui.kv(t("age"), p["age"]) + ui.kv(t("gender"), t(p["gender"])) + ui.kv("Email", p["email"] or "—")
                    + ui.kv(t("phone"), p["phone_masked"] or "—") + ui.kv("ПИНФЛ / JShShIR", "••••••••••••••" if p["pinfl_set"] else "—")
                    + _kv_table(f, PATIENT_FIELDS[1:]), unsafe_allow_html=True)
        st.caption(t("privacy_note_doc"))
    with st.expander(t("personal")):
        _patient_form(f, "doc_edit_pat", f"/api/profile/{patient_id}")
    _doctor_notes(patient_id)


def _doctor_notes(patient_id: int):
    """Закрытые заметки врача: прогноз, подозрения, план. Пациенту НЕ видны (сервер отдаёт их только врачу)."""
    with st.container(border=True):
        st.markdown(f"#### {t('notes_h')}")
        st.caption(t("notes_hint"))
        with st.form("note", clear_on_submit=True):
            body = st.text_area(t("add_note"), height=90, max_chars=3000, label_visibility="collapsed")
            if st.form_submit_button(t("add_note"), type="primary") and body.strip():
                api.post("/api/notes", {"patient_id": patient_id, "body": body.strip()})
                st.rerun()
        for n in api.get("/api/notes", patient_id=patient_id):
            c1, c2 = st.columns([6, 1], vertical_alignment="center")
            c1.markdown(f"<span class='mb-muted'>{ui.fmt_local(n['created_at'], '%d.%m.%Y %H:%M')}</span>",
                        unsafe_allow_html=True)
            c1.write(n["body"])
            if n["mine"] and c2.button(t("delete"), key=f"nd{n['id']}", type="tertiary"):
                api.delete(f"/api/notes/{n['id']}")
                st.rerun()
