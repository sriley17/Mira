"""
Ограниченный режим для НОВОГО устройства.

Сценарий (по просьбе команды): с нового телефона или компьютера войти можно, но в кабинете
ничего не видно — медицинские данные сервер не отдаёт (403 device_pending). Полноценная работа
начинается после подтверждения устройства в «Профиле»:
  1) проверкой лица (MyID) прямо на этом устройстве — сначала окно о камере, потом камера;
  2) или разрешением с первого устройства (уведомления / настройки -> «Разрешить»).
"""
import streamlit as st

import api
import ui
from i18n import t


def empty_state():
    """Любой раздел, кроме «Профиля», в ограниченном режиме — пустой экран с подсказкой."""
    _, mid, _ = st.columns([1, 2, 1])
    with mid:
        st.markdown(f'<div class="mb-pending">{ui.badge("warning", t("device_pending_st"))}'
                    f'<h2>{t("dev_limited_title")}</h2><p>{t("dev_limited_text")}</p></div>', unsafe_allow_html=True)
        st.button(t("go_profile"), type="primary", width="stretch",
                  on_click=lambda: st.session_state.update(page="m_profile"))


@st.dialog(" ")
def _camera_permission():
    st.markdown(f"### {t('id_cam_title')}")
    st.write(t("id_cam_text"))
    if st.button(t("id_cam_ok"), type="primary", width="stretch"):
        st.session_state["_dev_cam_ok"] = True
        st.rerun()


def _refresh_me() -> bool:
    """Спросить сервер, не подтвердили ли устройство (например, с первого устройства)."""
    try:
        me = api.get("/api/auth/me")
    except api.ApiError:
        return False
    st.session_state["user"].update(me)
    ui.save_session()
    return me.get("device_status") == "approved"


def render_profile():
    """«Профиль» в ограниченном режиме: только подтверждение устройства."""
    st.header(t("m_profile"))
    with st.container(border=True):
        st.markdown(f"#### {t('dev_limited_title')}")
        st.write(t("dev_limited_text"))
    with st.container(border=True):
        st.markdown(f"**{t('dev_way1')}**")
        st.caption(t("id_tips"))
        if not st.session_state.get("_dev_cam_ok"):
            if st.button(t("id_start"), type="primary", key="dev_face"):
                _camera_permission()
        else:
            shot = st.camera_input(t("id_title"), label_visibility="collapsed", key="dev_cam")
            if shot is not None:
                try:
                    res = api.upload("/api/identity/verify-device", "selfie.jpg", shot.getvalue(), "image/jpeg")
                except api.ApiError as e:
                    st.error(e.detail)
                    return
                if res["result"] == "verified":
                    st.session_state["user"]["device_status"] = "approved"
                    ui.save_session()
                    st.toast(t("dev_ok"))
                    st.rerun()
                else:
                    st.warning(t("id_fail").format(r=res.get("reason") or res["result"]))
    with st.container(border=True):
        st.markdown(f"**{t('dev_way2')}**")
        if st.button(t("dev_check"), key="dev_recheck"):
            if _refresh_me():
                st.toast(t("dev_ok"))
                st.rerun()
            else:
                st.info(t("dev_still"))
