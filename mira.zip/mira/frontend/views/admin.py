"""
Панель врача: пациенты, заявки на регистрацию, тревоги, журнал аудита.
Цвета статусов — приглушённые метки-«бейджи», без эмодзи (ТЗ).
"""
import pandas as pd
import streamlit as st

import api
import ui
from i18n import mname, t

STATUS_TEXT = {"critical": "critical", "warning": "warning", "normal": "normal"}


def render_patients():
    st.header(t("m_admin"))
    patients = api.get("/api/admin/patients")
    api.patients.clear()
    pending = api.get("/api/admin/pending")

    k1, k2, k3, k4 = st.columns(4)
    for col, label, value in ((k1, t("patients_total"), len(patients)),
                              (k2, t("in_critical"), sum(p["status"] == "critical" for p in patients)),
                              (k3, t("devices_online"), sum(p["device_online"] for p in patients)),
                              (k4, t("m_approvals"), len(pending))):
        with col, st.container(border=True):
            st.metric(label, value)

    st.subheader(t("my_patients"))
    if patients:
        df = pd.DataFrame(patients)
        df["status"] = df["status"].map(lambda s: t(STATUS_TEXT.get(s, "normal")))
        df["device_online"] = df["device_online"].map({True: t("online"), False: t("offline")})
        df["last_reading"] = ui.to_local(df["last_reading"]).dt.strftime("%d.%m %H:%M")
        view = df[["name", "age", "status", "heart_rate", "bp", "glucose", "critical_24h", "battery",
                   "device_online", "last_reading"]].rename(columns={
            "name": t("name"), "age": t("age"), "status": t("status"), "heart_rate": t("pulse"), "bp": t("bp"),
            "glucose": t("sugar"), "critical_24h": t("crit24"), "battery": t("battery") + ", %",
            "device_online": t("device"), "last_reading": t("last_seen")})
        st.dataframe(view, hide_index=True, width="stretch")

        names = {p["id"]: p["name"] for p in patients}
        c1, c2, c3 = st.columns([2, 1, 1], vertical_alignment="bottom")
        pid = c1.selectbox(t("select_patient"), list(names), format_func=names.get, key="adm_pick")
        if c2.button(t("open_patient"), width="stretch", type="primary"):
            st.session_state["patient_id"] = pid
            st.session_state["_goto"] = "m_analyses"
            st.rerun()
        if c3.button(t("remove"), width="stretch"):
            api.delete(f"/api/admin/patients/{pid}")
            if st.session_state.get("patient_id") == pid:
                st.session_state.pop("patient_id")
            st.rerun()
    else:
        st.info(t("no_patients"))

    st.subheader(t("add_patient"))
    with st.form("assign", clear_on_submit=True):
        c1, c2 = st.columns([3, 1], vertical_alignment="bottom")
        email = c1.text_input(t("email"), placeholder="patient@example.com")
        if c2.form_submit_button(t("add"), width="stretch") and email:
            try:
                api.post("/api/admin/patients/assign", {"email": email})
                st.toast(t("added"))
                st.rerun()
            except api.ApiError as e:
                st.error(e.detail)

    free = api.get("/api/admin/unassigned")
    if free:
        st.caption(t("unassigned"))
        for p in free:
            c1, c2 = st.columns([3, 1], vertical_alignment="center")
            c1.write(f"{p['name']} · {p['email']}")
            if c2.button(t("add"), key=f"as{p['id']}", width="stretch"):
                api.post("/api/admin/patients/assign", {"email": p["email"]})
                st.rerun()


def render_approvals():
    """ТЗ: пациент получает доступ только после одобрения врача."""
    st.header(t("m_approvals"))
    rows = api.get("/api/admin/pending")
    if not rows:
        st.info(t("no_requests"))
        return
    for p in rows:
        with st.container(border=True):
            c1, c2, c3 = st.columns([3, 1, 1], vertical_alignment="center")
            gender = t(p["gender"])
            c1.markdown(f"**{ui.esc(p['name'])}** · {p['age']} · {gender}  \n"
                        f"<span class='mb-muted'>{ui.esc(p['email'])} · {t('registered')}: "
                        f"{ui.fmt_local(p['created_at'], '%d.%m.%Y %H:%M')}</span>", unsafe_allow_html=True)
            if c2.button(t("approve"), key=f"ap{p['id']}", type="primary", width="stretch"):
                api.post(f"/api/admin/patients/{p['id']}/approve")
                api.patients.clear()
                st.toast(t("saved"))
                st.rerun()
            if c3.button(t("reject"), key=f"rj{p['id']}", width="stretch"):
                api.post(f"/api/admin/patients/{p['id']}/reject", {"reason": None})
                st.rerun()


def render_alerts():
    st.header(t("m_alerts"))
    ui.request_push_permission_button(t("enable_push"))
    alerts = api.get("/api/admin/alerts", limit=100)
    if not alerts:
        st.info("—")
        return
    df = pd.DataFrame(alerts)
    df["ts"] = ui.to_local(df["ts"]).dt.strftime("%d.%m %H:%M:%S")
    df["metric"] = df["metric"].map(mname)
    df["level"] = df["level"].map(t)
    df["ambulance_called"] = df["ambulance_called"].map({True: "103", False: ""})
    df["acknowledged"] = df["acknowledged"].map({True: t("done"), False: ""})
    st.dataframe(df[["ts", "patient", "metric", "value", "level", "ambulance_called", "acknowledged"]].rename(columns={
        "ts": t("time"), "patient": t("patient"), "metric": t("metric"), "value": t("value"), "level": t("level"),
        "ambulance_called": t("ambulance"), "acknowledged": t("ack")}), hide_index=True, width="stretch")
    open_ids = [a["id"] for a in alerts if not a["acknowledged"]]
    if open_ids and st.button(f"{t('ack')} ({len(open_ids)})", type="primary"):
        for i in open_ids:
            api.post(f"/api/admin/alerts/{i}/ack")
        st.rerun()


ACTIONS = {
    "login_ok": ("Вход", "Kirish", "Sign-in"), "login_fail": ("Неудачный вход", "Muvaffaqiyatsiz kirish", "Failed sign-in"),
    "logout": ("Выход", "Chiqish", "Sign-out"), "register": ("Регистрация", "Ro'yxatdan o'tish", "Registration"),
    "approve_patient": ("Одобрение пациента", "Bemorni tasdiqlash", "Patient approved"),
    "reject_patient": ("Отклонение пациента", "Bemorni rad etish", "Patient declined"),
    "dmed_view": ("Просмотр Dmed", "Dmed ko'rish", "Dmed viewed"),
    "med_prescribe": ("Назначение лекарства", "Dori tayinlash", "Medicine prescribed"),
    "med_stop": ("Отмена лекарства", "Dorini bekor qilish", "Medicine stopped"),
    "ack_alert": ("Тревога принята", "Signal qabul qilindi", "Alert acknowledged"),
    "device_credentials": ("Просмотр ключа устройства", "Qurilma kalitini ko'rish", "Device key viewed"),
    "device_rotate_key": ("Новый ключ устройства", "Qurilmaning yangi kaliti", "Device key rotated"),
    "device_auth_fail": ("Чужое устройство отклонено", "Begona qurilma rad etildi", "Unknown device rejected"),
    "appt_request": ("Заявка на приём", "Qabulga ariza", "Appointment requested"),
    "appt_approved": ("Приём подтверждён", "Qabul tasdiqlandi", "Appointment approved"),
    "appt_declined": ("Приём отклонён", "Qabul rad etildi", "Appointment declined"),
    "profile_update": ("Изменение профиля", "Profilni o'zgartirish", "Profile updated"),
    "password_change": ("Смена пароля", "Parolni almashtirish", "Password changed"),
}


def render_audit():
    """Журнал аудита: кто и когда входил, одобрял, смотрел медкарту."""
    from i18n import _IDX, lang
    st.header(t("m_audit"))
    rows = api.get("/api/admin/audit", limit=200)
    if not rows:
        st.info("—")
        return
    df = pd.DataFrame(rows)
    df["ts"] = ui.to_local(df["ts"]).dt.strftime("%d.%m %H:%M:%S")
    for col in ("user", "target", "detail", "ip"):
        df[col] = df[col].fillna("").astype(str)   # смешанные типы -> строки (для таблицы)
    df["action"] = df["action"].map(lambda a: ACTIONS.get(a, (a, a, a))[_IDX[lang()]])
    st.dataframe(df[["ts", "user", "action", "target", "ip", "detail"]].rename(columns={
        "ts": t("time"), "user": t("user"), "action": t("action"), "target": t("patient"), "ip": "IP", "detail": t("notes")}),
        hide_index=True, width="stretch")
