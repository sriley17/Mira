"""
ИИ-ассистент (пациент) / ИИ-аналитик (врач).

Два разных режима:
  • ПАЦИЕНТ — карточки «Что важно сейчас» (первая: можно ли выходить на улицу и нужна ли маска),
    строятся заново по свежей аналитике: показатели, тренд, сон, лекарства, погода, воздух, цели.
    Это заменяет раздел «Советы» (ТЗ: все советы даёт ИИ).
  • ВРАЧ — «Клиническая сводка»: риск, находки, что проверить, соблюдение режима, сон.
    Врачу не показываются бытовые советы пациенту — ему нужна аналитика для решений.
Ниже — чат с быстрыми вопросами и эффектом «печати».
"""
import time

import streamlit as st

import api
import ui
from i18n import lang, t


@st.cache_data(ttl=3600, show_spinner=False)
def _suggestions(lng: str, role: str, token: str) -> list[str]:
    try:
        return api.get("/api/ai/suggestions", lang=lng)
    except Exception:
        return []


def _typing(text: str):
    """Yield the answer word by word so it 'types' like a real chat."""
    for line in text.split("\n"):
        words = line.split(" ")
        for i, w in enumerate(words):
            yield w + (" " if i < len(words) - 1 else "")
            time.sleep(0.012)
        yield "\n"


def _ask(prompt: str, patient_id: int | None):
    with st.chat_message("user"):
        st.write(prompt)
    with st.chat_message("assistant"):
        try:
            with st.spinner(t("thinking")):
                reply = api.post("/api/ai/chat", {"message": prompt, "lang": lang(), "patient_id": patient_id})
            st.write_stream(_typing(reply["body"]))
        except api.ApiError as e:
            st.error(e.detail)


@st.cache_data(ttl=120, show_spinner=False)
def _insights(token: str, lng: str) -> list[dict]:
    """Пациент: карточки «Что важно сейчас». Кэш 2 минуты — анализ тяжёлый, смысл за это время не меняется."""
    return api.get("/api/ai/insights", lang=lng)


@st.cache_data(ttl=120, show_spinner=False)
def _clinical(token: str, lng: str, patient_id: int) -> list[dict]:
    """Врач: клиническая сводка по выбранному пациенту (риск, находки, что проверить, режим, сон)."""
    return api.get("/api/ai/clinical", lang=lng, patient_id=patient_id)


def _insight_cards():
    """ПАЦИЕНТ: первая карточка — «выходить ли на улицу / нужна ли маска», дальше — по анализам."""
    try:
        cards = _insights(st.session_state["token"], lang())
    except api.ApiError:
        return
    st.markdown(f"##### {t('insights')}")
    cols = st.columns(3)
    for i, c in enumerate(cards[:6]):
        lvl = {"critical": "warning", "warning": "warning", "trend": "info"}.get(c["level"], "normal")
        with cols[i % 3].container(border=True):
            badge = ui.badge(lvl, ui.level_text(lvl)) if lvl == "warning" else ""
            st.markdown(f"**{ui.esc(c['title'])}** {badge}", unsafe_allow_html=True)
            for r in c["reasons"][:3]:
                st.caption(r[0].upper() + r[1:] if r else r)
            for tip in c["tips"][:2]:
                st.markdown(f"- {tip}")


def _clinical_cards(patient_id: int):
    """ВРАЧ: не советы пациенту, а поддержка решений — риск, находки, что проверить, режим, сон."""
    try:
        cards = _clinical(st.session_state["token"], lang(), patient_id)
    except api.ApiError:
        return
    st.markdown(f"##### {t('clinical_h')}")
    cols = st.columns(3)
    for i, c in enumerate(cards):
        with cols[i % 3].container(border=True):
            badge = ui.badge(c["level"], t(c["level"])) if c["level"] in ("critical", "warning") else ""
            val = f"<div class='mb-big'>{c['value']}</div>" if c["value"] is not None else ""
            st.markdown(f"**{ui.esc(c['title'])}** {badge}{val}", unsafe_allow_html=True)
            for line in c["lines"]:
                st.caption(line)


def render(patient_id: int | None = None):
    """Patient: health assistant. Doctor: clinical AI analyst for the selected patient."""
    role = st.session_state["user"]["role"]
    is_doc = role == "doctor"
    c1, c2 = st.columns([4, 1], vertical_alignment="bottom")
    c1.header(t("m_ai_doc") if is_doc else t("m_ai"))
    if c2.button(t("clear_chat"), width="stretch"):
        api.delete("/api/ai/history" + (f"?patient_id={patient_id}" if patient_id else ""))
        st.rerun()
    st.caption(t("ai_intro_doc") if is_doc else t("ai_intro"))
    try:
        eng = api.get("/api/ai/engine")
        st.markdown(ui.badge("info", t("engine_llm") + f" · {eng['model']}" if eng["engine"] == "local-llm"
                             else t("engine_builtin")), unsafe_allow_html=True)
    except api.ApiError:
        pass
    if is_doc:
        _clinical_cards(patient_id)
    else:
        _insight_cards()

    for m in api.get("/api/ai/history", patient_id=patient_id):
        with st.chat_message(m["role"]):
            st.markdown(m["body"])

    def _on_quick():
        # remember the question and reset the chip right away (so it never fires twice)
        st.session_state["_ai_pending"] = st.session_state.get("ai_quick")
        st.session_state["ai_quick"] = None

    st.pills(t("ai_quick"), _suggestions(lang(), role, st.session_state["token"]), key="ai_quick", label_visibility="collapsed", on_change=_on_quick)
    typed = st.chat_input(t("ai_placeholder_doc") if is_doc else t("ai_placeholder"))
    prompt = typed or st.session_state.pop("_ai_pending", None)
    if prompt:
        _ask(prompt, patient_id)
