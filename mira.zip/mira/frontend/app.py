"""
app.py — ГЛАВНЫЙ ФАЙЛ ИНТЕРФЕЙСА MIRA (Streamlit)
================================================
Запуск (из папки frontend/, backend должен работать):
    streamlit run app.py

Как устроен Streamlit: при КАЖДОМ действии пользователя (клик, ввод) этот файл выполняется
сверху вниз заново. Всё, что нужно помнить между запусками (токен, язык, открытая страница),
хранится в st.session_state.

Путь пользователя (сайт «двухслойный»):
    landing   — 1-й слой: что такое MIRA, как работает, роли, зачем, скриншоты, техподдержка, подвал;
                справа вверху «Войти» / «Регистрация»
    welcome   — выбор роли «пациент / врач»
    login     — email + пароль, ниже «или» и «Войти через OneID»
    register  — анкета -> окно согласия на обработку данных -> аккаунт
    pending   — пациент ждёт одобрения врача
    identity  — первый вход: проверка лица MyID (сначала объяснение и разрешение камеры)
    main_app  — кабинет: слева меню, сверху язык / тема / уведомления / имя,
                справа внизу круглая кнопка «ИИ» (чат с ИИ или с врачом)

Дизайн: публичные страницы — с анимациями и иллюстрациями; кабинеты — минимализм, крупный шрифт,
больше воздуха между блоками, без эмодзи и ярких цветов.
"""
from datetime import datetime, timedelta

import httpx
import streamlit as st

st.set_page_config(page_title="MIRA — Medical Intelligent Rehabilitation Assistant",
                   page_icon=":material/monitor_heart:", layout="wide", initial_sidebar_state="auto")

import api  # noqa: E402
import ui  # noqa: E402
from i18n import LANGS, lang, mname, t  # noqa: E402
from views import (account, admin, ai_chat, analyses, appointments, device, device_confirm, goals, history,  # noqa: E402
                   identity, inbox, landing, medications, messages, mydoc, profile, record, sleep)

MIN_BACKEND = "2.3.0"          # версия backend, с которой совместим этот интерфейс

ui.inject_css()
ui.restore_session()
ui.ensure_device_id()
st.session_state.setdefault("lang", "ru")
st.session_state.setdefault("screen", "landing")


# ======================================================================================
# Язык и тема (используются и на публичных страницах, и в кабинете)
# ======================================================================================
def _lang_theme(c_lang, c_theme):
    inv = {v: k for k, v in LANGS.items()}
    choice = c_lang.segmented_control("lang", list(LANGS), default=inv[st.session_state["lang"]],
                                      label_visibility="collapsed", key="lang_ctl")
    if choice and LANGS[choice] != st.session_state["lang"]:
        st.session_state["lang"] = LANGS[choice]
        ui.set_cookie("mira_lang", LANGS[choice], days=365)
        if st.session_state.get("token"):
            ui.save_session()
        st.rerun()
    label = t("theme_light") if ui.is_dark() else t("theme_dark")   # текст вместо значков
    if c_theme.button(label, key="theme_btn", width="stretch"):
        ui.switch_theme()


def top_bar():
    c1, c2, c3 = st.columns([6, 3, 1.3], vertical_alignment="center")
    c1.markdown('<div class="mb-logo" style="margin:0"><i>M</i><div><b>MIRA</b><small>Medical Intelligent<br>'
                'Rehabilitation Assistant</small></div></div>', unsafe_allow_html=True)
    _lang_theme(c2, c3)


def logout():
    api.logout_remote()          # токен попадает в чёрный список на сервере
    ui.drop_session()
    api.stop_streams()
    keep = {k: st.session_state.get(k) for k in ("lang", "_device_id")}
    st.session_state.clear()
    st.session_state.update({k: v for k, v in keep.items() if v})


# ======================================================================================
# 1-й слой: лендинг
# ======================================================================================
HERO_SVG = """
<svg viewBox="0 0 360 300" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="MIRA">
  <circle cx="60" cy="60" r="46" fill="{soft}"/><circle cx="310" cy="250" r="34" fill="{soft}"/>
  <g class="device">
    <rect x="110" y="18" width="140" height="264" rx="28" fill="none" stroke="{border}" stroke-width="3"/>
    <rect x="122" y="32" width="116" height="236" rx="20" fill="{card}"/>
    <circle cx="180" cy="104" r="44" fill="none" stroke="{soft}" stroke-width="9"/>
    <circle cx="180" cy="104" r="44" fill="none" stroke="{accent}" stroke-width="9" stroke-linecap="round"
            stroke-dasharray="210 277" transform="rotate(-90 180 104)"/>
    <text x="180" y="112" text-anchor="middle" font-family="sans-serif" font-size="26" font-weight="700" fill="{text}">72</text>
    <polyline class="pulse" points="134,184 156,184 164,170 172,200 182,158 192,192 200,184 226,184" fill="none"
              stroke="{accent}" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/>
    <rect x="134" y="214" width="44" height="30" rx="8" fill="{soft}"/>
    <rect x="182" y="214" width="44" height="30" rx="8" fill="{soft}"/>
  </g>
  <path d="M40 150 C 70 150, 80 120, 104 120" fill="none" stroke="{muted}" stroke-width="2" stroke-dasharray="4 5"/>
  <circle cx="34" cy="150" r="16" fill="none" stroke="{accent}" stroke-width="3"/>
  <path d="M320 170 C 290 170, 280 200, 256 200" fill="none" stroke="{muted}" stroke-width="2" stroke-dasharray="4 5"/>
  <rect x="312" y="152" width="34" height="36" rx="9" fill="none" stroke="{accent}" stroke-width="3"/>
  <line x1="322" y1="164" x2="336" y2="164" stroke="{accent}" stroke-width="3" stroke-linecap="round"/>
  <line x1="322" y1="174" x2="332" y2="174" stroke="{accent}" stroke-width="3" stroke-linecap="round"/>
</svg>"""


def hero_html() -> str:
    p = ui.pal()
    svg = HERO_SVG.format(border=p["border"], card=p["card"], soft=p["accent_soft"], accent=p["accent"],
                          text=p["text"], muted=p["muted"])
    feats = "".join(f'<div class="mb-feat"><i></i><b>{t(k)}</b><span>{t(k + "_d")}</span></div>'
                    for k in ("f_live", "f_ai", "f_meds", "f_safe"))
    return (f'<div class="mb-hero"><div><div class="mb-eyebrow">Medical Intelligent Rehabilitation Assistant</div>'
            f'<h1>{t("hero_title")}</h1><p class="lead">{t("hero_sub")}</p><div class="mb-feats">{feats}</div></div>'
            f'<div>{svg}</div></div>')


def _to_auth(intent: str):
    st.session_state.update(intent=intent, screen="welcome")


def landing_screen():
    landing.render(hero_html(), lambda: _to_auth("login"), lambda: _to_auth("register"), _lang_theme)
    if not api.is_up():
        st.error(t("api_down"))


# ======================================================================================
# 2-й слой: роль, вход, регистрация
# ======================================================================================
def welcome():
    _, mid, _ = st.columns([1, 2.2, 1])
    with mid:
        st.markdown(f"### {t('who')}")
        c1, c2 = st.columns(2)
        nxt = "register" if st.session_state.get("intent") == "register" else "login"
        for col, role in ((c1, "patient"), (c2, "doctor")):
            with col:
                st.markdown(f'<div class="mb-rolecard"><b>{t(role)}</b><p>{t("role_" + role + "_d")}</p></div>',
                            unsafe_allow_html=True)
                if st.button(f"{t('continue_as')}: {t(role).lower()}", key=f"role_{role}", width="stretch",
                             type="primary" if role == "patient" else "secondary"):
                    st.session_state.update(role_choice=role, screen=nxt)
                    st.rerun()
        st.button(t("back"), width="stretch", on_click=lambda: st.session_state.update(screen="landing"))


def _logged_in(res: dict):
    st.session_state["token"] = res["access_token"]
    st.session_state["user"] = res["user"]
    st.session_state["page"] = "m_admin" if res["user"]["role"] == "doctor" else "m_analyses"
    sid = ui.save_session()
    st.session_state["_set_cookie"] = sid
    st.rerun()


def _auth_error(e: api.ApiError):
    """Понятные сообщения для особых ответов сервера."""
    if e.detail == "device_pending":
        st.warning(t("device_pending"))
    elif e.detail == "device_revoked":
        st.error(t("device_revoked"))
    else:
        st.error(e.detail)


def _oneid_block(role: str):
    """Под кнопками входа/регистрации: «или» и «Войти через OneID»."""
    st.markdown(f"<div style='text-align:center;color:var(--mb-muted,#7a8783);margin:.4rem 0'>— {t('or')} —</div>",
                unsafe_allow_html=True)
    try:
        info = api.get("/api/auth/oneid/url", role=role)
    except Exception:  # noqa: BLE001
        info = {"configured": False}
    if info.get("configured"):
        st.link_button(t("oneid_btn"), info["url"], width="stretch")
    elif st.button(t("oneid_btn"), key="oneid_btn", width="stretch"):
        st.info(t("oneid_off"))


def login_screen():
    role = st.session_state.get("role_choice", "patient")
    _, mid, _ = st.columns([1, 1.5, 1])
    with mid:
        st.markdown(f"### {t('login')}")
        st.caption(f"{t('as_role')}: **{t(role)}**")
        with st.form("login"):
            email = st.text_input(t("email"))
            pwd = st.text_input(t("password"), type="password")
            ok = st.form_submit_button(t("login_btn"), type="primary", width="stretch")
        if ok:
            if not email or not pwd:
                st.error(t("fill_all"))
            else:
                try:
                    _logged_in(api.login(email, pwd, role))
                except api.ApiError as e:
                    _auth_error(e)
                except Exception:  # noqa: BLE001
                    st.error(t("api_down"))
        c1, c2 = st.columns(2)
        if c1.button(t("register"), width="stretch"):
            st.session_state["screen"] = "register"
            st.rerun()
        if c2.button(t("back"), width="stretch"):
            st.session_state["screen"] = "landing"
            st.rerun()
        _oneid_block(role)
        demo = "patient@mira.uz / patient123" if role == "patient" else "doctor@mira.uz / doctor123"
        st.caption(f"{t('demo')}: `{demo}`")


def _pwd_ok(pwd: str) -> bool:
    """Та же политика, что на сервере: 8+ символов, буквы и цифры (сервер всё равно проверит сам)."""
    return len(pwd) >= 8 and any(c.isalpha() for c in pwd) and any(c.isdigit() for c in pwd)


@st.dialog(" ", width="large")
def consent_dialog():
    """Окно согласия: показывается ПОСЛЕ заполнения анкеты, до создания аккаунта."""
    st.markdown(f"### {t('consent_title')}")
    with st.container(height=320):
        st.markdown(t("consent_text"))
    agree = st.checkbox(t("consent_check"), key="consent_cb")
    if st.button(t("consent_agree"), type="primary", width="stretch"):
        if not agree:
            st.error(t("consent_need"))
            return
        payload = {**st.session_state.pop("_reg_payload"), "consent": True}
        try:
            _logged_in(api.register(payload))
        except api.ApiError as e:
            st.session_state["_reg_error"] = e.detail
            st.rerun()


def register_screen():
    role = st.session_state.get("role_choice", "patient")
    _, mid, _ = st.columns([1, 1.5, 1])
    with mid:
        st.markdown(f"### {t('register')} — {t(role).lower()}")
        if st.session_state.get("_reg_error"):
            st.error(st.session_state.pop("_reg_error"))
        with st.form("register"):
            c1, c2 = st.columns(2)
            first = c1.text_input(t("first_name"), max_chars=100)
            last = c2.text_input(t("last_name"), max_chars=100)
            email = st.text_input("Email", max_chars=255)
            pwd = st.text_input(t("password"), type="password", help=t("pwd_short"))
            c3, c4 = st.columns(2)
            age = c3.number_input(t("age"), min_value=1, max_value=120, value=30, step=1)
            genders = {"male": t("male"), "female": t("female")}
            gender = c4.selectbox(t("gender"), list(genders), format_func=genders.get)
            phone = pinfl = invite = None
            if role == "patient":
                phone = st.text_input(t("phone"), placeholder="+998 90 123 45 67")
                need = api.server_info().get("pinfl_required", False)   # MVP: необязательно
                pinfl = st.text_input(t("pinfl_req") if need else t("pinfl"), max_chars=14)
            else:
                invite = st.text_input(t("invite_code"), type="password")
            ok = st.form_submit_button(t("register_btn"), type="primary", width="stretch")
        if ok:
            if not (first and last and email and pwd):
                st.error(t("fill_all"))
            elif not _pwd_ok(pwd):
                st.error(t("pwd_short"))
            elif role == "patient" and pinfl and not (pinfl.isdigit() and len(pinfl) == 14):
                st.error(t("pinfl_bad"))
            elif role == "patient" and not pinfl and api.server_info().get("pinfl_required"):
                st.error(t("pinfl_bad"))
            else:
                st.session_state["_reg_payload"] = {
                    "first_name": first, "last_name": last, "email": email, "password": pwd, "age": int(age),
                    "gender": gender, "role": role, "phone": phone or None, "pinfl": pinfl or None,
                    "invite_code": invite or None}
                consent_dialog()
        c1, c2 = st.columns(2)
        if c1.button(t("login"), width="stretch"):
            st.session_state["screen"] = "login"
            st.rerun()
        if c2.button(t("back"), width="stretch"):
            st.session_state["screen"] = "landing"
            st.rerun()
        if role == "patient":
            _oneid_block(role)


def oneid_return():
    """OneID вернул пользователя на сайт с ?code=...&state=... — завершаем вход на сервере."""
    qp = st.query_params
    code, state = qp.get("code"), qp.get("state")
    st.query_params.clear()
    try:
        _logged_in(api.post("/api/auth/oneid/callback", {"code": code, "state": state, "consent": True}))
    except api.ApiError as e:
        st.session_state["screen"] = "login"
        if e.detail in ("device_pending", "device_revoked"):
            st.session_state["_login_msg"] = e.detail
        else:
            st.error(t("oneid_fail"))


# ======================================================================================
# Ожидание одобрения
# ======================================================================================
def pending_screen(user: dict):
    rejected = user.get("status") == "rejected"
    st.markdown(f'<div class="mb-pending">{ui.badge("info" if not rejected else "warning", t("st_requested") if not rejected else t("st_declined"))}'
                f'<h2>{t("pending_title") if not rejected else t("register")}</h2>'
                f'<p>{t("rejected_text") if rejected else t("pending_text")}</p></div>', unsafe_allow_html=True)
    _, mid, _ = st.columns([1, 1, 1])
    if mid.button(t("check_again"), width="stretch", type="primary"):
        try:
            st.session_state["user"] = api.get("/api/auth/me")
            ui.save_session()
        except api.ApiError:
            pass
        st.rerun()
    mid.button(t("logout"), width="stretch", on_click=logout)


# ======================================================================================
# Уведомления в реальном времени (toast)
# ======================================================================================
@st.fragment(run_every="5s")
def doctor_alert_watcher():
    """Критические тревоги — ТОЛЬКО у врача (ТЗ). Одна подсказка на инцидент, без повторов."""
    s = api.stream()
    shown = st.session_state.setdefault("_alerts_shown", {})
    now = datetime.utcnow()
    for a in [a for a in list(s.alerts) if not a["seen"]]:
        a["seen"] = True
        key = (a.get("patient_id"), a["metric"], a["level"])
        if key in shown and now - shown[key] < timedelta(minutes=10):
            continue
        shown[key] = now
        text = f"{a['patient_name']}: {mname(a['metric'])} = {a['value']:.1f}"
        if a["level"] == "critical":
            st.toast(f"{t('critical')} — {text}", icon=":material/emergency:")
            ui.browser_notify(f"MIRA: {t('critical')}", text)
        else:
            st.toast(f"{t('warning')} — {text}", icon=":material/info:")


@st.fragment(run_every="10s")
def patient_reminder_watcher():
    """Пациенту — только спокойные напоминания о лекарствах (SMS уходит параллельно с сервера)."""
    s = api.stream()
    for r in [r for r in list(s.reminders) if not r["seen"]]:
        r["seen"] = True
        st.toast(f"{t('reminder_now')}: {r['name']} {r['dose']} ({r['time']})", icon=":material/medication:")
        ui.browser_notify("MIRA", f"{t('reminder_now')}: {r['name']} {r['dose']}")


@st.dialog(" ")
def notif_permission_dialog():
    """Один раз после входа: зачем нужны уведомления (напоминания + защита от мошенничества)."""
    st.markdown(f"### {t('notif_title')}")
    st.write(t("notif_text"))
    ui.request_push_permission_button(t("allow"))
    if st.button(t("done_btn"), width="stretch", type="primary"):
        st.rerun()


# ======================================================================================
# Верхняя панель кабинета: приветствие · язык · тема · уведомления · имя
# ======================================================================================
@st.cache_data(ttl=10, show_spinner=False)     # 10 с: запрос нового устройства появляется почти сразу
def _notifications(token: str, lng: str) -> dict:
    return api.get("/api/notifications", lang=lng)


def _open(page: str):
    st.session_state["page"] = page


def header(user: dict):
    """Верхняя панель. Две строки, чтобы надписи никогда не наезжали друг на друга:
    1) справа — язык, тема, колокольчик, имя;  2) крупное приветствие на всю ширину."""
    is_doc = user["role"] == "doctor"
    with st.container(key="topbar"):
        _, c2, c3, c4, c5 = st.columns([3, 2.3, 1.2, 0.9, 2.1], vertical_alignment="center")
        _lang_theme(c2, c3)
        try:
            data = _notifications(st.session_state["token"], lang())
        except (api.ApiError, httpx.HTTPError):
            data = {"items": [], "unread": 0}
        n = data["unread"]
        # колокольчик: значок + число непрочитанных (значок Material — не эмодзи)
        with c4.popover(str(n) if n else " ", icon=":material/notifications:", help=t("notifications"),
                        width="stretch"):
            items = data["items"][:8]
            if not items:
                st.caption(t("no_notifications"))
            for it in items:
                cls = "mb-notif unread" if it["unread"] else "mb-notif"
                st.markdown(f'<div class="{cls}"><b>{ui.esc(it["title"])}</b><span>{ui.esc(it["text"])}</span><br>'
                            f'<small>{ui.fmt_local(it["ts"], "%d.%m %H:%M")}</small></div>', unsafe_allow_html=True)
                if (it.get("action") or {}).get("type") == "approve_device":
                    if st.button(t("allow"), key=f"nb_{it['key']}", type="primary"):
                        api.post(f"/api/auth/devices/{it['action']['id']}/approve")
                        _notifications.clear()
                        st.rerun()
            a, b = st.columns(2)
            if a.button(t("mark_read"), key="nb_read", width="stretch"):
                api.post("/api/notifications/seen")
                _notifications.clear()
                st.rerun()
            b.button(t("open_all"), key="nb_all", width="stretch", on_click=_open, args=("m_inbox",))
        with c5.popover(f"{user['first_name']} {user['last_name'][:1]}.", icon=":material/account_circle:",
                        width="stretch"):
            st.markdown(f"**{ui.esc(user['first_name'])} {ui.esc(user['last_name'])}**  \n"
                        f"<span class='mb-muted'>{t(user['role'])} · {ui.esc(user['email'])}</span>",
                        unsafe_allow_html=True)
            items = (("m_profile", "personal_info"), ("m_settings", "m_settings"), ("m_docs", "m_docs"),
                     ("m_support", "m_support"))
            if user.get("device_status") == "pending":
                items = (("m_profile", "m_profile"), ("m_support", "m_support"))
            for page, key in items:
                st.button(t(key), key=f"um_{page}", width="stretch", type="tertiary", on_click=_open, args=(page,))
            st.button(t("logout"), key="um_logout", width="stretch", on_click=logout)
    sub = t("hello_sub_doctor") if is_doc else t("hello_sub_patient")
    st.markdown(f'<div class="mb-hello"><h2>{t("hello")}, {ui.esc(user["first_name"])}</h2><p>{sub}</p></div>',
                unsafe_allow_html=True)
    _version_check()


def _ver(v: str) -> tuple:
    """'2.10.1' -> (2, 10, 1): версии сравниваем как числа, а не как строки."""
    try:
        return tuple(int(x) for x in v.split("."))
    except ValueError:
        return (0,)


def _version_check():
    """Если запущен старый backend — предупреждаем сразу, а не падаем на «Not Found»."""
    if _ver(api.server_info().get("version", "0")) < _ver(MIN_BACKEND):
        st.warning(t("api_old"))


def fab(is_doc: bool):
    """Круглая кнопка «ИИ» в правом нижнем углу: выбор — чат с ИИ или чат с врачом (пациентом)."""
    with st.container(key="fab"):
        with st.popover(t("fab")):
            st.markdown(f"**{t('fab_title')}**")
            st.button(t("fab_ai_doc") if is_doc else t("fab_ai"), key="fab_ai", width="stretch", type="primary",
                      on_click=_open, args=("m_ai",))
            if is_doc:
                st.button(t("fab_pat"), key="fab_msg", width="stretch", on_click=_open, args=("m_messages",))
            else:
                def to_chat():
                    st.session_state.update(page="m_mydoc", mydoc_tab="chat")
                st.button(t("fab_doc"), key="fab_doc", width="stretch", on_click=to_chat)


# ======================================================================================
# Главное меню
# ======================================================================================
# Умное меню: разделы сгруппированы, чтобы человек не «заблудился» в длинном списке.
# Слева — 6–7 крупных групп; внутри группы — вкладки сверху страницы.
PATIENT_GROUPS = [
    ("g_health", ["m_analyses", "m_history", "m_sleep", "m_goals"]),
    ("g_treat", ["m_meds", "m_record"]),
    ("m_mydoc", ["m_mydoc"]),
    ("g_device", ["m_device", "m_gps"]),
    ("m_inbox", ["m_inbox"]),
    ("g_account", ["m_profile", "m_settings", "m_docs", "m_support"]),
]
DOCTOR_GROUPS = [
    ("g_patients", ["m_admin", "m_approvals", "m_pinfo"]),
    ("m_inbox_doc", ["m_inbox", "m_messages"]),
    ("m_appts", ["m_appts"]),
    ("g_pmetrics", ["m_analyses", "m_history", "m_sleep", "m_goals"]),
    ("g_treat", ["m_meds", "m_record"]),
    ("g_device", ["m_device", "m_gps"]),
    ("g_account", ["m_profile", "m_settings", "m_docs", "m_audit", "m_support"]),
]
HIDDEN = ["m_ai"]                     # открывается круглой кнопкой «ИИ»
PER_PATIENT = {"m_pinfo", "m_analyses", "m_history", "m_messages", "m_ai", "m_meds", "m_goals", "m_sleep",
               "m_record", "m_gps", "m_device"}   # страницы врача, где нужно выбрать пациента
SUB_LABEL_DOC = {"m_inbox": "sub_signals", "m_messages": "sub_messages"}


def limited_app(user: dict):
    """НОВОЕ устройство: вход выполнен, но кабинет пустой. В меню — только «Профиль», где
    устройство подтверждается (лицом MyID на этом устройстве или разрешением с первого)."""
    page = st.session_state.get("page")
    with st.sidebar:
        st.markdown('<div class="mb-logo"><i>M</i><div><b>MIRA</b><small>Medical Intelligent<br>'
                    'Rehabilitation Assistant</small></div></div>', unsafe_allow_html=True)
        st.button(t("m_profile"), key="nav_lim_profile", width="stretch", on_click=_open, args=("m_profile",),
                  type="primary" if page == "m_profile" else "tertiary")
    header(user)
    if page == "m_profile":
        device_confirm.render_profile()
    elif page == "m_support":
        account.render_support()
    else:
        device_confirm.empty_state()


def _safe_render(fn):
    """Любая ошибка сервера показывается аккуратной карточкой, а не красной «простынёй» Python.
    404 чаще всего значит, что запущен СТАРЫЙ backend (новые разделы в нём ещё нет)."""
    try:
        fn()
    except api.ApiError as e:
        if e.status == 404 and e.detail == "Not Found":
            st.error(t("api_old"))
        else:
            st.error(f"{t('api_error')}: {e.detail}")
    except httpx.HTTPError:
        st.error(t("api_down"))


def main_app():
    user = st.session_state["user"]
    if user.get("status", "approved") != "approved":
        top_bar()
        pending_screen(user)
        return
    if user.get("identity_status", "verified") != "verified":
        top_bar()
        identity.render(user, logout)
        return
    is_doc = user["role"] == "doctor"
    if st.session_state.pop("_set_cookie", None):
        ui.set_cookie(ui.COOKIE, st.session_state["_sid"])
    if user.get("device_status") == "pending":
        limited_app(user)
        return
    if not st.context.cookies.get("mira_notif_asked") and not st.session_state.get("_notif_asked"):
        st.session_state["_notif_asked"] = True
        # cookie ставим сразу при показе окна: после перезагрузки страницы окно не повторяется
        ui.set_cookie("mira_notif_asked", "1", days=365)
        notif_permission_dialog()

    groups = DOCTOR_GROUPS if is_doc else PATIENT_GROUPS
    all_pages = [p for _, ps in groups for p in ps] + HIDDEN
    if "_goto" in st.session_state:
        st.session_state["page"] = st.session_state.pop("_goto")
    if st.session_state.get("page") not in all_pages:
        last = st.session_state.get("_last_page")
        st.session_state["page"] = last if last in all_pages else groups[0][1][0]
    page = st.session_state["page"]
    group = next((g for g, ps in groups if page in ps), None)      # None — скрытая страница (ИИ)

    # ---- слева: крупные группы
    with st.sidebar:
        st.markdown('<div class="mb-logo"><i>M</i><div><b>MIRA</b><small>Medical Intelligent<br>'
                    'Rehabilitation Assistant</small></div></div>', unsafe_allow_html=True)
        for g, ps in groups:
            st.button(t(g), key=f"nav_{g}", width="stretch", on_click=_open, args=(ps[0],),
                      type="primary" if g == group else "tertiary")

    header(user)

    # ---- телефон: группы «таблетками»
    gkeys = [g for g, _ in groups]
    first_of = dict(groups)

    def mob_change():
        g = st.session_state.get("mnav")
        if g:
            _open(first_of[g][0])
    st.session_state["mnav"] = group
    with st.container(key="mobnav"):
        st.pills("menu", gkeys, key="mnav", label_visibility="collapsed", on_change=mob_change, format_func=t)

    st.session_state["_last_page"] = page
    ui.save_session()
    fab(is_doc)
    if is_doc:
        doctor_alert_watcher()
    else:
        patient_reminder_watcher()

    # ---- вкладки внутри группы + (у врача) выбор пациента в той же строке
    subs = first_of.get(group, [])
    patient_id, names = None, {}
    if is_doc:
        try:
            plist = api.patients(st.session_state["token"])
        except (api.ApiError, httpx.HTTPError):
            plist = []
        names = {p["id"]: p["name"] for p in plist}
        if names:
            cur = st.session_state.get("patient_id")
            patient_id = cur if cur in names else next(iter(names))
    need_patient = is_doc and page in PER_PATIENT
    if len(subs) > 1 or need_patient:
        c1, c2 = st.columns([3, 1.4] if need_patient else [1, 0.001], vertical_alignment="bottom")
        if len(subs) > 1:
            def sub_label(p):
                return t(SUB_LABEL_DOC[p]) if (is_doc and p in SUB_LABEL_DOC) else t(p)
            choice = c1.segmented_control(" ", subs, default=page, format_func=sub_label,
                                          key=f"sub_{group}_{page}", label_visibility="collapsed")
            if choice and choice != page:
                _open(choice)
                st.rerun()
        if need_patient and names:
            patient_id = c2.selectbox(t("select_patient"), list(names), index=list(names).index(patient_id),
                                      format_func=names.get, label_visibility="collapsed")
    if is_doc:
        st.session_state["patient_id"] = patient_id
        if need_patient and not patient_id:
            st.info(t("no_patients"))
            return
    pid = patient_id if is_doc else None

    renderers = {
        "m_admin": admin.render_patients,
        "m_approvals": admin.render_approvals,
        "m_inbox": lambda: inbox.render(is_doc),
        "m_audit": admin.render_audit,
        "m_analyses": lambda: analyses.render(pid),
        "m_history": lambda: history.render(pid),
        "m_messages": lambda: messages.render_doctor(patient_id),
        "m_ai": lambda: ai_chat.render(pid),
        "m_meds": lambda: medications.render(pid),
        "m_goals": lambda: goals.render(pid),
        "m_sleep": lambda: sleep.render(pid),
        "m_appts": appointments.render,
        "m_record": lambda: record.render(pid),
        "m_profile": profile.render_own,
        "m_pinfo": lambda: profile.render_patient(patient_id),
        "m_mydoc": mydoc.render,
        "m_gps": lambda: device.render_gps(pid),
        "m_device": lambda: device.render_device(pid),
        "m_settings": account.render_settings,
        "m_docs": lambda: account.render_documents(pid),
        "m_support": account.render_support,
    }
    _safe_render(renderers[page])


# ======================================================================================
# Точка входа
# ======================================================================================
if "code" in st.query_params and "state" in st.query_params and not st.session_state.get("token"):
    oneid_return()

if st.session_state.get("token"):
    main_app()
else:
    screen = st.session_state["screen"]
    if screen == "landing":
        landing_screen()
    else:
        top_bar()
        msg = st.session_state.pop("_login_msg", None)
        if msg:
            st.warning(t(msg))
        {"welcome": welcome, "login": login_screen, "register": register_screen}.get(screen, welcome)()
