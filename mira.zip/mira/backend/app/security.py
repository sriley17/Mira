"""
security.py — ВСЯ БЕЗОПАСНОСТЬ MIRA В ОДНОМ МЕСТЕ
================================================

Что здесь есть (и зачем):

1. Пароли (bcrypt)
   Пароль никогда не хранится в базе. Хранится только bcrypt-хэш — «отпечаток», из которого
   нельзя восстановить пароль. bcrypt специально медленный (≈0.1–0.3 c), поэтому перебирать
   миллионы паролей по украденной базе очень дорого.

2. Политика паролей
   Минимум 8 символов, обязательно буквы и цифры, не совпадает с email.

3. JWT-токены
   После входа пользователь получает токен (подписанная строка). В нём: id пользователя (sub),
   роль, время выдачи (iat), срок (exp) и уникальный номер токена (jti).
   Подпись HMAC-SHA256 секретом сервера — подделать токен без секрета невозможно.
   При выходе jti попадает в «чёрный список» (таблица revoked_tokens) — украденный токен
   после выхода перестаёт работать.

4. Защита от подбора пароля (brute-force)
   После 5 неудачных попыток для пары «email + IP» вход блокируется на 5 минут.

5. Роли и доступ
   get_current_user   — любой вошедший ОДОБРЕННЫЙ пользователь;
   get_user_any_status— вошедший пользователь даже со статусом pending или без проверки
                        личности (нужно для экранов «ожидайте врача» и «подтвердите личность»);
   Токен привязан к устройству (claim dev): отозвали устройство — токен перестал работать.
   require_doctor     — только врач;
   resolve_patient    — пациент видит только себя, врач — только СВОИХ пациентов.

6. Шифрование данных «на диске» (Fernet = AES-128-CBC + HMAC-SHA256)
   Сообщения, чат с ИИ, телефон, ПИНФЛ, ключ устройства хранятся зашифрованными.
   Даже если кто-то скопирует файл базы, без ключа он увидит только «кашу».

7. Журнал аудита — кто, когда и что сделал (вход, одобрение, просмотр пациента).
"""
import base64
import hashlib
import hmac
import logging
import re
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone

import bcrypt
import jwt
from cryptography.fernet import Fernet, InvalidToken
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from .config import get_settings
from .database import get_db
from .models import AuditLog, RevokedToken, User, UserDevice, utcnow

settings = get_settings()
log = logging.getLogger("mira.security")

# FastAPI сам достаёт токен из заголовка "Authorization: Bearer <token>"
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


# ======================================================================================
# 1. Пароли
# ======================================================================================
def hash_password(password: str) -> str:
    """Возвращает bcrypt-хэш. gensalt() добавляет случайную «соль», поэтому
    у двух одинаковых паролей хэши всё равно разные.
    [:72] — bcrypt учитывает только первые 72 байта, обрезаем явно, чтобы не было ошибки."""
    return bcrypt.hashpw(password.encode()[:72], bcrypt.gensalt()).decode()


def verify_password(password: str, hashed: str) -> bool:
    """Проверка пароля. checkpw сравнивает за постоянное время (не выдаёт подсказок по таймингу)."""
    try:
        return bcrypt.checkpw(password.encode()[:72], hashed.encode())
    except ValueError:  # повреждённый хэш в базе — считаем, что пароль неверный
        return False


# Хэш-«пустышка»: если email не найден, всё равно тратим время на проверку пароля.
# Иначе по скорости ответа можно было бы узнать, зарегистрирован ли email.
_DUMMY_HASH = hash_password("dummy-password-for-timing")


def verify_password_or_dummy(password: str, user: User | None) -> bool:
    if user is None:
        verify_password(password, _DUMMY_HASH)
        return False
    return verify_password(password, user.password_hash)


# ======================================================================================
# 2. Политика паролей
# ======================================================================================
def password_problems(password: str, email: str = "") -> list[str]:
    """Возвращает список нарушений (пустой список = пароль хороший).
    Используется в schemas.RegisterIn — ошибки видны пользователю при регистрации."""
    problems = []
    if len(password) < settings.password_min_length:
        problems.append(f"минимум {settings.password_min_length} символов")
    if not re.search(r"[A-Za-zА-Яа-яЁёЎўҚқҒғҲҳ]", password):
        problems.append("нужна хотя бы одна буква")
    if not re.search(r"\d", password):
        problems.append("нужна хотя бы одна цифра")
    if email and password.lower() == email.lower():
        problems.append("пароль не должен совпадать с email")
    return problems


# ======================================================================================
# 3. JWT-токены
# ======================================================================================
def device_hash(raw: str | None) -> str:
    """Id устройства (случайная строка из cookie браузера) -> SHA-256. Сам id в базе не храним."""
    return hashlib.sha256((raw or "unknown-device").encode()).hexdigest()


def create_token(user: User, dev_hash: str | None = None) -> str:
    """Выдаёт подписанный токен доступа. dev — к какому устройству привязан токен:
    если это устройство отзовут, токен сразу перестанет работать."""
    now = datetime.now(timezone.utc)
    payload = {
        "dev": dev_hash,
        "sub": str(user.id),               # кто
        "role": user.role,                 # роль (для быстрых проверок на фронтенде)
        "iat": now,                        # когда выдан
        "exp": now + timedelta(minutes=settings.jwt_expire_minutes),  # до какого времени действует
        "jti": uuid.uuid4().hex,           # уникальный номер — нужен для отзыва при выходе
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algorithm)


def decode_token(token: str) -> dict:
    """Проверяет подпись и срок. Список algorithms задан явно — защита от атаки «alg=none»."""
    try:
        return jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm],
                          options={"require": ["exp", "sub"]})
    except jwt.PyJWTError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired token")


def is_revoked(db: Session, data: dict) -> bool:
    jti = data.get("jti")
    return bool(jti and db.get(RevokedToken, jti))


def revoke_token(db: Session, data: dict) -> None:
    """Помещает токен в чёрный список до окончания его срока. Заодно чистит устаревшие записи."""
    jti = data.get("jti")
    if not jti:
        return
    exp = datetime.fromtimestamp(data["exp"], tz=timezone.utc).replace(tzinfo=None)
    if not db.get(RevokedToken, jti):
        db.add(RevokedToken(jti=jti, expires_at=exp))
    db.execute(delete(RevokedToken).where(RevokedToken.expires_at < utcnow()))
    db.commit()


def _user_from_token(token: str, db: Session) -> tuple[User, dict]:
    """Проверяет токен и устройство. Кладёт в user.device_status статус устройства токена:
       approved — полноценный доступ;
       pending  — НОВОЕ устройство: вход выполнен, но кабинет пустой, пока устройство не подтвердят
                  (с первого устройства или проверкой лица в «Профиле» на этом устройстве);
       отозванное или неизвестное устройство -> 401 (токен больше не работает)."""
    data = decode_token(token)
    if is_revoked(db, data):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Token revoked")
    user = db.get(User, int(data["sub"]))
    if not user:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "User not found")
    user.device_status = "approved"          # атрибут только на время запроса, в базу не пишется
    user.device_hash = data.get("dev")
    if settings.device_binding and data.get("dev"):
        dev = db.scalar(select(UserDevice).where(UserDevice.user_id == user.id,
                                                 UserDevice.device_hash == data["dev"]))
        if not dev or dev.status not in ("approved", "pending"):
            raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Device access revoked")
        user.device_status = dev.status
    return user, data


def get_user_any_status(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    """Вошедший пользователь с любым статусом аккаунта и устройства.
    Только для «служебных» эндпоинтов: /me, выход, список устройств, проверка лица."""
    return _user_from_token(token, db)[0]


def require_approved_device(user: User = Depends(get_user_any_status)) -> User:
    """Действия, которые можно делать ТОЛЬКО с уже подтверждённого устройства
    (например, разрешить вход новому устройству — иначе новое устройство одобрило бы само себя)."""
    if user.device_status != "approved":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "device_pending")
    return user


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    """Вошедший и ОДОБРЕННЫЙ пользователь. Используется почти во всех эндпоинтах.
    Пациент со статусом pending получает 403 — пока врач не подтвердит регистрацию,
    к медицинским разделам доступа нет (требование ТЗ)."""
    user, _ = _user_from_token(token, db)
    if user.device_status != "approved":
        # новое устройство ещё не подтверждено: вход есть, но медицинские данные не отдаём
        raise HTTPException(status.HTTP_403_FORBIDDEN, "device_pending")
    if user.status != "approved":
        raise HTTPException(status.HTTP_403_FORBIDDEN, f"Account {user.status}")
    if settings.identity_required and user.identity_status != "verified":
        # пока личность не подтверждена по лицу (MyID), медицинские данные не отдаём
        raise HTTPException(status.HTTP_403_FORBIDDEN, "identity_required")
    return user


def require_doctor(user: User = Depends(get_current_user)) -> User:
    if user.role != "doctor":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Doctors only")
    return user


def require_patient(user: User = Depends(get_current_user)) -> User:
    if user.role != "patient":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Patients only")
    return user


def resolve_patient(user: User, patient_id: int | None, db: Session) -> User:
    """Кого смотрим? Пациент -> всегда себя (patient_id игнорируется, чужие данные недоступны).
    Врач -> обязан указать patient_id, и это должен быть ЕГО пациент."""
    if user.role == "patient":
        return user
    if patient_id is None:
        raise HTTPException(400, "patient_id is required for doctors")
    patient = db.get(User, patient_id)
    if not patient or patient.role != "patient" or patient.doctor_id != user.id:
        # 404, а не 403: не подтверждаем даже сам факт существования чужого пациента
        raise HTTPException(404, "Patient not found in your list")
    return patient


# ======================================================================================
# 4. Защита от подбора пароля
# ======================================================================================
class LoginLimiter:
    """Счётчик неудачных входов в памяти процесса.
    Ключ — email + IP. Для нескольких серверов замените на Redis (тот же интерфейс).
    threading.Lock — потому что FastAPI выполняет обычные (def) эндпоинты в пуле потоков."""

    def __init__(self, max_attempts: int, lock_sec: int) -> None:
        self.max_attempts, self.lock_sec = max_attempts, lock_sec
        self._fails: dict[str, list[float]] = {}   # ключ -> времена неудачных попыток
        self._lock = threading.Lock()

    def seconds_left(self, key: str) -> int:
        """Сколько секунд ещё заблокирован вход (0 — можно пробовать)."""
        now = time.monotonic()
        with self._lock:
            recent = [t for t in self._fails.get(key, []) if now - t < self.lock_sec]
            self._fails[key] = recent
            if len(recent) >= self.max_attempts:
                return int(self.lock_sec - (now - recent[-self.max_attempts])) + 1
        return 0

    def fail(self, key: str) -> None:
        with self._lock:
            self._fails.setdefault(key, []).append(time.monotonic())

    def reset(self, key: str) -> None:
        with self._lock:
            self._fails.pop(key, None)


login_limiter = LoginLimiter(settings.login_max_attempts, settings.login_lock_sec)


def client_ip(request: Request | None) -> str:
    """IP клиента. За обратным прокси (nginx, cloudflared) берём первый адрес из X-Forwarded-For."""
    if request is None:
        return "-"
    fwd = request.headers.get("x-forwarded-for")
    if fwd:
        return fwd.split(",")[0].strip()[:64]
    return (request.client.host if request.client else "-")[:64]


# ======================================================================================
# 5. Ключ устройства
# ======================================================================================
def device_key_matches(stored_enc: str, provided: str) -> bool:
    """Сравнение ключа устройства за ПОСТОЯННОЕ время (hmac.compare_digest).
    Обычное `==` останавливается на первом несовпавшем символе, и по времени ответа
    злоумышленник мог бы угадывать ключ посимвольно."""
    real = decrypt(stored_enc)
    return hmac.compare_digest(real.encode(), provided.encode())


# ======================================================================================
# 6. Шифрование данных
# ======================================================================================
_fernet_cache: Fernet | None = None


def _fernet() -> Fernet:
    """Объект шифрования создаётся один раз. Если DATA_ENCRYPTION_KEY не задан,
    ключ получается из JWT_SECRET через SHA-256 (для демо; в продакшене — отдельный ключ)."""
    global _fernet_cache
    if _fernet_cache is None:
        key = settings.data_encryption_key
        if not key:
            key = base64.urlsafe_b64encode(hashlib.sha256(settings.jwt_secret.encode()).digest()).decode()
        _fernet_cache = Fernet(key.encode())
    return _fernet_cache


def encrypt(text: str) -> str:
    return _fernet().encrypt(text.encode()).decode()


def decrypt(token: str | None) -> str:
    """Расшифровка. None -> пустая строка; чужой/повреждённый шифротекст -> пометка, без падения."""
    if not token:
        return ""
    try:
        return _fernet().decrypt(token.encode()).decode()
    except InvalidToken:
        return "[unreadable]"


def encrypt_bytes(data: bytes) -> str:
    """Шифрование двоичных данных (фото). Результат — строка base64, хранится в Text-колонке."""
    return _fernet().encrypt(data).decode()


def decrypt_bytes(token: str) -> bytes:
    return _fernet().decrypt(token.encode())


def mask_phone(phone: str) -> str:
    """+998901234567 -> +998 ** *** 45 67 (в интерфейсе и логах показываем только хвост)."""
    digits = re.sub(r"\D", "", phone)
    if len(digits) < 4:
        return ""
    return f"+{digits[:3]} ** *** {digits[-4:-2]} {digits[-2:]}"


# ======================================================================================
# 7. Журнал аудита
# ======================================================================================
def audit(db: Session, action: str, user_id: int | None = None, target_id: int | None = None,
          request: Request | None = None, detail: str = "") -> None:
    """Записывает действие в журнал. Ошибка записи журнала никогда не ломает основной запрос."""
    try:
        db.add(AuditLog(user_id=user_id, action=action, target_id=target_id,
                        ip=client_ip(request), detail=detail[:255] or None))
        db.commit()
    except Exception as e:  # noqa: BLE001 — журнал вторичен, основная операция важнее
        db.rollback()
        log.warning("audit failed: %s", e)
