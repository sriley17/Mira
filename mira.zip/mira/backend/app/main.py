"""
main.py — ТОЧКА ВХОДА BACKEND (FastAPI)
======================================
Запуск (из папки backend/):
    uvicorn app.main:app --port 8000
Документация API (Swagger): http://localhost:8000/docs

Что происходит при старте (lifespan):
  1. миграции: добавляем новые колонки, шифруем старые открытые данные, создаём таблицы;
  2. демо-данные (если база пустая);
  3. фоновые задачи: симулятор устройства и планировщик напоминаний о лекарствах.

Слои защиты на каждый HTTP-запрос (middleware, выполняются по очереди):
  • CORS — браузер пустит к API только разрешённые сайты (CORS_ORIGINS);
  • security headers — запрет встраивания в чужие сайты (clickjacking), запрет «угадывания»
    типа файла, строгая политика referrer, запрет кэширования ответов с медданными;
  • ограничение размера тела запроса (1 МБ, для фото профиля 6 МБ) — защита от «заваливания» сервера.
"""
import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from . import migrations
from .config import get_settings, warn_insecure_defaults
from .database import SessionLocal
from .routers import admin, ai, appointments, auth, device, dmed, export, identity, measurements, medications, \
    messages, notes, notifications, profile, wellbeing, ws
from .services.demo import seed_demo
from .services.medications import reminder_loop
from .services.simulator import run_simulator

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
settings = get_settings()
MAX_BODY = 1_000_000   # 1 МБ — с запасом для любых запросов MIRA
MAX_PHOTO_BODY = 6_000_000   # загрузка фото профиля — до 5 МБ + служебные данные формы


@asynccontextmanager
async def lifespan(app: FastAPI):
    warn_insecure_defaults()
    migrations.run()
    if settings.demo_seed:
        with SessionLocal() as db:
            seed_demo(db)
    tasks = [asyncio.create_task(reminder_loop())]
    if settings.simulator_enabled:
        tasks.append(asyncio.create_task(run_simulator()))
    yield
    for t in tasks:     # аккуратно останавливаем фоновые задачи при выключении сервера
        t.cancel()


app = FastAPI(title="MIRA — Medical Intelligent Rehabilitation Assistant API", version="2.3.0", lifespan=lifespan)

app.add_middleware(CORSMiddleware, allow_origins=[o.strip() for o in settings.cors_origins.split(",")],
                   allow_credentials=False, allow_methods=["GET", "POST", "PUT", "DELETE"],
                   allow_headers=["Authorization", "Content-Type", "X-Device-Serial", "X-Device-Key", "X-Device-Id"])


@app.middleware("http")
async def security_layer(request: Request, call_next):
    # 1) слишком большой запрос отклоняем, не читая его
    length = request.headers.get("content-length")
    limit = MAX_PHOTO_BODY if request.url.path in ("/api/profile/photo", "/api/identity/verify") else MAX_BODY
    if length and length.isdigit() and int(length) > limit:
        return JSONResponse({"detail": "Request too large"}, status_code=413)
    response = await call_next(request)
    # 2) защитные заголовки
    h = response.headers
    h["X-Content-Type-Options"] = "nosniff"
    h["X-Frame-Options"] = "DENY"
    h["Referrer-Policy"] = "no-referrer"
    h["Permissions-Policy"] = "geolocation=(), camera=(), microphone=()"
    if request.url.path.startswith("/api/"):
        h["Cache-Control"] = "no-store"      # медданные не должны оседать в кэше браузера/прокси
    if not request.url.path.startswith(("/docs", "/redoc", "/openapi")):
        h["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none'"
    return response


for r in (auth.router, measurements.router, messages.router, device.router, ai.router, export.router,
          admin.router, medications.router, wellbeing.router, appointments.router, dmed.router, profile.router,
          identity.router, notifications.router, notes.router, ws.router):
    app.include_router(r)


@app.get("/api/health")
def health():
    """Проверка «жив ли сервер» — для мониторинга и docker healthcheck."""
    return {"status": "ok", "version": app.version, "pinfl_required": settings.pinfl_required}
