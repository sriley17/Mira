"""
models.py — ТАБЛИЦЫ БАЗЫ ДАННЫХ (ORM на SQLAlchemy 2.0)
=====================================================
Каждый класс = одна таблица. Каждое поле `Mapped[...] = mapped_column(...)` = одна колонка.
Код одинаково работает с PostgreSQL (продакшен) и SQLite (демо на ноутбуке).

Правило безопасности: всё, что является личной/медицинской информацией в виде свободного
текста (сообщения, чат с ИИ, телефон, ПИНФЛ, заметки к лекарствам, причина записи),
хранится ЗАШИФРОВАННЫМ (колонки с суффиксом `_enc`). Шифрует/расшифровывает security.py.
Числовые показатели (пульс и т.п.) хранятся открыто, чтобы по ним можно было строить отчёты.
"""
from datetime import date, datetime, timezone

from sqlalchemy import Boolean, Date, DateTime, Float, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


def utcnow() -> datetime:
    """Текущее время в UTC без часового пояса (так проще хранить в любой БД).
    В интерфейсе время переводится в часовой пояс пользователя."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


# ======================================================================================
# Пользователи и устройства
# ======================================================================================
class User(Base):
    """Пользователь портала: пациент или врач."""
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)   # логин
    password_hash: Mapped[str] = mapped_column(String(255))                     # bcrypt-хэш, НЕ пароль
    first_name: Mapped[str] = mapped_column(String(100))
    last_name: Mapped[str] = mapped_column(String(100))
    age: Mapped[int] = mapped_column(Integer)
    gender: Mapped[str] = mapped_column(String(10))                             # male / female
    role: Mapped[str] = mapped_column(String(10), index=True)                   # patient / doctor
    doctor_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)  # лечащий врач

    # Одобрение: пациент после регистрации ждёт, пока врач его подтвердит.
    # pending -> approved (доступ открыт) или rejected (доступ закрыт).
    status: Mapped[str] = mapped_column(String(10), default="approved", index=True)

    phone_enc: Mapped[str | None] = mapped_column(Text, nullable=True)   # телефон (для SMS), зашифрован
    pinfl_enc: Mapped[str | None] = mapped_column(Text, nullable=True)   # ПИНФЛ для Dmed, зашифрован
    # Анкета (отчество, дата рождения, адрес, место работы, должность, контакт родственника...).
    # Хранится ОДНИМ зашифрованным JSON: даже администратор БД не прочитает её без ключа.
    profile_enc: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_login: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    # Согласие на обработку персональных данных (окно при регистрации): когда и какую версию принял
    consent_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    consent_version: Mapped[str | None] = mapped_column(String(20), nullable=True)
    # Проверка личности (MyID, анализ лица) при первом входе: none -> verified
    identity_status: Mapped[str] = mapped_column(String(12), default="none")
    identity_verified_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    identity_source: Mapped[str | None] = mapped_column(String(20), nullable=True)   # myid / oneid / demo
    # Вход через OneID: уникальный идентификатор пользователя в OneID (хэш, не ПИНФЛ)
    oneid_sub: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    # Когда пользователь последний раз открывал уведомления (всё, что новее, — «непрочитанное»)
    notif_seen_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    device: Mapped["Device | None"] = relationship(back_populates="owner", uselist=False)


class Device(Base):
    """Носимое устройство MIRA, привязанное к пациенту (один пациент — одно устройство)."""
    __tablename__ = "devices"

    id: Mapped[int] = mapped_column(primary_key=True)
    serial: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    # Ключ устройства храним зашифрованным; сравнение идёт за постоянное время (hmac.compare_digest)
    api_key_enc: Mapped[str] = mapped_column(Text)
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id"), unique=True)
    battery: Mapped[float] = mapped_column(Float, default=100.0)
    connected: Mapped[bool] = mapped_column(Boolean, default=True)
    lat: Mapped[float] = mapped_column(Float, default=41.3111)     # последняя сохранённая точка GPS
    lon: Mapped[float] = mapped_column(Float, default=69.2797)
    gps_updated: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)  # когда обновили GPS
    firmware: Mapped[str] = mapped_column(String(20), default="1.1.0")
    last_seen: Mapped[datetime] = mapped_column(DateTime, default=utcnow)   # последний сигнал от устройства

    owner: Mapped[User] = relationship(back_populates="device")


# ======================================================================================
# Медицинские данные
# ======================================================================================
class Measurement(Base):
    """Одно измерение с устройства (строка на момент времени)."""
    __tablename__ = "measurements"
    # Составной индекс: самые частые запросы — «измерения пациента X за период»
    __table_args__ = (Index("ix_meas_user_ts", "user_id", "ts"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    heart_rate: Mapped[float] = mapped_column(Float)      # пульс, уд/мин
    systolic: Mapped[float] = mapped_column(Float)        # верхнее давление, мм рт.ст.
    diastolic: Mapped[float] = mapped_column(Float)       # нижнее давление, мм рт.ст.
    glucose: Mapped[float] = mapped_column(Float)         # сахар, ммоль/л
    resp_rate: Mapped[float] = mapped_column(Float)       # дыхание, вдохов/мин
    spo2: Mapped[float] = mapped_column(Float)            # насыщение кислородом, %
    calories: Mapped[float] = mapped_column(Float)        # ккал, потраченные за интервал
    body_temp: Mapped[float] = mapped_column(Float)       # температура тела, °C
    room_temp: Mapped[float] = mapped_column(Float)       # температура комнаты, °C


class Alert(Base):
    """Тревога по показателю. ВИДНА ТОЛЬКО ВРАЧУ (пациента не пугаем — требование ТЗ)."""
    __tablename__ = "alerts"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)   # пациент
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    metric: Mapped[str] = mapped_column(String(30))
    value: Mapped[float] = mapped_column(Float)
    level: Mapped[str] = mapped_column(String(10))            # warning / critical
    ambulance_called: Mapped[bool] = mapped_column(Boolean, default=False)
    acknowledged: Mapped[bool] = mapped_column(Boolean, default=False)   # врач отметил «принято»
    lat: Mapped[float | None] = mapped_column(Float, nullable=True)
    lon: Mapped[float | None] = mapped_column(Float, nullable=True)


class Message(Base):
    """Сообщения врач <-> пациент. Текст зашифрован (body_enc)."""
    __tablename__ = "messages"

    id: Mapped[int] = mapped_column(primary_key=True)
    sender_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    receiver_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    body_enc: Mapped[str] = mapped_column(Text)
    kind: Mapped[str] = mapped_column(String(20), default="message")   # message / recommendation / alert / system
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    read: Mapped[bool] = mapped_column(Boolean, default=False)


class ChatMessage(Base):
    """История чата с локальным ИИ (зашифрована). У врача — отдельный чат по каждому пациенту."""
    __tablename__ = "ai_chat"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    patient_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    role: Mapped[str] = mapped_column(String(10))          # user / assistant
    body_enc: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


# ======================================================================================
# Лекарства и напоминания
# ======================================================================================
class Medication(Base):
    """Назначенное лекарство. times = время приёма по местному времени, например "08:00,20:00"."""
    __tablename__ = "medications"

    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))   # врач или сам пациент
    name: Mapped[str] = mapped_column(String(120))
    dose: Mapped[str] = mapped_column(String(60))                     # "500 мг", "1 таблетка"
    times: Mapped[str] = mapped_column(String(120))                   # "08:00,20:00"
    start_date: Mapped[date] = mapped_column(Date)
    end_date: Mapped[date | None] = mapped_column(Date, nullable=True)  # у антибиотиков курс конечен
    is_antibiotic: Mapped[bool] = mapped_column(Boolean, default=False)
    notes_enc: Mapped[str | None] = mapped_column(Text, nullable=True)  # «после еды» и т.п.
    sms_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class MedicationIntake(Base):
    """Одна запланированная доза: когда напомнили и когда пациент отметил «принял».
    Уникальность (medication_id, scheduled_at) защищает от повторных SMS за одну и ту же дозу."""
    __tablename__ = "medication_intakes"
    __table_args__ = (Index("ux_intake_med_time", "medication_id", "scheduled_at", unique=True),)

    id: Mapped[int] = mapped_column(primary_key=True)
    medication_id: Mapped[int] = mapped_column(ForeignKey("medications.id"), index=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    scheduled_at: Mapped[datetime] = mapped_column(DateTime)            # UTC
    reminded_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    sms_status: Mapped[str] = mapped_column(String(20), default="pending")  # pending/sent/demo/failed/off
    taken_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


# ======================================================================================
# Задачи и цели
# ======================================================================================
class Goal(Base):
    """Цель пациента.
    kind:
      calories  — сжечь N ккал в день (прогресс считаем по измерениям)
      sleep     — спать N часов (прогресс — из анализа сна)
      water / steps / custom — отмечаются вручную (value_done)
    """
    __tablename__ = "goals"

    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    kind: Mapped[str] = mapped_column(String(20))
    title: Mapped[str] = mapped_column(String(120))
    target: Mapped[float] = mapped_column(Float)
    unit: Mapped[str] = mapped_column(String(20), default="")
    value_done: Mapped[float] = mapped_column(Float, default=0)   # для ручных целей
    done_date: Mapped[date | None] = mapped_column(Date, nullable=True)  # за какой день value_done
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


# ======================================================================================
# Запись к врачу
# ======================================================================================
class Appointment(Base):
    """Заявка на приём. status: requested -> approved / declined; cancelled — отменена пациентом."""
    __tablename__ = "appointments"
    __table_args__ = (Index("ix_appt_doctor_start", "doctor_id", "start"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    doctor_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    start: Mapped[datetime] = mapped_column(DateTime)          # UTC
    minutes: Mapped[int] = mapped_column(Integer, default=30)
    status: Mapped[str] = mapped_column(String(12), default="requested")
    reason_enc: Mapped[str | None] = mapped_column(Text, nullable=True)
    doctor_note_enc: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


# ======================================================================================
# Безопасность и аудит
# ======================================================================================
class AuditLog(Base):
    """Журнал действий: вход, неудачный вход, одобрение пациента, просмотр данных пациента врачом...
    В медицине важно знать, КТО и КОГДА смотрел данные пациента."""
    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(primary_key=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow, index=True)
    user_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    action: Mapped[str] = mapped_column(String(40))           # login_ok, login_fail, approve, view_patient...
    target_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    detail: Mapped[str | None] = mapped_column(String(255), nullable=True)


class RevokedToken(Base):
    """«Чёрный список» токенов: после выхода токен больше не принимается, даже если срок не истёк."""
    __tablename__ = "revoked_tokens"

    jti: Mapped[str] = mapped_column(String(64), primary_key=True)   # уникальный id токена
    expires_at: Mapped[datetime] = mapped_column(DateTime)            # после этой даты запись можно удалить


class SmsLog(Base):
    """Все отправленные SMS (напоминания о лекарствах, SOS). Текст зашифрован."""
    __tablename__ = "sms_log"

    id: Mapped[int] = mapped_column(primary_key=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    user_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    purpose: Mapped[str] = mapped_column(String(20))       # medication / sos
    status: Mapped[str] = mapped_column(String(10))        # sent / demo / failed
    body_enc: Mapped[str] = mapped_column(Text)


class UserPhoto(Base):
    """Фото профиля: у пациента — фото паспорта (для идентификации в клинике),
    у врача — фото в медицинской форме. Картинка хранится ЗАШИФРОВАННОЙ (Fernet),
    отдаётся только владельцу, его врачу (для пациента) и его пациентам (для фото врача)."""
    __tablename__ = "user_photos"

    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), primary_key=True)
    kind: Mapped[str] = mapped_column(String(20))          # passport / uniform
    mime: Mapped[str] = mapped_column(String(20))          # image/jpeg
    data_enc: Mapped[str] = mapped_column(Text)            # зашифрованные байты JPEG
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class UserDevice(Base):
    """Устройства (браузеры), с которых разрешён вход. ПРАВИЛО: один аккаунт — одно устройство.
    Первое устройство одобряется автоматически. Вход с нового устройства создаёт запрос,
    который нужно подтвердить с уже одобренного устройства (защита от кражи пароля)."""
    __tablename__ = "user_devices"
    __table_args__ = (Index("ux_user_device", "user_id", "device_hash", unique=True),)

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    device_hash: Mapped[str] = mapped_column(String(64))       # SHA-256 от id устройства (сам id не храним)
    label: Mapped[str] = mapped_column(String(120), default="")  # «Chrome · Windows» — для списка устройств
    status: Mapped[str] = mapped_column(String(10), default="pending")   # approved / pending / revoked
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_seen: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class IdentityCheck(Base):
    """Попытки проверки личности (MyID). Селфи хранится ЗАШИФРОВАННЫМ и только для разбора споров."""
    __tablename__ = "identity_checks"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    ts: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    source: Mapped[str] = mapped_column(String(20))            # myid / demo
    result: Mapped[str] = mapped_column(String(12))            # verified / rejected / error
    score: Mapped[float | None] = mapped_column(Float, nullable=True)
    reason: Mapped[str | None] = mapped_column(String(120), nullable=True)
    selfie_enc: Mapped[str | None] = mapped_column(Text, nullable=True)


class DoctorNote(Base):
    """Заметки врача о пациенте — ТОЛЬКО ДЛЯ ВРАЧА (прогноз, подозрения, план).
    Такие сведения могут напугать пациента, поэтому пациенту они не отдаются никогда."""
    __tablename__ = "doctor_notes"

    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    doctor_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    body_enc: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
