"""
doctor_ai.py — ЛОКАЛЬНЫЙ ИИ-АНАЛИТИК ДЛЯ ВРАЧА (поддержка клинических решений)
============================================================================
Встроенный режим отвечает по статистике из clinical.py: сводка, разбор показателя, тренды,
тревоги, приоритизация пациентов по риску, вопросы пациенту, черновик рекомендации.
Если на сервере настроена локальная LLM (Ollama, local_llm.py) — она получает ту же статистику
в виде JSON (llm_system) и формулирует ответ. Облачные ИИ не используются.
ИИ не ставит окончательный диагноз и не назначает дозы — решение всегда за врачом.
"""
import json
import random

from .clinical import NORMAL

# ------------------------------------------------------------------ texts
L = {
    "ru": {
        "m": {"heart_rate": "ЧСС", "systolic": "САД", "diastolic": "ДАД", "glucose": "Глюкоза", "resp_rate": "ЧДД",
              "spo2": "SpO₂", "body_temp": "Т тела", "room_temp": "Т комнаты"},
        "u": {"heart_rate": "уд/мин", "systolic": "мм рт.ст.", "diastolic": "мм рт.ст.", "glucose": "ммоль/л",
              "resp_rate": "/мин", "spo2": "%", "body_temp": "°C", "room_temp": "°C"},
        "summary_h": ["Клиническая сводка", "Сводка по пациенту", "Обзор состояния пациента"],
        "patient": "**{name}** · возраст: {age} · пол: {gender}. Данных за 30 дней: {n} измерений, покрытие за сутки {cov}%.",
        "male": "мужской", "female": "женский",
        "table_h": "| Показатель | Последнее | Ср. 24ч | Ср. 7д | Мин–Макс 7д | В норме 7д | Тренд |\n|---|---|---|---|---|---|---|",
        "trend": {"up": "↑ {p}%", "down": "↓ {p}%", "stable": "стабильно"},
        "findings_h": "**Ключевые находки:**", "review_h": "**На что обратить внимание:**",
        "questions_h": "**Вопросы пациенту:**", "no_findings": "Значимых отклонений за 7 дней не выявлено.",
        "alerts_h": "**Тревоги за 7 дней:**", "no_alerts": "Тревог за 7 дней не было.",
        "alerts_line": "- {metric}: {level} × {count}", "crit": "критичная", "warn": "внимание",
        "amb": "Вызовов скорой: {n}.", "last_alert": "Последняя: {metric} = {value} ({level}).",
        "dip": "Суточный профиль САД: день {day}, ночь {night}, ночное снижение {dip}% — {type}.",
        "dip_t": {"dipper": "нормальный профиль (dipper)", "non_dipper": "недостаточное снижение (non-dipper)",
                  "extreme": "чрезмерное снижение (extreme dipper)"},
        "cv": "Вариабельность глюкозы (CV): {cv}%.",
        "cohort_h": ["Пациенты по уровню риска", "Приоритизация пациентов", "Кого посмотреть в первую очередь"],
        "cohort_t": "| # | Пациент | Риск | Ключевые находки | Крит. тревоги 7д |\n|---|---|---|---|---|",
        "cohort_hint": "Риск — сумма весов находок и критических тревог за 7 дней. Для подробностей выберите пациента и спросите «сводка».",
        "draft_h": "**Черновик сообщения пациенту** (проверьте и отправьте в разделе «Сообщения»):",
        "draft_open": ["Здравствуйте, {first}!", "Добрый день, {first}!"],
        "draft_ok": "Я посмотрел(а) ваши показатели за последнюю неделю — в целом они стабильные, продолжайте в том же режиме.",
        "draft_close": ["Продолжайте измерения в обычном режиме. Если появятся жалобы — сразу напишите мне.",
                        "Если самочувствие ухудшится, не ждите — напишите мне или звоните 103."],
        "deep_h": "Разбор: {metric} за 7 и 30 дней",
        "deep": "- Последнее: **{last}** {unit}; среднее 24ч / 7д / 30д: {a24} / {a7} / {a30}\n"
                "- Диапазон 7д: {min}–{max}, SD {sd}; время в целевом диапазоне ({lo}–{hi}): **{tir}%**\n"
                "- Эпизодов ниже нормы: {below}, выше нормы: {above}; тренд 24ч к 7д: {trend}",
        "disclaimer": ["_Это поддержка принятия решений, а не диагноз. Окончательная оценка — за вами._",
                       "_Выводы основаны на данных домашнего устройства; сверяйте с клинической картиной._"],
        "followup": ["Разобрать подробнее давление, глюкозу или ЧСС?", "Подготовить черновик рекомендации пациенту?",
                     "Показать, кого из пациентов стоит посмотреть в первую очередь?",
                     "Сформировать список вопросов для пациента?"],
        "no_data": "По пациенту {name} пока нет измерений — проверьте подключение устройства.",
        "no_patient": "Выберите пациента вверху страницы, чтобы я проанализировал его данные.",
        "capabilities": "Я могу: дать **сводку** по пациенту, разобрать **давление / ЧСС / глюкозу / SpO₂ / температуру**, "
                        "показать **тревоги**, **тренды**, **приоритизировать пациентов** по риску, подготовить "
                        "**черновик рекомендации** и **вопросы пациенту**.",
    },
    "uz": {
        "m": {"heart_rate": "YUQ", "systolic": "SQB", "diastolic": "DQB", "glucose": "Glyukoza", "resp_rate": "NCh",
              "spo2": "SpO₂", "body_temp": "Tana T", "room_temp": "Xona T"},
        "u": {"heart_rate": "zarba/daq", "systolic": "mm sim.ust.", "diastolic": "mm sim.ust.", "glucose": "mmol/l",
              "resp_rate": "/daq", "spo2": "%", "body_temp": "°C", "room_temp": "°C"},
        "summary_h": ["Klinik xulosa", "Bemor bo'yicha xulosa", "Bemor holati sharhi"],
        "patient": "**{name}** · yosh: {age} · jins: {gender}. 30 kunlik ma'lumot: {n} o'lchov, bir kunlik qamrov {cov}%.",
        "male": "erkak", "female": "ayol",
        "table_h": "| Ko'rsatkich | Oxirgi | O'rt. 24s | O'rt. 7k | Min–Maks 7k | Me'yorda 7k | Trend |\n|---|---|---|---|---|---|---|",
        "trend": {"up": "↑ {p}%", "down": "↓ {p}%", "stable": "barqaror"},
        "findings_h": "**Asosiy topilmalar:**", "review_h": "**E'tibor berish kerak:**",
        "questions_h": "**Bemorga savollar:**", "no_findings": "7 kun ichida sezilarli og'ishlar aniqlanmadi.",
        "alerts_h": "**7 kunlik signallar:**", "no_alerts": "7 kun ichida signallar bo'lmadi.",
        "alerts_line": "- {metric}: {level} × {count}", "crit": "kritik", "warn": "diqqat",
        "amb": "Tez yordam chaqiruvlari: {n}.", "last_alert": "Oxirgisi: {metric} = {value} ({level}).",
        "dip": "SQB sutkalik profili: kunduz {day}, tun {night}, tungi pasayish {dip}% — {type}.",
        "dip_t": {"dipper": "normal profil (dipper)", "non_dipper": "yetarli pasaymaslik (non-dipper)",
                  "extreme": "haddan tashqari pasayish (extreme dipper)"},
        "cv": "Glyukoza o'zgaruvchanligi (CV): {cv}%.",
        "cohort_h": ["Bemorlar xavf darajasi bo'yicha", "Bemorlarni ustuvorlashtirish", "Birinchi navbatda kimni ko'rish kerak"],
        "cohort_t": "| # | Bemor | Xavf | Asosiy topilmalar | Kritik signallar 7k |\n|---|---|---|---|---|",
        "cohort_hint": "Xavf — topilmalar va 7 kunlik kritik signallar vaznlari yig'indisi. Batafsil uchun bemorni tanlang va «xulosa» deb so'rang.",
        "draft_h": "**Bemorga xabar qoralamasi** (tekshiring va «Xabarlar» bo'limida yuboring):",
        "draft_open": ["Assalomu alaykum, {first}!", "Xayrli kun, {first}!"],
        "draft_ok": "Oxirgi haftadagi ko'rsatkichlaringizni ko'rib chiqdim — umuman barqaror, shu tartibda davom eting.",
        "draft_close": ["O'lchovlarni odatdagidek davom ettiring. Shikoyat paydo bo'lsa — darhol yozing.",
                        "Ahvolingiz yomonlashsa, kutmang — menga yozing yoki 103 ga qo'ng'iroq qiling."],
        "deep_h": "Tahlil: {metric}, 7 va 30 kun",
        "deep": "- Oxirgi: **{last}** {unit}; o'rtacha 24s / 7k / 30k: {a24} / {a7} / {a30}\n"
                "- 7k oralig'i: {min}–{max}, SD {sd}; maqsadli oraliqda ({lo}–{hi}): **{tir}%**\n"
                "- Me'yordan past epizodlar: {below}, yuqori: {above}; 24s va 7k trendi: {trend}",
        "disclaimer": ["_Bu qaror qabul qilishni qo'llab-quvvatlash, tashxis emas. Yakuniy baho — sizniki._",
                       "_Xulosalar uy qurilmasi ma'lumotlariga asoslangan; klinik manzara bilan solishtiring._"],
        "followup": ["Bosim, glyukoza yoki YUQni batafsil tahlil qilaylikmi?", "Bemorga tavsiya qoralamasini tayyorlaymi?",
                     "Qaysi bemorlarni birinchi ko'rish kerakligini ko'rsataymi?", "Bemorga savollar ro'yxatini tuzaymi?"],
        "no_data": "{name} bo'yicha hali o'lchovlar yo'q — qurilma ulanishini tekshiring.",
        "no_patient": "Ma'lumotlarini tahlil qilishim uchun sahifa tepasida bemorni tanlang.",
        "capabilities": "Men: bemor bo'yicha **xulosa**, **bosim / YUQ / glyukoza / SpO₂ / harorat** tahlili, **signallar**, "
                        "**trendlar**, bemorlarni xavf bo'yicha **ustuvorlashtirish**, **tavsiya qoralamasi** va "
                        "**bemorga savollar** tayyorlay olaman.",
    },
    "en": {
        "m": {"heart_rate": "HR", "systolic": "SBP", "diastolic": "DBP", "glucose": "Glucose", "resp_rate": "RR",
              "spo2": "SpO₂", "body_temp": "Body T", "room_temp": "Room T"},
        "u": {"heart_rate": "bpm", "systolic": "mmHg", "diastolic": "mmHg", "glucose": "mmol/L", "resp_rate": "/min",
              "spo2": "%", "body_temp": "°C", "room_temp": "°C"},
        "summary_h": ["Clinical summary", "Patient summary", "Patient status overview"],
        "patient": "**{name}** · age: {age} · sex: {gender}. 30-day data: {n} readings, 24 h coverage {cov}%.",
        "male": "male", "female": "female",
        "table_h": "| Metric | Last | Avg 24h | Avg 7d | Min–Max 7d | In range 7d | Trend |\n|---|---|---|---|---|---|---|",
        "trend": {"up": "↑ {p}%", "down": "↓ {p}%", "stable": "stable"},
        "findings_h": "**Key findings:**", "review_h": "**Points to review:**",
        "questions_h": "**Questions for the patient:**", "no_findings": "No significant deviations over 7 days.",
        "alerts_h": "**Alerts over 7 days:**", "no_alerts": "No alerts in the last 7 days.",
        "alerts_line": "- {metric}: {level} × {count}", "crit": "critical", "warn": "warning",
        "amb": "Ambulance calls: {n}.", "last_alert": "Latest: {metric} = {value} ({level}).",
        "dip": "SBP day/night profile: day {day}, night {night}, nocturnal dip {dip}% — {type}.",
        "dip_t": {"dipper": "normal (dipper)", "non_dipper": "insufficient dip (non-dipper)",
                  "extreme": "excessive dip (extreme dipper)"},
        "cv": "Glucose variability (CV): {cv}%.",
        "cohort_h": ["Patients by risk", "Patient prioritisation", "Who to review first"],
        "cohort_t": "| # | Patient | Risk | Key findings | Critical alerts 7d |\n|---|---|---|---|---|",
        "cohort_hint": "Risk = weighted findings plus critical alerts over 7 days. Select a patient and ask for a “summary” for details.",
        "draft_h": "**Draft message to the patient** (review and send in “Messages”):",
        "draft_open": ["Hello {first},", "Good day {first},"],
        "draft_ok": "I've reviewed your readings for the past week — overall they are stable, keep up your routine.",
        "draft_close": ["Keep measuring as usual. If you have any complaints, message me right away.",
                        "If you feel worse, don't wait — message me or call emergency services."],
        "deep_h": "Deep dive: {metric}, 7 and 30 days",
        "deep": "- Last: **{last}** {unit}; average 24h / 7d / 30d: {a24} / {a7} / {a30}\n"
                "- 7d range: {min}–{max}, SD {sd}; time in target range ({lo}–{hi}): **{tir}%**\n"
                "- Episodes below range: {below}, above: {above}; 24h vs 7d trend: {trend}",
        "disclaimer": ["_This is decision support, not a diagnosis. The final assessment is yours._",
                       "_Findings are based on home-device data; correlate with the clinical picture._"],
        "followup": ["Shall I go deeper into blood pressure, glucose or heart rate?",
                     "Shall I draft a recommendation for the patient?",
                     "Shall I show which patients to review first?", "Shall I list questions for the patient?"],
        "no_data": "No readings for {name} yet — check the device connection.",
        "no_patient": "Select a patient at the top of the page so I can analyse their data.",
        "capabilities": "I can give a patient **summary**, analyse **blood pressure / HR / glucose / SpO₂ / temperature**, "
                        "show **alerts** and **trends**, **prioritise patients** by risk, and prepare a **draft "
                        "recommendation** and **questions for the patient**.",
    },
}

# finding -> (finding text, review point, question for patient, patient-friendly advice)
FLAGS = {
    "ru": {
        "home_bp_high": ("Среднее домашнее АД за 7 дней {sys}/{dia} — не ниже порога 135/85.",
                         "Оценить эффективность текущей антигипертензивной тактики; рассмотреть СМАД.",
                         "Регулярно ли принимаются назначенные препараты? Когда обычно измеряется давление?",
                         "Давление в последние дни держится выше целевого — ограничьте соль, измеряйте утром и вечером."),
        "bp_crisis_episode": ("Эпизоды САД ≥ 180 мм рт.ст. (максимум {max}).",
                              "Уточнить симптомы во время эпизодов; исключить поражение органов-мишеней.",
                              "Были ли головная боль, нарушение зрения, боль в груди во время подъёмов давления?",
                              "Если давление снова поднимется выше 180/110 с головной болью или болью в груди — сразу звоните 103."),
        "non_dipper": ("Недостаточное ночное снижение САД ({dip}%).",
                       "Нарушенный суточный профиль АД — повод для СМАД и оценки сна (в т.ч. апноэ).",
                       "Как пациент спит? Есть ли храп, ночные пробуждения?",
                       "Постарайтесь ложиться в одно время и не пить кофе после обеда."),
        "bp_trend_up": ("САД за сутки выше недельного среднего на {trend}%.",
                        "Отследить динамику в ближайшие дни; уточнить причины (стресс, соль, пропуск препаратов).",
                        "Что изменилось за последние дни: стресс, питание, сон, лекарства?",
                        "Давление за сутки немного выросло — следите за солью и стрессом, продолжайте измерения."),
        "tachycardia": ("Средняя ЧСС за 7 дней {hr} уд/мин — выше 100.",
                        "Оценить причины тахикардии (анемия, щитовидная железа, обезвоживание); рассмотреть ЭКГ.",
                        "Бывают ли сердцебиение, одышка, слабость? Употребление кофеина/энергетиков?",
                        "Пульс чаще обычного — пейте достаточно воды, ограничьте кофе и энергетики."),
        "bradycardia": ("Средняя ЧСС за 7 дней {hr} уд/мин — ниже 55.",
                        "Сопоставить с препаратами (β-блокаторы) и симптомами; рассмотреть ЭКГ.",
                        "Бывают ли головокружение, обмороки, слабость?",
                        "Если появятся головокружение или обмороки — сообщите мне сразу."),
        "hr_spikes": ("Пики ЧСС до {max} уд/мин.",
                      "Уточнить обстоятельства пиков; при повторении — холтеровское мониторирование.",
                      "В какие моменты бывает сильное сердцебиение? Связано ли с нагрузкой?",
                      "Если сердцебиение сопровождается болью в груди или одышкой — звоните 103."),
        "glucose_control": ("Гликемический контроль: среднее за 7 дней {g} ммоль/л, в диапазоне {tir}% времени.",
                            "Оценить HbA1c и текущую сахароснижающую тактику; разобрать питание.",
                            "Как питается пациент, есть ли поздние приёмы пищи, сладкие напитки?",
                            "Сахар чаще выходит за норму — уменьшите сладкое и сладкие напитки, гуляйте после еды."),
        "hypoglycemia": ("Эпизоды глюкозы ниже 3,9 ммоль/л: {n}.",
                         "Проверить риск гипогликемий (дозы, пропуски приёма пищи).",
                         "Были ли дрожь, потливость, чувство голода, спутанность?",
                         "При сахаре ниже 3,9 — съешьте 15 г быстрых углеводов (полстакана сока) и перемерьте через 15 минут."),
        "glucose_variability": ("Высокая вариабельность глюкозы (CV {cv}%).",
                                "Высокая вариабельность — оценить режим питания и терапию.",
                                "Регулярно ли питание? Есть ли большие перерывы между приёмами пищи?",
                                "Старайтесь есть в одно и то же время небольшими порциями."),
        "desaturation": ("Эпизоды SpO₂ ниже 92% (минимум {min}%).",
                         "Проверить технику измерения; при подтверждении — оценить дыхательную функцию и ночную оксиметрию.",
                         "Есть ли одышка, кашель, ночные пробуждения с нехваткой воздуха?",
                         "Если сатурация ниже 92% и есть одышка — сразу звоните 103."),
        "fever": ("Средняя температура за сутки {t} °C.",
                  "Уточнить источник лихорадки; контроль динамики.",
                  "Есть ли кашель, боль в горле, другие симптомы инфекции?",
                  "Температура повышена — пейте больше жидкости, отдыхайте; если выше 39 °C или держится 3 дня — сообщите."),
        "tachypnea": ("Средняя ЧДД за 7 дней {rr}/мин — выше нормы.",
                      "Оценить дыхательную и сердечную функцию.",
                      "Замечает ли пациент одышку при нагрузке или в покое?",
                      "Если одышка усиливается — сообщите мне."),
        "low_coverage": ("Покрытие данными за сутки только {cov}%.",
                         "Данных недостаточно для надёжных выводов — уточнить, носит ли пациент устройство.",
                         "Носите ли вы устройство постоянно? Были ли проблемы с ним?",
                         "Пожалуйста, носите устройство постоянно — так я вижу полную картину."),
        "device_issue": ("Проблема с устройством (заряд {bat}% или нет связи).",
                         "Напомнить пациенту о зарядке/подключении устройства.",
                         "Заряжено ли устройство, есть ли интернет?",
                         "Проверьте, пожалуйста, заряд и подключение устройства MIRA."),
    },
    "uz": {
        "home_bp_high": ("7 kunlik o'rtacha uy QB {sys}/{dia} — 135/85 chegarasidan past emas.",
                         "Joriy antigipertenziv taktika samaradorligini baholang; SMAD ni ko'rib chiqing.",
                         "Tayinlangan dorilar muntazam ichilyaptimi? Bosim odatda qachon o'lchanadi?",
                         "So'nggi kunlarda bosim maqsaddan yuqori — tuzni kamaytiring, ertalab va kechqurun o'lchang."),
        "bp_crisis_episode": ("SQB ≥ 180 mm sim.ust. epizodlari (maksimum {max}).",
                              "Epizodlar paytidagi belgilarni aniqlang; nishon-organlar zararlanishini istisno qiling.",
                              "Bosim ko'tarilganda bosh og'rig'i, ko'rish buzilishi, ko'krak og'rig'i bo'lganmi?",
                              "Bosim yana 180/110 dan oshib, bosh yoki ko'krak og'risa — darhol 103 ga qo'ng'iroq qiling."),
        "non_dipper": ("Tungi SQB pasayishi yetarli emas ({dip}%).",
                       "Buzilgan sutkalik QB profili — SMAD va uyquni (jumladan apnoe) baholash uchun sabab.",
                       "Bemor qanday uxlaydi? Xurrak, tungi uyg'onishlar bormi?",
                       "Har kuni bir vaqtda yoting va tushdan keyin qahva ichmang."),
        "bp_trend_up": ("Bir kunlik SQB haftalik o'rtachadan {trend}% yuqori.",
                        "Yaqin kunlarda dinamikani kuzating; sabablarni aniqlang (stress, tuz, dorini o'tkazib yuborish).",
                        "So'nggi kunlarda nima o'zgardi: stress, ovqatlanish, uyqu, dorilar?",
                        "Bir kunda bosim biroz oshdi — tuz va stressni kuzating, o'lchashni davom ettiring."),
        "tachycardia": ("7 kunlik o'rtacha YUQ {hr} zarba/daq — 100 dan yuqori.",
                        "Taxikardiya sabablarini baholang (kamqonlik, qalqonsimon bez, suvsizlanish); EKG ni ko'rib chiqing.",
                        "Yurak urishi, hansirash, holsizlik bormi? Kofein/energetiklar iste'moli?",
                        "Puls odatdagidan tez — yetarli suv iching, qahva va energetiklarni cheklang."),
        "bradycardia": ("7 kunlik o'rtacha YUQ {hr} zarba/daq — 55 dan past.",
                        "Dorilar (β-blokatorlar) va belgilar bilan solishtiring; EKG ni ko'rib chiqing.",
                        "Bosh aylanishi, hushdan ketish, holsizlik bo'ladimi?",
                        "Bosh aylanishi yoki hushdan ketish bo'lsa — darhol menga xabar bering."),
        "hr_spikes": ("YUQ cho'qqilari {max} zarba/daq gacha.",
                      "Cho'qqilar holatini aniqlang; takrorlansa — Xolter monitoringi.",
                      "Kuchli yurak urishi qachon bo'ladi? Yuklama bilan bog'liqmi?",
                      "Yurak urishi ko'krak og'rig'i yoki hansirash bilan bo'lsa — 103 ga qo'ng'iroq qiling."),
        "glucose_control": ("Glikemik nazorat: 7 kunlik o'rtacha {g} mmol/l, vaqtning {tir}% oraliqda.",
                            "HbA1c va joriy qand tushiruvchi taktikani baholang; ovqatlanishni tahlil qiling.",
                            "Bemor qanday ovqatlanadi, kechki ovqat, shirin ichimliklar bormi?",
                            "Qand tez-tez me'yordan chiqyapti — shirinlikni kamaytiring, ovqatdan keyin sayr qiling."),
        "hypoglycemia": ("Glyukoza 3,9 mmol/l dan past epizodlari: {n}.",
                         "Gipoglikemiya xavfini tekshiring (dozalar, ovqatni o'tkazib yuborish).",
                         "Titrash, terlash, ochlik hissi, chalkashlik bo'lganmi?",
                         "Qand 3,9 dan past bo'lsa — 15 g tez uglevod yeng (yarim stakan sharbat) va 15 daqiqadan so'ng qayta o'lchang."),
        "glucose_variability": ("Glyukozaning yuqori o'zgaruvchanligi (CV {cv}%).",
                                "Yuqori o'zgaruvchanlik — ovqatlanish rejimi va terapiyani baholang.",
                                "Ovqatlanish muntazammi? Ovqatlar orasida katta tanaffuslar bormi?",
                                "Har kuni bir vaqtda kichik porsiyalarda ovqatlanishga harakat qiling."),
        "desaturation": ("SpO₂ 92% dan past epizodlari (minimum {min}%).",
                         "O'lchash texnikasini tekshiring; tasdiqlansa — nafas funksiyasi va tungi oksimetriyani baholang.",
                         "Hansirash, yo'tal, havo yetishmay tungi uyg'onishlar bormi?",
                         "Saturatsiya 92% dan past va hansirash bo'lsa — darhol 103 ga qo'ng'iroq qiling."),
        "fever": ("Bir kunlik o'rtacha harorat {t} °C.",
                  "Isitma manbasini aniqlang; dinamikani nazorat qiling.",
                  "Yo'tal, tomoq og'rig'i, boshqa infeksiya belgilari bormi?",
                  "Harorat ko'tarilgan — ko'proq suyuqlik iching, dam oling; 39 °C dan oshsa yoki 3 kun davom etsa — xabar bering."),
        "tachypnea": ("7 kunlik o'rtacha NCh {rr}/daq — me'yordan yuqori.",
                      "Nafas va yurak funksiyasini baholang.",
                      "Bemor yuklamada yoki tinch holatda hansirashni sezadimi?",
                      "Hansirash kuchaysa — menga xabar bering."),
        "low_coverage": ("Bir kunlik ma'lumot qamrovi atigi {cov}%.",
                         "Ishonchli xulosa uchun ma'lumot yetarli emas — bemor qurilmani taqib yurishini aniqlang.",
                         "Qurilmani doim taqib yurasizmi? U bilan muammolar bo'lganmi?",
                         "Iltimos, qurilmani doim taqib yuring — shunda to'liq manzarani ko'raman."),
        "device_issue": ("Qurilma bilan muammo (quvvat {bat}% yoki aloqa yo'q).",
                         "Bemorga qurilmani zaryadlash/ulashni eslating.",
                         "Qurilma zaryadlanganmi, internet bormi?",
                         "Iltimos, MIRA qurilmasining quvvati va ulanishini tekshiring."),
    },
    "en": {
        "home_bp_high": ("7-day average home BP {sys}/{dia} — at or above the 135/85 threshold.",
                         "Assess the current antihypertensive approach; consider ambulatory BP monitoring (ABPM).",
                         "Are prescribed medicines taken regularly? When is BP usually measured?",
                         "Your blood pressure has been above target lately — cut down on salt and measure morning and evening."),
        "bp_crisis_episode": ("SBP episodes ≥ 180 mmHg (max {max}).",
                              "Clarify symptoms during episodes; rule out target-organ damage.",
                              "Any headache, visual disturbance or chest pain during BP rises?",
                              "If BP rises above 180/110 again with headache or chest pain, call emergency services immediately."),
        "non_dipper": ("Insufficient nocturnal SBP dip ({dip}%).",
                       "Abnormal circadian BP profile — reason for ABPM and sleep assessment (incl. apnoea).",
                       "How does the patient sleep? Snoring, night awakenings?",
                       "Try to go to bed at the same time and avoid coffee after lunch."),
        "bp_trend_up": ("24 h SBP is {trend}% above the weekly average.",
                        "Monitor the trend over the next days; clarify causes (stress, salt, missed doses).",
                        "What changed recently: stress, diet, sleep, medicines?",
                        "Your blood pressure rose a little over the last day — watch salt and stress and keep measuring."),
        "tachycardia": ("7-day average HR {hr} bpm — above 100.",
                        "Assess causes of tachycardia (anaemia, thyroid, dehydration); consider an ECG.",
                        "Any palpitations, breathlessness, weakness? Caffeine/energy drinks?",
                        "Your pulse is faster than usual — drink enough water and limit coffee and energy drinks."),
        "bradycardia": ("7-day average HR {hr} bpm — below 55.",
                        "Correlate with medication (β-blockers) and symptoms; consider an ECG.",
                        "Any dizziness, fainting, weakness?",
                        "If you feel dizzy or faint, let me know right away."),
        "hr_spikes": ("HR peaks up to {max} bpm.",
                      "Clarify circumstances of peaks; if recurrent, consider Holter monitoring.",
                      "When do strong palpitations occur? Related to exertion?",
                      "If palpitations come with chest pain or breathlessness, call emergency services."),
        "glucose_control": ("Glycaemic control: 7-day average {g} mmol/L, in range {tir}% of the time.",
                            "Assess HbA1c and the current glucose-lowering approach; review diet.",
                            "What does the patient eat — late meals, sugary drinks?",
                            "Your sugar is often out of range — cut down on sweets and sugary drinks, walk after meals."),
        "hypoglycemia": ("Glucose episodes below 3.9 mmol/L: {n}.",
                         "Check hypoglycaemia risk (doses, skipped meals).",
                         "Any tremor, sweating, hunger, confusion?",
                         "If sugar is below 3.9, eat 15 g of fast carbs (half a glass of juice) and re-check in 15 minutes."),
        "glucose_variability": ("High glucose variability (CV {cv}%).",
                                "High variability — assess meal pattern and therapy.",
                                "Are meals regular? Long gaps between meals?",
                                "Try to eat at the same times in small portions."),
        "desaturation": ("SpO₂ episodes below 92% (min {min}%).",
                         "Check measurement technique; if confirmed, assess respiratory function and overnight oximetry.",
                         "Any breathlessness, cough, waking at night short of breath?",
                         "If saturation is below 92% and you feel short of breath, call emergency services."),
        "fever": ("24 h average temperature {t} °C.",
                  "Identify the source of fever; monitor the trend.",
                  "Any cough, sore throat, other signs of infection?",
                  "You have a raised temperature — drink more fluids and rest; tell me if it exceeds 39 °C or lasts 3 days."),
        "tachypnea": ("7-day average RR {rr}/min — above normal.",
                      "Assess respiratory and cardiac function.",
                      "Does the patient notice breathlessness on exertion or at rest?",
                      "If breathlessness gets worse, let me know."),
        "low_coverage": ("Only {cov}% data coverage over 24 h.",
                         "Not enough data for reliable conclusions — check whether the patient wears the device.",
                         "Do you wear the device all the time? Any problems with it?",
                         "Please wear the device continuously so I can see the full picture."),
        "device_issue": ("Device problem (battery {bat}% or no connection).",
                         "Remind the patient to charge/connect the device.",
                         "Is the device charged and connected to the internet?",
                         "Please check the battery and connection of your MIRA device."),
    },
}

INTENTS = {
    "cohort": ["все пациент", "всех пациент", "кто из пациент", "зона риска", "зоне риска", "группа риска",
               "приоритет", "сравни", "кого посмотреть", "barcha bemor", "xavf guruh", "ustuvor", "solishtir",
               "all patients", "risk", "priorit", "compare", "who should"],
    "draft": ["черновик", "сообщение пациенту", "рекомендаци", "написать пациенту", "qoralama", "tavsiya",
              "bemorga xabar", "draft", "message to the patient", "recommendation"],
    "questions": ["вопрос", "что спросить", "savol", "question", "what to ask"],
    "alerts": ["тревог", "инцидент", "скорая", "signal", "tez yordam", "alert", "incident", "ambulance"],
    "trends": ["тренд", "динамик", "изменени", "trend", "dinamika", "o'zgarish", "change"],
    "deep_systolic": ["давлен", "ад ", "гиперт", "bosim", "pressure", "bp", "hypert"],
    "deep_heart_rate": ["пульс", "чсс", "сердц", "тахикард", "puls", "yurak", "heart", "pulse", "hr "],
    "deep_glucose": ["глюкоз", "сахар", "гликем", "диабет", "qand", "glyukoza", "glucose", "sugar", "diabet"],
    "deep_spo2": ["spo2", "spo₂", "сатурац", "кислород", "дыхан", "saturatsiya", "kislorod", "nafas", "oxygen",
                  "saturation", "breath"],
    "deep_body_temp": ["температур", "лихорад", "harorat", "isitma", "temperature", "fever"],
}


def _intent(text: str) -> str:
    for name, words in INTENTS.items():
        if any(w in text for w in words):
            return name
    return "summary"


def _flag_args(s: dict) -> dict:
    m = s["metrics"]
    return {"sys": m["systolic"]["avg7"], "dia": m["diastolic"]["avg7"], "max": m["systolic"]["max7"],
            "dip": s.get("bp_dip", {}).get("dip_pct"), "trend": m["systolic"].get("trend_pct"),
            "hr": m["heart_rate"]["avg7"], "g": m["glucose"]["avg7"], "tir": m["glucose"]["tir7"],
            "n": m["glucose"]["below7"], "cv": m["glucose"].get("cv7"), "min": m["spo2"]["min7"],
            "t": m["body_temp"]["avg24"], "rr": m["resp_rate"]["avg7"], "cov": s.get("coverage24"),
            "bat": s.get("device", {}).get("battery")}


def _flag_text(flag: str, s: dict, lang: str, idx: int) -> str:
    args = _flag_args(s)
    if flag == "hr_spikes":
        args["max"] = s["metrics"]["heart_rate"]["max7"]
    return FLAGS[lang][flag][idx].format(**args)


def _table(s: dict, lang: str) -> str:
    T = L[lang]
    rows = [T["table_h"]]
    for k in ["systolic", "diastolic", "heart_rate", "glucose", "spo2", "resp_rate", "body_temp"]:
        st = s["metrics"][k]
        tr = T["trend"].get(st.get("trend", "stable"), "").format(p=abs(st.get("trend_pct") or 0))
        rows.append(f"| {T['m'][k]}, {T['u'][k]} | {st['last']} | {st['avg24']} | {st['avg7']} | "
                    f"{st['min7']}–{st['max7']} | {st['tir7']}% | {tr} |")
    return "\n".join(rows)


def _summary(s: dict, lang: str) -> list[str]:
    T = L[lang]
    parts = [f"### {random.choice(T['summary_h'])}",
             T["patient"].format(name=s["name"], age=s["age"], gender=T.get(s["gender"], s["gender"]),
                                 n=s["n_30d"], cov=s.get("coverage24", 0)),
             _table(s, lang)]
    extra = []
    if s.get("bp_dip"):
        d = s["bp_dip"]
        extra.append(T["dip"].format(day=d["day"], night=d["night"], dip=d["dip_pct"], type=T["dip_t"][d["type"]]))
    if s["metrics"]["glucose"].get("cv7") is not None:
        extra.append(T["cv"].format(cv=s["metrics"]["glucose"]["cv7"]))
    if extra:
        parts.append(" ".join(extra))
    flags = s["flags"]
    if flags:
        parts.append(T["findings_h"] + "\n" + "\n".join(f"- {_flag_text(f, s, lang, 0)}" for f in flags))
        parts.append(T["review_h"] + "\n" + "\n".join(f"- {_flag_text(f, s, lang, 1)}" for f in flags[:5]))
    else:
        parts.append(T["no_findings"])
    parts.append(_alerts(s, lang))
    extra2 = _sleep_adherence(s, lang)
    if extra2:
        parts.append(extra2)
    return parts


SA = {"ru": ("**Сон и режим лечения:**", "- Сон: последняя ночь {h} ч, качество {q}/100, в среднем {a} ч; коротких ночей: {k}",
             "- Соблюдение режима лекарств за 7 дней: {p} % ({t}/{n} доз)"),
      "uz": ("**Uyqu va davolash rejimi:**", "- Uyqu: oxirgi tun {h} soat, sifat {q}/100, o'rtacha {a} soat; qisqa tunlar: {k}",
             "- 7 kunlik dori rejimiga rioya: {p} % ({t}/{n} doza)"),
      "en": ("**Sleep and treatment routine:**", "- Sleep: last night {h} h, quality {q}/100, average {a} h; short nights: {k}",
             "- Medication adherence over 7 days: {p} % ({t}/{n} doses)")}


def _sleep_adherence(s: dict, lang: str) -> str | None:
    """Блок «сон + приём лекарств» в сводке врача (данные добавляет routers/ai.py)."""
    head, sl_t, adh_t = SA[lang]
    lines = []
    sl = s.get("sleep")
    if sl:
        lines.append(sl_t.format(h=sl["last"]["hours"], q=sl["last"]["score"], a=sl["avg_hours"], k=sl["short_nights"]))
    adh = s.get("adherence")
    if adh and adh.get("pct") is not None:
        lines.append(adh_t.format(p=adh["pct"], t=adh["taken"], n=adh["planned"]))
    return head + "\n" + "\n".join(lines) if lines else None


def _alerts(s: dict, lang: str) -> str:
    T = L[lang]
    if not s.get("alerts7"):
        return f"{T['alerts_h']} {T['no_alerts']}"
    lines = [T["alerts_line"].format(metric=T["m"].get(a["metric"], a["metric"]),
                                     level=T["crit"] if a["level"] == "critical" else T["warn"], count=a["count"])
             for a in s["alerts7"]]
    tail = [T["amb"].format(n=s.get("ambulance7", 0))]
    if s.get("last_alert"):
        la = s["last_alert"]
        tail.append(T["last_alert"].format(metric=T["m"].get(la["metric"], la["metric"]), value=la["value"],
                                           level=T["crit"] if la["level"] == "critical" else T["warn"]))
    return T["alerts_h"] + "\n" + "\n".join(lines) + "\n\n" + " ".join(tail)


def _deep(metric: str, s: dict, lang: str) -> list[str]:
    T = L[lang]
    st = s["metrics"][metric]
    lo, hi = NORMAL[metric]
    tr = T["trend"].get(st.get("trend", "stable"), "").format(p=abs(st.get("trend_pct") or 0))
    parts = [f"### {T['deep_h'].format(metric=T['m'][metric])}",
             T["deep"].format(last=st["last"], unit=T["u"][metric], a24=st["avg24"], a7=st["avg7"], a30=st["avg30"],
                              min=st["min7"], max=st["max7"], sd=st["sd7"], lo=lo, hi=hi, tir=st["tir7"],
                              below=st["below7"], above=st["above7"], trend=tr)]
    if metric == "systolic":
        d = s["metrics"]["diastolic"]
        parts[1] += f"\n- {T['m']['diastolic']}: {d['last']} / {d['avg7']} ({d['min7']}–{d['max7']}), {d['tir7']}%"
        if s.get("bp_dip"):
            b = s["bp_dip"]
            parts.append(T["dip"].format(day=b["day"], night=b["night"], dip=b["dip_pct"], type=T["dip_t"][b["type"]]))
    if metric == "glucose" and st.get("cv7") is not None:
        parts.append(T["cv"].format(cv=st["cv7"]))
    related = {"systolic": {"home_bp_high", "bp_crisis_episode", "non_dipper", "bp_trend_up"},
               "heart_rate": {"tachycardia", "bradycardia", "hr_spikes"},
               "glucose": {"glucose_control", "hypoglycemia", "glucose_variability"},
               "spo2": {"desaturation", "tachypnea"}, "body_temp": {"fever"}}[metric]
    fl = [f for f in s["flags"] if f in related]
    if fl:
        parts.append(T["findings_h"] + "\n" + "\n".join(f"- {_flag_text(f, s, lang, 0)}" for f in fl))
        parts.append(T["review_h"] + "\n" + "\n".join(f"- {_flag_text(f, s, lang, 1)}" for f in fl))
    else:
        parts.append(T["no_findings"])
    return parts


def _trends(s: dict, lang: str) -> list[str]:
    T = L[lang]
    lines = []
    for k in ["systolic", "heart_rate", "glucose", "spo2", "resp_rate", "body_temp"]:
        st = s["metrics"][k]
        if st.get("trend") in ("up", "down"):
            lines.append(f"- **{T['m'][k]}**: {st['avg24']} vs {st['avg7']} ({T['trend'][st['trend']].format(p=abs(st['trend_pct']))})")
    head = "### " + {"ru": "Тренды: сутки против недели", "uz": "Trendlar: sutka va hafta",
                     "en": "Trends: last 24 h vs week"}[lang]
    return [head, "\n".join(lines) if lines else T["no_findings"]]


def _questions(s: dict, lang: str) -> list[str]:
    T = L[lang]
    qs = [_flag_text(f, s, lang, 2) for f in s["flags"]]
    general = {"ru": ["Есть ли жалобы на самочувствие в последние дни?", "Изменился ли приём лекарств?"],
               "uz": ["So'nggi kunlarda ahvoldan shikoyat bormi?", "Dori ichish o'zgardimi?"],
               "en": ["Any complaints in recent days?", "Any changes in medication?"]}[lang]
    return [T["questions_h"], "\n".join(f"{i}. {q}" for i, q in enumerate(dict.fromkeys(qs + general), 1))]


def _draft(s: dict, lang: str) -> list[str]:
    T = L[lang]
    first = s["name"].split()[0]
    body = [random.choice(T["draft_open"]).format(first=first)]
    advice, urgent = [], False
    for f in s["flags"]:
        if f == "low_coverage":
            continue
        a = _flag_text(f, s, lang, 3)
        if "103" in a or "emergency" in a:  # one emergency instruction is enough
            if urgent:
                continue
            urgent = True
        advice.append(a)
    advice = advice[:4]
    body.append(" ".join(advice) if advice else T["draft_ok"])
    body.append(random.choice(T["draft_close"]))
    return [T["draft_h"], "> " + "\n>\n> ".join(body)]


def _cohort(rows: list[dict], lang: str) -> list[str]:
    T = L[lang]
    lines = [f"### {random.choice(T['cohort_h'])}", T["cohort_t"]]
    for i, r in enumerate(rows, 1):
        if not r.get("metrics"):
            continue
        fl = "; ".join(_flag_text(f, r, lang, 0).rstrip(".") for f in r["flags"][:2]) or "—"
        lines.append(f"| {i} | {r['name']} ({r['age']}) | **{r['risk']}** | {fl} | {r.get('alerts_crit7', 0)} |")
    return ["\n".join(lines), T["cohort_hint"]]


def builtin(message: str, stats: dict | None, cohort_rows: list[dict] | None, lang: str) -> str:
    T = L[lang]
    text = f" {message.lower()} "
    intent = _intent(text)
    if intent == "cohort":
        parts = _cohort(cohort_rows or [], lang)
    elif stats is None:
        return T["no_patient"] + "\n\n" + T["capabilities"]
    elif not stats.get("metrics"):
        return T["no_data"].format(name=stats["name"])
    elif intent == "draft":
        parts = _draft(stats, lang)
    elif intent == "questions":
        parts = _questions(stats, lang)
    elif intent == "alerts":
        parts = [_alerts(stats, lang)]
    elif intent == "trends":
        parts = _trends(stats, lang)
    elif intent.startswith("deep_"):
        parts = _deep(intent[5:], stats, lang)
    else:
        parts = _summary(stats, lang)
        if any(w in text for w in ("привет", "здравств", "salom", "hello", "hi ")):
            parts.append(T["capabilities"])
    # follow-up order: [deep dive, draft, cohort, questions] — don't offer what was just shown
    skip = {"draft": 1, "cohort": 2, "questions": 3}.get(intent, 0 if intent.startswith("deep_") else -1)
    options = [f for i, f in enumerate(T["followup"]) if i != skip]
    parts += [random.choice(options), random.choice(T["disclaimer"])]
    return "\n\n".join(parts)


def llm_system(stats: dict | None, cohort_rows: list[dict] | None, lang: str) -> str:
    lang_name = {"ru": "русском", "uz": "узбекском (латиница)", "en": "английском"}[lang]
    brief = [{k: r.get(k) for k in ("name", "age", "risk", "flags", "alerts_crit7")} for r in (cohort_rows or [])]
    return (
        "Ты — ИИ-аналитик для врача в портале MIRA (поддержка принятия клинических решений). "
        "Собеседник — врач. Помогай анализировать данные домашнего мониторинга пациента: статистику, тренды, "
        "время в целевом диапазоне, суточный профиль АД, тревоги; предлагай, на что обратить внимание, какие "
        "обследования можно рассмотреть и какие вопросы задать пациенту; по запросу готовь черновик сообщения "
        "пациенту простым языком. Используй профессиональную терминологию, Markdown-таблицы и списки. "
        "Не ставь окончательный диагноз и не назначай конкретные дозировки — решение за врачом. "
        f"Отвечай на {lang_name} языке.\n\n"
        f"Данные выбранного пациента (JSON): {json.dumps(stats, ensure_ascii=False, default=str) if stats else 'не выбран'}\n"
        f"Краткий обзор всех пациентов врача: {json.dumps(brief, ensure_ascii=False)}"
    )
