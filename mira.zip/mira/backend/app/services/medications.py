"""
medications.py — РАСПИСАНИЕ ЛЕКАРСТВ, НАПОМИНАНИЯ И SMS
======================================================
Как это работает:

1. Врач назначает лекарство: название, доза, время приёма ("08:00,20:00"), даты курса.
   Для антибиотиков дата окончания обязательна — курс нельзя бросать раньше.
2. Планировщик `reminder_loop` каждые 30 секунд проверяет: наступило ли время какой-то дозы?
   Если да и напоминания ещё не было:
      • создаёт запись MedicationIntake (уникальный индекс не даст создать вторую → нет повторных SMS);
      • отправляет пациенту SMS на телефон (sms.py);
      • шлёт в открытый портал событие "reminder" через WebSocket.
3. Пациент нажимает «Принял» → taken_at. Врач видит соблюдение режима (adherence, %).

Время: врач и пациент думают в МЕСТНОМ времени (Ташкент), а в базе всё хранится в UTC.
Переводом занимаются функции _local_to_utc / _utc_to_local.
"""
import asyncio
import logging
from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..config import get_settings
from ..database import SessionLocal
from ..models import Medication, MedicationIntake, User, utcnow
from ..security import decrypt
from .sms import send_sms
from .ws_manager import manager, patient_channel

log = logging.getLogger("mira.meds")
settings = get_settings()
TZ = ZoneInfo(settings.timezone)


# ------------------------------------------------------------------ время
def parse_times(raw: str) -> list[time]:
    """'8:00, 20:00' -> [time(8,0), time(20,0)]. Ошибка формата -> ValueError (вернётся 422)."""
    out = []
    for part in raw.replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        hh, mm = part.split(":")
        out.append(time(int(hh), int(mm)))
    if not out:
        raise ValueError("at least one time is required")
    return sorted(set(out))


def _local_to_utc(d: date, t: time) -> datetime:
    return datetime.combine(d, t, tzinfo=TZ).astimezone(timezone.utc).replace(tzinfo=None)


def _utc_to_local(dt: datetime) -> datetime:
    return dt.replace(tzinfo=timezone.utc).astimezone(TZ).replace(tzinfo=None)


def local_today() -> date:
    return _utc_to_local(utcnow()).date()


def active_on(med: Medication, d: date) -> bool:
    return med.active and med.start_date <= d and (med.end_date is None or d <= med.end_date)


def doses_for_day(med: Medication, d: date) -> list[datetime]:
    """Все дозы лекарства за местный день d (в UTC)."""
    if not active_on(med, d):
        return []
    return [_local_to_utc(d, t) for t in parse_times(med.times)]


# ------------------------------------------------------------------ расписание и соблюдение
def _intakes(db: Session, patient_id: int, since: datetime) -> dict[tuple[int, datetime], MedicationIntake]:
    rows = db.scalars(select(MedicationIntake).where(MedicationIntake.patient_id == patient_id,
                                                     MedicationIntake.scheduled_at >= since))
    return {(r.medication_id, r.scheduled_at): r for r in rows}


def dose_status(scheduled: datetime, intake: MedicationIntake | None, now: datetime) -> str:
    """taken — принято; due — пора принять (окно открыто); upcoming — ещё не время; missed — пропущено."""
    if intake and intake.taken_at:
        return "taken"
    if now < scheduled:
        return "upcoming"
    if now < scheduled + timedelta(minutes=settings.reminder_window_min):
        return "due"
    return "missed"


def day_schedule(db: Session, patient: User, d: date | None = None) -> list[dict]:
    """Расписание приёма на день: для страницы «Лекарства» и для ИИ-ассистента."""
    d = d or local_today()
    now = utcnow()
    meds = db.scalars(select(Medication).where(Medication.patient_id == patient.id, Medication.active.is_(True))).all()
    intakes = _intakes(db, patient.id, _local_to_utc(d, time(0, 0)))
    out = []
    for m in meds:
        for sched in doses_for_day(m, d):
            it = intakes.get((m.id, sched))
            out.append({"medication_id": m.id, "name": m.name, "dose": m.dose, "is_antibiotic": m.is_antibiotic,
                        "time": _utc_to_local(sched).strftime("%H:%M"), "scheduled_at": sched.isoformat(),
                        "status": dose_status(sched, it, now), "sms_status": it.sms_status if it else None,
                        "taken_at": it.taken_at.isoformat() if it and it.taken_at else None})
    return sorted(out, key=lambda x: x["time"])


def adherence(db: Session, patient: User, days: int = 7) -> dict:
    """Соблюдение режима за N дней: доля принятых доз среди тех, чьё окно уже закрылось."""
    now = utcnow()
    today = local_today()
    since = _local_to_utc(today - timedelta(days=days - 1), time(0, 0))
    meds = db.scalars(select(Medication).where(Medication.patient_id == patient.id)).all()
    intakes = _intakes(db, patient.id, since)
    window = timedelta(minutes=settings.reminder_window_min)
    planned = taken = 0
    per_med: dict[int, dict] = {}
    for m in meds:
        pm = per_med.setdefault(m.id, {"name": m.name, "planned": 0, "taken": 0})
        for i in range(days):
            for sched in doses_for_day(m, today - timedelta(days=i)):
                if sched + window > now:
                    continue  # окно ещё открыто — не считаем ни принятой, ни пропущенной
                planned += 1
                pm["planned"] += 1
                it = intakes.get((m.id, sched))
                if it and it.taken_at:
                    taken += 1
                    pm["taken"] += 1
    pct = round(taken / planned * 100) if planned else None
    for pm in per_med.values():
        pm["pct"] = round(pm["taken"] / pm["planned"] * 100) if pm["planned"] else None
    return {"days": days, "planned": planned, "taken": taken, "pct": pct,
            "per_medication": [v for v in per_med.values() if v["planned"]]}


def mark_taken(db: Session, patient: User, med: Medication, scheduled_at: datetime) -> MedicationIntake:
    """Пациент отметил дозу. Если записи ещё нет (отметил заранее) — создаём."""
    it = db.scalar(select(MedicationIntake).where(MedicationIntake.medication_id == med.id,
                                                  MedicationIntake.scheduled_at == scheduled_at))
    if not it:
        it = MedicationIntake(medication_id=med.id, patient_id=patient.id, scheduled_at=scheduled_at,
                              sms_status="off")
        db.add(it)
    it.taken_at = utcnow()
    db.commit()
    return it


# ------------------------------------------------------------------ планировщик напоминаний
def _sms_text(med: Medication) -> str:
    """Короткий текст на двух языках (узбекский + русский). Без диагнозов — только название и доза."""
    note = decrypt(med.notes_enc) if med.notes_enc else ""
    extra = f" ({note})" if note and len(note) <= 40 else ""
    course = " Kursni oxirigacha davom ettiring / Не прерывайте курс." if med.is_antibiotic else ""
    return f"MIRA: {med.name} {med.dose}{extra} qabul qilish vaqti / время принять.{course}"


async def check_reminders(db: Session) -> int:
    """Один проход планировщика. Возвращает число отправленных напоминаний (удобно для тестов)."""
    now = utcnow()
    today = local_today()
    window = timedelta(minutes=settings.reminder_window_min)
    sent = 0
    meds = db.scalars(select(Medication).join(User, User.id == Medication.patient_id)
                      .where(Medication.active.is_(True), User.status == "approved")).all()
    for med in meds:
        for sched in doses_for_day(med, today):
            if not (sched <= now < sched + window):
                continue
            exists = db.scalar(select(MedicationIntake.id).where(MedicationIntake.medication_id == med.id,
                                                                  MedicationIntake.scheduled_at == sched))
            if exists:
                continue  # уже напомнили (или пациент отметил заранее)
            intake = MedicationIntake(medication_id=med.id, patient_id=med.patient_id, scheduled_at=sched,
                                      reminded_at=now, sms_status="pending")
            db.add(intake)
            try:
                db.commit()
            except IntegrityError:  # параллельный процесс успел раньше — это нормально
                db.rollback()
                continue
            patient = db.get(User, med.patient_id)
            phone = decrypt(patient.phone_enc) if patient and patient.phone_enc else None
            intake.sms_status = await send_sms(db, phone, _sms_text(med), "medication", med.patient_id) \
                if med.sms_enabled else "off"
            db.commit()
            await manager.publish(patient_channel(med.patient_id), {
                "type": "reminder", "patient_id": med.patient_id,
                "data": {"medication_id": med.id, "name": med.name, "dose": med.dose,
                         "time": _utc_to_local(sched).strftime("%H:%M")}})
            sent += 1
    return sent


async def reminder_loop() -> None:
    """Бесконечный цикл в фоне (запускается в main.lifespan)."""
    log.info("Medication reminders started (every %ss)", settings.reminder_check_sec)
    while True:
        try:
            with SessionLocal() as db:
                await check_reminders(db)
        except Exception:  # noqa: BLE001 — цикл не должен умирать из-за одной ошибки
            log.exception("Reminder check failed")
        await asyncio.sleep(settings.reminder_check_sec)
