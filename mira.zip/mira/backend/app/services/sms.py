"""
sms.py — ОТПРАВКА SMS (напоминания о лекарствах и SOS)
====================================================
Работает с любым SMS-шлюзом, у которого есть простой JSON API:
    POST SMS_GATEWAY_URL
    Authorization: Bearer SMS_GATEWAY_TOKEN
    {"to": "+998901234567", "text": "...", "from": "MIRA"}

В Узбекистане так работают, например, Eskiz.uz / Play Mobile (у них свои названия полей —
при подключении достаточно поправить словарь `payload` ниже).

Если SMS_GATEWAY_URL не задан — ДЕМО-РЕЖИМ: SMS не отправляется, а записывается в журнал
со статусом "demo". Так можно показать работу напоминаний без платного шлюза.

Каждая SMS (и демо тоже) сохраняется в таблицу sms_log. Текст шифруется,
номер телефона в журнал сервера пишется только в маскированном виде.
"""
import logging
import re

import httpx
from sqlalchemy.orm import Session

from ..config import get_settings
from ..models import SmsLog
from ..security import encrypt, mask_phone

log = logging.getLogger("mira.sms")
settings = get_settings()

PHONE_RE = re.compile(r"^\+?\d{9,15}$")


def normalize_phone(phone: str) -> str | None:
    """'+998 (90) 123-45-67' -> '+998901234567'. Неверный формат -> None."""
    cleaned = re.sub(r"[\s\-()]", "", phone or "")
    if not PHONE_RE.match(cleaned):
        return None
    return cleaned if cleaned.startswith("+") else "+" + cleaned


async def send_sms(db: Session, to: str | None, text: str, purpose: str, user_id: int | None = None) -> str:
    """Отправляет SMS и возвращает статус: sent / demo / failed / off (нет номера)."""
    phone = normalize_phone(to or "")
    if not phone:
        return "off"
    status = "demo"
    if settings.sms_gateway_url:
        payload = {"to": phone, "text": text, "from": settings.sms_sender}
        try:
            async with httpx.AsyncClient(timeout=8) as client:
                r = await client.post(settings.sms_gateway_url, json=payload,
                                      headers={"Authorization": f"Bearer {settings.sms_gateway_token}"})
            status = "sent" if r.is_success else "failed"
            if not r.is_success:
                log.error("SMS gateway HTTP %s for %s", r.status_code, mask_phone(phone))
        except httpx.HTTPError as e:
            status = "failed"
            log.error("SMS gateway error for %s: %s", mask_phone(phone), e)
    else:
        log.info("[DEMO SMS] %s -> %s: %s", purpose, mask_phone(phone), text)
    db.add(SmsLog(user_id=user_id, purpose=purpose, status=status, body_enc=encrypt(text)))
    db.commit()
    return status
