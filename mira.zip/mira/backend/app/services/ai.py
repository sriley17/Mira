"""
ai.py — ЛОКАЛЬНЫЙ ИИ-АССИСТЕНТ ПАЦИЕНТА
=====================================
Все советы — ДИНАМИЧЕСКИЕ: каждый ответ строится из свежей аналитики пациента,
статичного раздела «Советы» больше нет (требование ТЗ).

Что ИИ знает о пациенте (ctx, собирается в routers/ai.py):
    latest / avg / kcal_total   — последние показатели и средние за сутки;
    sleep                       — итоги последней ночи и недели (services/sleep.py);
    goals                       — цели и прогресс за сегодня (services/goals.py);
    meds                        — расписание лекарств на сегодня и соблюдение за 7 дней;
    weather                     — температура и УФ-индекс на сегодня;
    outdoor                     — совет «выходить ли на улицу и нужна ли маска» (погода + воздух +
                                  состояние пациента, services/outdoor.py).

Как строится ответ встроенным движком (_builtin):
    1. Определяем тему вопроса по ключевым словам (давление, сон, лекарства, реабилитация...).
    2. Показываем относящиеся к теме цифры пациента со сравнением с нормой.
    3. Добавляем блоки контекста: сон / цели / лекарства / погода — если они к месту.
    4. Подбираем 2–4 совета из базы знаний, исключая те, что уже были в последних ответах.
       Если вопрос общий — советы берутся по тому, что СЕЙЧАС отклоняется у пациента.
    5. «Когда к врачу», уточняющий вопрос, напоминание, что ИИ не заменяет врача.

Спокойная подача: пациенту никогда не пишем «критично» и не показываем тревожные значки —
критические тревоги видит только врач (требование ТЗ). Опасные СИМПТОМЫ, о которых пишет сам
пациент (боль в груди и т.п.), по-прежнему сопровождаются советом звонить 103 — это безопасность.

Если на сервере установлена локальная LLM (Ollama, см. local_llm.py) — она переписывает ответ
более живым языком, опираясь на те же факты. Данные никогда не покидают сервер.
"""
import json
import logging
import random

from ..config import get_settings
from .ai_kb import (GREETING_KEYWORDS, METRIC_INFO, PHRASES, STATUS_KEYWORDS, THANKS_KEYWORDS, TOPICS)
from . import local_llm
from .thresholds import classify

log = logging.getLogger("mira.ai")
settings = get_settings()

NORMAL = {"heart_rate": (60, 100), "systolic": (90, 140), "diastolic": (60, 90), "glucose": (3.9, 7.8),
          "resp_rate": (12, 20), "spo2": (95, 100), "body_temp": (36.1, 37.2), "room_temp": (20, 25)}
ALL_METRICS = ["heart_rate", "systolic", "glucose", "spo2", "resp_rate", "body_temp", "room_temp", "calories"]
# which topic explains an abnormal metric (used when the question is general)
METRIC_TOPIC = {"heart_rate": "pulse", "systolic": "pressure", "diastolic": "pressure", "glucose": "sugar",
                "spo2": "breathing", "resp_rate": "breathing", "body_temp": "fever", "room_temp": "room"}

LANG_NAME = {"ru": "русском", "uz": "узбекском (латиница)", "en": "английском"}


# ------------------------------------------------------------------ helpers
def _has(text: str, words: list[str]) -> bool:
    return any(w in text for w in words)


def _detect_topics(text: str) -> list[str]:
    found = [k for k, v in TOPICS.items() if _has(text, v["keywords"])]
    found.sort(key=lambda k: not TOPICS[k].get("emergency"))  # emergencies first
    return found[:2]


def _fmt(v: float, digits: int) -> str:
    return f"{v:.{digits}f}"


def _state(metric: str, v: float, P: dict) -> tuple[str, str]:
    """(level, text) e.g. ('warning', 'выше нормы')."""
    lvl = classify(metric, v)
    lo, hi = NORMAL.get(metric, (None, None))
    if lvl == "critical":
        return lvl, P["crit"]
    if lo is not None and v < lo:
        return "warning", P["low"]
    if hi is not None and v > hi:
        return "warning", P["high"]
    return "normal", P["norm"]


def _vitals_lines(metrics: list[str], ctx: dict, lang: str) -> tuple[list[str], list[str]]:
    """Markdown bullet lines for the chosen metrics + list of abnormal metrics."""
    P = PHRASES[lang]
    latest, avg = ctx.get("latest") or {}, ctx.get("avg") or {}
    lines, abnormal = [], []
    for m in metrics:
        if m not in METRIC_INFO:  # diastolic is shown together with systolic
            continue
        label, unit, norm, digits = METRIC_INFO[m]
        if m == "calories":
            if ctx.get("kcal_total"):
                lines.append(f"- **{label[lang]}:** {ctx['kcal_total']:.0f} {unit[lang]}")
            continue
        if m not in latest:
            continue
        v = latest[m]
        if m == "systolic":
            d = latest.get("diastolic", 0)
            lvl_s, txt_s = _state("systolic", v, P)
            lvl_d, txt_d = _state("diastolic", d, P)
            lvl, txt = (lvl_s, txt_s) if ["normal", "warning", "critical"].index(lvl_s) >= \
                ["normal", "warning", "critical"].index(lvl_d) else (lvl_d, txt_d)
            value = f"{v:.0f}/{d:.0f}"
            avg_txt = f"{avg['systolic']:.0f}/{avg['diastolic']:.0f}" if "systolic" in avg and "diastolic" in avg else None
        else:
            lvl, txt = _state(m, v, P)
            value = _fmt(v, digits)
            avg_txt = _fmt(avg[m], digits) if m in avg else None
        mark = " (!)" if lvl != "normal" else ""   # спокойная текстовая пометка вместо значков
        norm_txt = f" ({norm})" if norm else ""
        line = f"- **{label[lang]}:** {value} {unit[lang]} — {txt}{norm_txt}{mark}"
        if avg_txt:
            line += f"; {P['vs_avg'].format(avg=avg_txt)}"
        lines.append(line)
        if lvl != "normal":
            abnormal.append(m)
    return lines, abnormal


def _pick_tips(topic: str, lang: str, n: int, recent: str) -> list[str]:
    pool = TOPICS[topic][lang]["tips"]
    fresh = [t for t in pool if t not in recent]  # avoid repeating the previous answers
    src = fresh if len(fresh) >= n else pool
    return random.sample(src, min(n, len(src)))


# ------------------------------------------------------------------ built-in assistant
def _builtin(message: str, history: list[dict], ctx: dict, lang: str) -> str:
    P = PHRASES[lang]
    text = f" {message.lower().strip()} "
    name = ctx.get("name") or ""
    recent = " ".join(h["content"] for h in history[-4:] if h["role"] == "assistant")
    topics = _detect_topics(text)
    is_status = _has(text, STATUS_KEYWORDS)
    is_greet = _has(text, GREETING_KEYWORDS)
    has_vitals = bool(ctx.get("latest"))

    if _has(text, THANKS_KEYWORDS) and not topics:
        return f"{random.choice(P['thanks']).format(name=name)}\n\n{random.choice(P['followup'])}"

    parts: list[str] = []
    # 1. opening
    if is_greet:
        parts.append(random.choice(P["greet"]).format(name=name))
    if topics:
        parts.append(random.choice(TOPICS[topics[0]][lang]["intro"]))
    elif not is_greet and not is_status:
        parts.append(random.choice(P["unknown"]))

    # 2. emergency banner
    if any(TOPICS[t].get("emergency") for t in topics):
        parts.append(P["urgent"])

    # 3. patient's own readings
    abnormal: list[str] = []
    if has_vitals:
        if topics and not is_status:
            metrics = []
            for t in topics:
                metrics += [m for m in TOPICS[t]["metrics"] if m not in metrics]
        else:
            metrics = ALL_METRICS
        lines, abnormal = _vitals_lines(metrics, ctx, lang)
        if lines:
            block = random.choice(P["vitals_title"]) + "\n" + "\n".join(lines)
            if not topics or is_status:
                block += "\n\n" + random.choice(P["overall_warn"] if abnormal else P["overall_ok"])
            parts.append(block)
    elif ctx.get("role") == "patient":
        parts.append(P["no_data"])

    # 4. advice
    tip_topics = list(topics)
    if not tip_topics:  # general question: advise on what is off, otherwise something random
        tip_topics = list(dict.fromkeys(METRIC_TOPIC[m] for m in abnormal if m in METRIC_TOPIC))[:2]
        if not tip_topics:  # показатели в норме — смотрим на сон, лекарства, погоду, цели
            tip_topics = context_issues(ctx)[:2]
        if not tip_topics:
            tip_topics = random.sample(["pressure", "sleep", "food", "activity", "water", "stress", "rehab"], 2)
    per_topic = 4 if len(tip_topics) == 1 else 2
    tips = []
    for t in tip_topics:
        tips += _pick_tips(t, lang, per_topic, recent)
    if tips:
        parts.append(random.choice(P["tips_title"]) + "\n" + "\n".join(f"- {t}" for t in tips))

    # 5. when to see a doctor
    doc_topic = topics[0] if topics else (tip_topics[0] if abnormal else None)
    if doc_topic:
        parts.append(f"{random.choice(P['doctor_title'])} {TOPICS[doc_topic][lang]['doctor']}")

    # 6. what else I can do + follow-up + disclaimer
    if is_greet and not topics:
        parts.append(P["capabilities"])
    parts.append(random.choice(P["followup"]))
    parts.append(random.choice(P["disclaimer"]))
    return "\n\n".join(parts)


# ------------------------------------------------------------------ контекст: сон, цели, лекарства, погода
CTX_TXT = {
    "ru": {"sleep_h": "**Ваш сон (последняя ночь):**",
           "sleep": "- {hours} ч сна ({onset}–{wake}), качество **{score}/100**, пробуждений: {wakes}\n"
                    "- Пульс во сне {hr} уд/мин (днём ~{hr_day}), SpO₂ в среднем {spo2} %\n"
                    "- В среднем за неделю: {avg_h} ч, качество {avg_s}/100",
           "weak": {"duration": "продолжительность сна", "efficiency": "сон прерывистый (много времени без сна в кровати)",
                    "awakenings": "частые пробуждения", "spo2": "ночной уровень кислорода",
                    "room_temp": "температура в спальне", "hr_dip": "пульс ночью почти не снижается"},
           "weak_line": "- Над чем стоит поработать: {w}",
           "goals_h": "**Ваши цели на сегодня:**", "goal": "- {title}: {value} из {target} {unit} ({pct} %){done}",
           "done": " — выполнено", "meds_h": "**Лекарства сегодня:**",
           "med": "- {time} {name} {dose} — {status}",
           "st": {"taken": "принято", "due": "пора принять", "upcoming": "впереди", "missed": "не отмечено"},
           "adh": "- Соблюдение режима за 7 дней: **{pct} %**", "no_meds": "- Назначенных лекарств нет.",
           "wx_h": "**Погода сегодня:**", "wx": "- До {tmax} °C, УФ-индекс {uv} ({lvl})",
           "uv": {"low": "низкий", "moderate": "умеренный", "high": "высокий", "very_high": "очень высокий",
                  "extreme": "экстремальный", "unknown": "нет данных"},
           "no_sleep": "- Данных о сне пока недостаточно — носите устройство ночью."},
    "uz": {"sleep_h": "**Uyqungiz (oxirgi tun):**",
           "sleep": "- {hours} soat uyqu ({onset}–{wake}), sifat **{score}/100**, uyg'onishlar: {wakes}\n"
                    "- Uyqudagi puls {hr} zarba/daq (kunduzi ~{hr_day}), SpO₂ o'rtacha {spo2} %\n"
                    "- Haftalik o'rtacha: {avg_h} soat, sifat {avg_s}/100",
           "weak": {"duration": "uyqu davomiyligi", "efficiency": "uyqu uzilib-uzilib (to'shakda uyqusiz vaqt ko'p)",
                    "awakenings": "tez-tez uyg'onish", "spo2": "tungi kislorod darajasi",
                    "room_temp": "yotoqxona harorati", "hr_dip": "tunda puls deyarli pasaymaydi"},
           "weak_line": "- Nimaga e'tibor berish kerak: {w}",
           "goals_h": "**Bugungi maqsadlaringiz:**", "goal": "- {title}: {value} / {target} {unit} ({pct} %){done}",
           "done": " — bajarildi", "meds_h": "**Bugungi dorilar:**",
           "med": "- {time} {name} {dose} — {status}",
           "st": {"taken": "ichildi", "due": "ichish vaqti", "upcoming": "oldinda", "missed": "belgilanmagan"},
           "adh": "- 7 kunlik rejimga rioya: **{pct} %**", "no_meds": "- Tayinlangan dorilar yo'q.",
           "wx_h": "**Bugungi ob-havo:**", "wx": "- {tmax} °C gacha, UB-indeks {uv} ({lvl})",
           "uv": {"low": "past", "moderate": "o'rtacha", "high": "yuqori", "very_high": "juda yuqori",
                  "extreme": "ekstremal", "unknown": "ma'lumot yo'q"},
           "no_sleep": "- Uyqu haqida ma'lumot hali yetarli emas — qurilmani kechasi ham taqib yuring."},
    "en": {"sleep_h": "**Your sleep (last night):**",
           "sleep": "- {hours} h of sleep ({onset}–{wake}), quality **{score}/100**, awakenings: {wakes}\n"
                    "- Pulse during sleep {hr} bpm (daytime ~{hr_day}), average SpO₂ {spo2} %\n"
                    "- Weekly average: {avg_h} h, quality {avg_s}/100",
           "weak": {"duration": "sleep duration", "efficiency": "fragmented sleep (a lot of awake time in bed)",
                    "awakenings": "frequent awakenings", "spo2": "night-time oxygen level",
                    "room_temp": "bedroom temperature", "hr_dip": "pulse barely drops at night"},
           "weak_line": "- What to work on: {w}",
           "goals_h": "**Your goals today:**", "goal": "- {title}: {value} of {target} {unit} ({pct} %){done}",
           "done": " — done", "meds_h": "**Medicines today:**",
           "med": "- {time} {name} {dose} — {status}",
           "st": {"taken": "taken", "due": "time to take", "upcoming": "later", "missed": "not marked"},
           "adh": "- Adherence over 7 days: **{pct} %**", "no_meds": "- No prescribed medicines.",
           "wx_h": "**Weather today:**", "wx": "- Up to {tmax} °C, UV index {uv} ({lvl})",
           "uv": {"low": "low", "moderate": "moderate", "high": "high", "very_high": "very high",
                  "extreme": "extreme", "unknown": "no data"},
           "no_sleep": "- Not enough sleep data yet — wear the device at night."},
}

GOAL_NAMES = {
    "ru": {"calories": "Сжечь калории", "sleep": "Сон", "water": "Вода", "steps": "Шаги", "custom": "Цель"},
    "uz": {"calories": "Kaloriya sarflash", "sleep": "Uyqu", "water": "Suv", "steps": "Qadamlar", "custom": "Maqsad"},
    "en": {"calories": "Burn calories", "sleep": "Sleep", "water": "Water", "steps": "Steps", "custom": "Goal"},
}
UNIT_NAMES = {"ru": {"kcal": "ккал", "h": "ч", "l": "л", "steps": "шагов"},
              "uz": {"kcal": "kkal", "h": "soat", "l": "l", "steps": "qadam"},
              "en": {"kcal": "kcal", "h": "h", "l": "l", "steps": "steps"}}

# Когда какой блок контекста показывать: тема вопроса -> блоки
TOPIC_BLOCKS = {"outdoor": ["outdoor"], "breathing": ["outdoor"], "sleep": ["sleep", "weather"], "fatigue": ["sleep"], "goals": ["goals"], "activity": ["goals"],
                "weight": ["goals"], "medication": ["meds"], "heat_uv": ["outdoor", "weather"], "rehab": ["goals", "outdoor"]}


def _fmt_num(v) -> str:
    """7.0 -> '7', 7.25 -> '7.2' — числа в тексте без лишних нулей."""
    if v is None:
        return "–"
    return f"{v:.0f}" if abs(v - round(v)) < 0.05 else f"{v:.1f}"


def _block_sleep(ctx: dict, lang: str) -> str:
    C = CTX_TXT[lang]
    s = ctx.get("sleep")
    if not s:
        return C["sleep_h"] + "\n" + C["no_sleep"]
    last = s["last"]
    v = last["vitals"]
    text = C["sleep_h"] + "\n" + C["sleep"].format(
        hours=_fmt_num(last["hours"]), onset=last["onset"], wake=last["wake"], score=last["score"],
        wakes=last["awakenings"], hr=_fmt_num(v["heart_rate"]), hr_day=_fmt_num(v["heart_rate_day"]),
        spo2=_fmt_num(v["spo2_avg"]), avg_h=_fmt_num(s["avg_hours"]), avg_s=s["avg_score"])
    weakest = min(last["factors"], key=lambda f: f["points"] / f["max"])
    if weakest["points"] < weakest["max"]:
        text += "\n" + C["weak_line"].format(w=C["weak"][weakest["code"]])
    return text


def _block_goals(ctx: dict, lang: str) -> str | None:
    goals = ctx.get("goals") or []
    if not goals:
        return None
    C = CTX_TXT[lang]
    lines = [C["goal"].format(title=g["title"] or GOAL_NAMES[lang].get(g["kind"], g["kind"]), value=_fmt_num(g["value"]), target=_fmt_num(g["target"]),
                              unit=UNIT_NAMES[lang].get(g["unit"], g["unit"]), pct=g["pct"], done=C["done"] if g["done"] else "") for g in goals]
    return C["goals_h"] + "\n" + "\n".join(lines)


def _block_meds(ctx: dict, lang: str) -> str:
    C = CTX_TXT[lang]
    meds = ctx.get("meds") or {}
    today = meds.get("today") or []
    lines = [C["med"].format(time=d["time"], name=d["name"], dose=d["dose"], status=C["st"][d["status"]])
             for d in today] or [C["no_meds"]]
    adh = (meds.get("adherence") or {}).get("pct")
    if adh is not None:
        lines.append(C["adh"].format(pct=adh))
    return C["meds_h"] + "\n" + "\n".join(lines)


def _block_weather(ctx: dict, lang: str) -> str | None:
    w = ctx.get("weather")
    if not w:
        return None
    C = CTX_TXT[lang]
    return C["wx_h"] + "\n" + C["wx"].format(tmax=_fmt_num(w.get("t_max")), uv=_fmt_num(w.get("uv_max")),
                                              lvl=C["uv"].get(w.get("uv_level"), "–"))


def _block_outdoor(ctx: dict, lang: str) -> str | None:
    """Совет «выходить ли и нужна ли маска» (services/outdoor.py)."""
    o = ctx.get("outdoor")
    if not o:
        return None
    lines = [f"**{o['title']}**"]
    lines += [f"- {r[0].upper() + r[1:]}" for r in o["reasons"]]
    lines += [f"- {t}" for t in o["tips"]]
    return "\n".join(lines)


BLOCKS = {"outdoor": _block_outdoor, "sleep": _block_sleep, "goals": _block_goals, "meds": _block_meds, "weather": _block_weather}


def context_issues(ctx: dict) -> list[str]:
    """Темы, на которые стоит дать совет ПРЯМО СЕЙЧАС (по свежей аналитике, не по вопросу).
    Используется, когда вопрос общий, и для карточек «Инсайты» на странице ИИ."""
    issues = []
    o = ctx.get("outdoor")
    if o and (o["verdict"] != "go" or o["mask"]):
        issues.append("outdoor")
    s = ctx.get("sleep")
    if s and (s["last"]["hours"] < 6.5 or s["last"]["score"] < 65):
        issues.append("sleep")
    adh = ((ctx.get("meds") or {}).get("adherence") or {}).get("pct")
    if adh is not None and adh < 80:
        issues.append("medication")
    w = ctx.get("weather") or {}
    if "outdoor" not in issues and (w.get("uv_level") in ("high", "very_high", "extreme") or (w.get("t_max") or 0) >= 33):
        issues.append("heat_uv")
    goals = ctx.get("goals") or []
    if goals and sum(g["pct"] for g in goals) / len(goals) < 40:
        issues.append("goals")
    return issues


# ------------------------------------------------------------------ итоговый ответ
def builtin_answer(message: str, history: list[dict], ctx: dict, lang: str) -> str:
    """Встроенный ответ + блоки контекста (сон/цели/лекарства/погода) по теме вопроса."""
    base = _builtin(message, history, ctx, lang)
    text = f" {message.lower().strip()} "
    topics = _detect_topics(text)
    wanted: list[str] = []
    for t in topics:
        wanted += [b for b in TOPIC_BLOCKS.get(t, []) if b not in wanted]
    if _has(text, STATUS_KEYWORDS):            # «как мои показатели?» — полная картина дня
        wanted = ["outdoor", "sleep", "meds", "goals"]
    blocks = [b for b in (BLOCKS[name](ctx, lang) for name in wanted) if b]
    if not blocks:
        return base
    # вставляем блоки после блока с показателями (перед советами), чтобы ответ читался логично
    parts = base.split("\n\n")
    tips_titles = set(PHRASES[lang]["tips_title"])
    pos = next((i for i, p in enumerate(parts) if p.split("\n")[0] in tips_titles), len(parts) - 2)
    return "\n\n".join(parts[:pos] + blocks + parts[pos:])


def _llm_system(ctx: dict, lang: str, reference: str) -> str:
    """Системная подсказка для локальной LLM: факты + правила. Модель не видит email/телефон и т.п."""
    facts = {k: ctx.get(k) for k in ("name", "age", "gender", "latest", "avg", "kcal_total", "goals", "weather")}
    if ctx.get("outdoor"):
        facts["outdoor_advice"] = {k: ctx["outdoor"][k] for k in ("verdict", "mask", "reasons")}
    if ctx.get("sleep"):
        facts["sleep_last"] = {k: ctx["sleep"]["last"].get(k) for k in ("hours", "score", "awakenings", "onset", "wake")}
    if ctx.get("meds"):
        facts["meds_today"] = ctx["meds"].get("today")
        facts["adherence_pct"] = (ctx["meds"].get("adherence") or {}).get("pct")
    return (
        "Ты — локальный медицинский ИИ-ассистент портала MIRA (реабилитация и домашний мониторинг). "
        f"Отвечай на {LANG_NAME[lang]} языке, тепло и спокойно, 120–250 слов, Markdown со списками. "
        "Используй ТОЛЬКО факты ниже, не выдумывай цифры. Не ставь диагнозы, не назначай и не меняй лекарства и дозы. "
        "Не пугай пациента и не используй слово «критично»; при опасных симптомах, которые описывает сам пациент, "
        "спокойно посоветуй звонить 103. Закончи коротким уточняющим вопросом.\n\n"
        f"Факты о пациенте (JSON): {json.dumps(facts, ensure_ascii=False, default=str)}\n\n"
        f"Черновик ответа встроенного движка (можно опираться):\n{reference}"
    )


async def answer(message: str, history: list[dict], ctx: dict, lang: str) -> str:
    """Главная функция: сначала встроенный ответ; если есть локальная LLM — она его «очеловечивает»."""
    reference = builtin_answer(message, history, ctx, lang)
    if local_llm.available():
        try:
            return await local_llm.chat(_llm_system(ctx, lang, reference), history, message)
        except Exception as e:  # noqa: BLE001 — LLM недоступна: отвечаем встроенным движком
            log.warning("Local LLM failed, built-in answer used: %s", e)
    return reference
