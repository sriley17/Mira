"""
oneid.py — ВХОД ЧЕРЕЗ OneID (единая система идентификации госуслуг Узбекистана, id.egov.uz)
========================================================================================
Как устроен вход (OAuth 2.0, как «войти через Google», только через госуслуги):

  1. Пользователь нажимает «Войти через OneID». Мы отправляем его на страницу OneID:
        GET {ONEID_BASE_URL}?response_type=one_code&client_id=...&redirect_uri=...&scope=...&state=...
     state — случайная строка: защищает от подделки ответа (CSRF), проверяется на шаге 3.
  2. Человек входит в OneID (логин/пароль, ЭЦП или ID-карта). OneID возвращает его обратно на
     наш сайт с параметрами ?code=...&state=...
  3. Сервер MIRA (не браузер!) меняет code на access_token:
        POST {ONEID_BASE_URL} grant_type=one_authorization_code, client_id, client_secret, code, redirect_uri
  4. По access_token получаем данные человека:
        POST {ONEID_BASE_URL} grant_type=one_access_token_identify, client_id, client_secret, access_token, scope
     Ответ содержит ФИО, дату рождения, пол, ПИНФЛ и др.

client_id / client_secret выдаёт оператор OneID после регистрации системы. Названия полей
ниже соответствуют публичному описанию протокола; при подключении сверьте их с документацией,
которую оператор выдаст вместе с ключами (менять нужно только функцию _map_user).

Без ключей интеграция «не подключена» — кнопка честно сообщает об этом, ничего не имитирует.
"""
import hashlib
import hmac
import secrets
import time
from datetime import date
from urllib.parse import urlencode

import httpx

from ..config import get_settings

settings = get_settings()
_STATES: dict[str, tuple[float, str]] = {}   # state -> (время создания, роль)
STATE_TTL = 600                               # у пользователя 10 минут на вход в OneID


class OneIDError(Exception):
    pass


def configured() -> bool:
    return bool(settings.oneid_client_id and settings.oneid_client_secret)


def authorize_url(role: str) -> str:
    """Шаг 1: адрес страницы OneID + одноразовый state."""
    now = time.time()
    for k in [k for k, (ts, _) in _STATES.items() if now - ts > STATE_TTL]:
        _STATES.pop(k, None)                       # чистим просроченные
    state = secrets.token_urlsafe(24)
    _STATES[state] = (now, role)
    params = {"response_type": "one_code", "client_id": settings.oneid_client_id,
              "redirect_uri": settings.oneid_redirect_uri, "scope": settings.oneid_scope, "state": state}
    return f"{settings.oneid_base_url}?{urlencode(params)}"


def pop_state(state: str) -> str:
    """Проверка state (шаг 3). Одноразовый: повторно использовать нельзя. Возвращает роль."""
    item = _STATES.pop(state, None)
    if not item or time.time() - item[0] > STATE_TTL:
        raise OneIDError("invalid or expired state")
    return item[1]


def subject(pin: str) -> str:
    """Постоянный идентификатор человека для нашей базы: HMAC от ПИНФЛ с секретом сервера.
    Сам ПИНФЛ как ключ поиска не храним — по базе нельзя перебрать ПИНФЛ."""
    return hmac.new(settings.jwt_secret.encode(), pin.encode(), hashlib.sha256).hexdigest()


def _age(birth: str | None) -> int:
    try:
        b = date.fromisoformat(birth[:10]) if birth else None
    except ValueError:
        b = None
    if not b:
        return 30
    t = date.today()
    return t.year - b.year - ((t.month, t.day) < (b.month, b.day))


def _map_user(raw: dict) -> dict:
    """Ответ OneID -> наш формат. Единственное место, зависящее от названий их полей."""
    gd = str(raw.get("gd", "")).strip()
    return {"pin": str(raw.get("pin", "")), "first_name": raw.get("first_name") or "",
            "last_name": raw.get("sur_name") or "", "middle_name": raw.get("mid_name") or "",
            "birth_date": raw.get("birth_date"), "age": _age(raw.get("birth_date")),
            "gender": "female" if gd in ("2", "F", "f") else "male",
            "email": (raw.get("email") or "").lower(), "phone": raw.get("mob_phone") or ""}


async def exchange(code: str) -> dict:
    """Шаги 3–4: code -> access_token -> данные пользователя."""
    if not configured():
        raise OneIDError("OneID is not configured")
    base = {"client_id": settings.oneid_client_id, "client_secret": settings.oneid_client_secret}
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.post(settings.oneid_base_url, data={**base, "grant_type": "one_authorization_code",
                                                             "code": code, "redirect_uri": settings.oneid_redirect_uri})
        r.raise_for_status()
        token = r.json().get("access_token")
        if not token:
            raise OneIDError("no access_token")
        r = await client.post(settings.oneid_base_url, data={**base, "grant_type": "one_access_token_identify",
                                                             "access_token": token, "scope": settings.oneid_scope})
        r.raise_for_status()
        user = _map_user(r.json())
    if not user["pin"]:
        raise OneIDError("OneID did not return identity")
    return user
