"""
simulator.py — СИМУЛЯТОР УСТРОЙСТВА MIRA
=======================================
Пока нет настоящего браслета, симулятор каждые 2 секунды «присылает» показатели для каждого
пациента с устройством, а новому пациенту создаёт историю за 30 дней (отчёты сразу «живые»).

Реалистичность:
* суточный ритм (_daily_factor): ночью пульс и давление ниже, днём выше;
* СОН (sleep_state): у каждого пациента своё время отхода ко сну и пробуждения, разное каждую
  ночь, с короткими пробуждениями. Во сне пульс падает на ~14 уд/мин (на 15–20 %, как у реальных людей), дыхание замедляется,
  калорий тратится меньше. По этим признакам модуль sleep.py потом «узнаёт» сон — так же,
  как это делают настоящие фитнес-браслеты;
* три демо-профиля (стабильный, гипертоник, плохой контроль сахара) — чтобы врачу было что анализировать;
* редкие критические всплески — чтобы показать работу тревог и вызова скорой.
"""
import asyncio
from functools import lru_cache
import logging
import math
import random
from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..database import SessionLocal
from ..models import Device, Measurement, User, utcnow
from .ingest import ingest_reading

log = logging.getLogger("mira.simulator")
settings = get_settings()

BASE = {"heart_rate": 74, "systolic": 118, "diastolic": 77, "glucose": 5.4, "resp_rate": 15,
        "spo2": 97.5, "body_temp": 36.6, "room_temp": 23.0}
NOISE = {"heart_rate": 1.5, "systolic": 1.2, "diastolic": 0.8, "glucose": 0.05, "resp_rate": 0.3,
         "spo2": 0.2, "body_temp": 0.02, "room_temp": 0.05}
KCAL_PER_HOUR = 95.0
TZ = ZoneInfo(settings.timezone)

# Demo patient profiles, so the doctor's analytics show different clinical pictures
PROFILES = [
    {"systolic": 0, "diastolic": 0, "heart_rate": 0, "glucose": 0.0, "dip": 1.0, "gvar": 1.0},     # stable
    {"systolic": 20, "diastolic": 10, "heart_rate": 6, "glucose": 0.0, "dip": 0.25, "gvar": 1.0},  # hypertensive, non-dipper
    {"systolic": 6, "diastolic": 3, "heart_rate": 4, "glucose": 2.6, "dip": 0.8, "gvar": 3.0},     # poor glucose control
]


def profile_for(patient_id: int) -> dict:
    return PROFILES[(patient_id - 2) % len(PROFILES)]


def _daily_factor(ts: datetime) -> float:
    """Circadian curve in local time: lowest around 3 am, highest around 3 pm."""
    loc = ts.replace(tzinfo=timezone.utc).astimezone(TZ)
    hour = loc.hour + loc.minute / 60
    return math.sin((hour - 9) / 24 * 2 * math.pi)


@lru_cache(maxsize=4096)   # план ночи вычисляется один раз и запоминается
def _night_plan(patient_id: int, evening: date) -> dict:
    """План одной ночи (детерминированный: одинаковый при каждом вызове для той же даты).
    evening — местная дата вечера, когда пациент ложится спать."""
    rng = random.Random(patient_id * 100_003 + evening.toordinal())
    bed = datetime.combine(evening, time(22, 0)) + timedelta(minutes=rng.randint(0, 150))   # 22:00–00:30
    wake = datetime.combine(evening + timedelta(days=1), time(5, 45)) + timedelta(minutes=rng.randint(0, 120))
    wakes = []  # короткие ночные пробуждения (0–3 за ночь, по 10–25 минут)
    for _ in range(rng.choice([0, 1, 1, 2, 3])):
        start = bed + (wake - bed) * rng.uniform(0.15, 0.85)
        wakes.append((start, start + timedelta(minutes=rng.randint(10, 25))))
    return {"bed": bed, "wake": wake, "wakes": wakes}


def sleep_state(patient_id: int, ts_utc: datetime) -> bool:
    """True, если в момент ts_utc пациент спит (по плану ночи). Время сравниваем в МЕСТНОМ поясе."""
    loc = ts_utc.replace(tzinfo=timezone.utc).astimezone(TZ).replace(tzinfo=None)
    evening = (loc - timedelta(hours=12)).date()   # до полудня — это ещё «вчерашняя» ночь
    plan = _night_plan(patient_id, evening)
    if not plan["bed"] <= loc < plan["wake"]:
        return False
    return not any(a <= loc < b for a, b in plan["wakes"])


# Насколько меняются показатели во сне (относительно бодрствования)
SLEEP_SHIFT = {"heart_rate": -14, "systolic": -6, "diastolic": -4, "resp_rate": -2.5, "spo2": -0.6,
               "body_temp": -0.25}


def synthetic_reading(ts: datetime, rng: random.Random, minutes: float, prof: dict | None = None,
                      patient_id: int | None = None) -> dict:
    prof = prof or PROFILES[0]
    f = _daily_factor(ts)
    asleep = patient_id is not None and sleep_state(patient_id, ts)
    loc_hour = ts.replace(tzinfo=timezone.utc).astimezone(TZ).hour
    meal = max(0, math.sin(loc_hour / 24 * 6 * math.pi))
    r = {
        "heart_rate": BASE["heart_rate"] + prof["heart_rate"] + 8 * f + rng.gauss(0, 4),
        "systolic": BASE["systolic"] + prof["systolic"] + 11 * f * prof["dip"] + rng.gauss(0, 4),
        "diastolic": BASE["diastolic"] + prof["diastolic"] + 6 * f * prof["dip"] + rng.gauss(0, 3),
        "glucose": BASE["glucose"] + prof["glucose"] + 0.8 * meal * prof["gvar"] + rng.gauss(0, 0.3 * prof["gvar"]),
        "resp_rate": BASE["resp_rate"] + 1.5 * f + rng.gauss(0, 1),
        "spo2": min(100, BASE["spo2"] + rng.gauss(0, 0.6)),
        "body_temp": BASE["body_temp"] + 0.2 * f + rng.gauss(0, 0.1),
        "room_temp": BASE["room_temp"] + 1.5 * f + rng.gauss(0, 0.3),
    }
    kcal_factor = 1 + 0.5 * max(0, f)
    if asleep:
        for k, d in SLEEP_SHIFT.items():
            r[k] += d
        kcal_factor = 0.7   # во сне расход энергии ниже
    r["calories"] = KCAL_PER_HOUR * minutes / 60 * kcal_factor * rng.uniform(0.8, 1.2)
    return {k: round(v, 2) for k, v in r.items()}


def seed_history(db: Session, patient: User, days: int = 30, step_min: int = 15) -> None:
    rng = random.Random(patient.id)
    end = utcnow().replace(second=0, microsecond=0)
    t = end - timedelta(days=days)
    rows = []
    while t < end:
        rows.append(Measurement(user_id=patient.id, ts=t,
                                **synthetic_reading(t, rng, step_min, profile_for(patient.id), patient.id)))
        t += timedelta(minutes=step_min)
    db.add_all(rows)
    db.commit()


class _State:
    def __init__(self, seed: int, prof: dict):
        self.rng = random.Random(seed)
        self.prof = prof
        self.base = {k: v + prof.get(k, 0) for k, v in BASE.items()}
        self.vals = dict(self.base)
        self.kcal_acc = 0.0
        self.ticks = 0
        self.spike_left = 0
        self.spike_metric = None


_states: dict[int, _State] = {}


def _next(state: _State, patient_id: int) -> dict:
    rng = state.rng
    now = utcnow()
    f = _daily_factor(now)
    asleep = sleep_state(patient_id, now)
    amp = {"systolic": 11 * state.prof["dip"], "diastolic": 6 * state.prof["dip"], "heart_rate": 8}
    for k in state.vals:  # случайное блуждание с возвратом к личной норме (с учётом суточного ритма и сна)
        target = state.base[k] + amp.get(k, 0) * f + (SLEEP_SHIFT.get(k, 0) if asleep else 0)
        state.vals[k] += (target - state.vals[k]) * 0.08 + rng.gauss(0, NOISE[k] * (state.prof["gvar"] if k == "glucose" else 1))
    reading = dict(state.vals)

    if state.spike_left == 0 and rng.random() < settings.simulator_critical_chance:
        state.spike_metric = rng.choice(["heart_rate", "systolic", "glucose", "spo2"])
        state.spike_left = 3
    if state.spike_left > 0:
        state.spike_left -= 1
        spikes = {"heart_rate": 150, "systolic": 190, "glucose": 17.5, "spo2": 87}
        reading[state.spike_metric] = spikes[state.spike_metric] + rng.gauss(0, 1)
        if state.spike_metric == "systolic":
            reading["diastolic"] = 118 + rng.gauss(0, 2)

    reading["spo2"] = min(100.0, reading["spo2"])
    kcal = KCAL_PER_HOUR * settings.simulator_interval_sec / 3600 * rng.uniform(0.8, 1.3) * (0.7 if asleep else 1.0)
    state.kcal_acc += kcal
    reading["calories"] = kcal
    return {k: round(v, 3 if k == "calories" else 2) for k, v in reading.items()}


async def run_simulator() -> None:
    persist_every = max(1, round(30 / settings.simulator_interval_sec))  # store ~every 30 s
    log.info("Simulator started (interval %.1fs)", settings.simulator_interval_sec)
    while True:
        try:
            with SessionLocal() as db:
                # только одобренные пациенты: у ожидающих подтверждения устройство ещё не активно
                patients = db.scalars(select(User).join(Device).where(User.role == "patient",
                                                                      User.status == "approved")).all()
                for p in patients:
                    st = _states.setdefault(p.id, _State(p.id * 7919, profile_for(p.id)))
                    reading = _next(st, p.id)
                    st.ticks += 1
                    dev = p.device
                    reading["battery"] = dev.battery - 0.02 if dev.battery > 8 else 100.0
                    reading["lat"] = dev.lat + st.rng.gauss(0, 0.00005)
                    reading["lon"] = dev.lon + st.rng.gauss(0, 0.00005)
                    persist = st.ticks % persist_every == 0
                    stored_kcal = None
                    if persist:
                        stored_kcal = round(st.kcal_acc, 3)
                        st.kcal_acc = 0.0
                    await ingest_reading(db, p, reading, persist=persist, stored_calories=stored_kcal)
        except Exception:  # keep the loop alive no matter what
            log.exception("Simulator tick failed")
        await asyncio.sleep(settings.simulator_interval_sec)
