"""Clinical-style thresholds for alerts. (low_crit, low_warn, high_warn, high_crit); None = no bound.
Values are indicative for a demo and must be reviewed by a medical professional before real use."""

THRESHOLDS: dict[str, tuple[float | None, float | None, float | None, float | None]] = {
    "heart_rate": (40, 50, 110, 140),
    "systolic": (80, 90, 140, 180),
    "diastolic": (None, None, 90, 120),
    "glucose": (3.0, 3.9, 10.0, 16.7),
    "resp_rate": (8, 10, 24, 30),
    "spo2": (90, 94, None, None),
    "body_temp": (35.0, 35.5, 37.8, 39.5),
}


def classify(metric: str, value: float) -> str:
    """Return 'normal' | 'warning' | 'critical'."""
    bounds = THRESHOLDS.get(metric)
    if not bounds:
        return "normal"
    lc, lw, hw, hc = bounds
    if (lc is not None and value < lc) or (hc is not None and value > hc):
        return "critical"
    if (lw is not None and value < lw) or (hw is not None and value > hw):
        return "warning"
    return "normal"


def evaluate(reading: dict) -> list[tuple[str, float, str]]:
    """List of (metric, value, level) for every non-normal metric."""
    out = []
    for metric in THRESHOLDS:
        if metric in reading and reading[metric] is not None:
            level = classify(metric, float(reading[metric]))
            if level != "normal":
                out.append((metric, float(reading[metric]), level))
    return out
