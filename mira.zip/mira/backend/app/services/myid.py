"""
myid.py — ПРОВЕРКА ЛИЧНОСТИ ПО ЛИЦУ (MyID)
=========================================
MyID — национальная система удалённой идентификации: селфи человека сравнивается с фотографией
из государственной базы (паспорт / ID-карта) по ПИНФЛ или серии паспорта и дате рождения.

Зачем в MIRA: медицинские данные нельзя открывать тому, кто просто узнал чужой пароль.
При первом входе пациент и врач проходят проверку лица; пока она не пройдена, медицинские
разделы закрыты (security.get_current_user -> 403 identity_required).

Режимы:
  • MYID_BASE_URL / MYID_CLIENT_ID / MYID_CLIENT_SECRET заданы -> реальный запрос в MyID.
    Путь и поля запроса зависят от договора с оператором — они собраны в _myid_request,
    поправьте их по выданной документации.
  • не заданы -> ДЕМО-проверка: локальный детектор OpenCV проверяет, что на снимке ровно одно
    лицо нормального размера (не пустой кадр, не фото экрана с несколькими лицами). Это НЕ
    сравнение с паспортом — результат помечается source="demo", и это видно в журнале.

Селфи хранится только в зашифрованном виде (identity_checks.selfie_enc) — для разбора спорных случаев.
"""
import base64
import io
import logging

import httpx
from PIL import Image

from ..config import get_settings

log = logging.getLogger("mira.myid")
settings = get_settings()

try:                                   # OpenCV необязателен: без него демо-проверка проще
    import cv2
    import numpy as np
    _CASCADE = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
except Exception:  # noqa: BLE001
    cv2 = None
    _CASCADE = None


def configured() -> bool:
    return bool(settings.myid_base_url and settings.myid_client_id and settings.myid_client_secret)


def _faces(jpeg: bytes) -> int | None:
    """Сколько лиц на снимке (None — детектор недоступен)."""
    if _CASCADE is None:
        return None
    img = np.array(Image.open(io.BytesIO(jpeg)).convert("L"))
    h, w = img.shape
    faces = _CASCADE.detectMultiScale(img, scaleFactor=1.1, minNeighbors=6,
                                      minSize=(int(min(h, w) * 0.2), int(min(h, w) * 0.2)))
    return len(faces)


async def _myid_request(jpeg: bytes, pinfl: str | None, birth_date: str | None) -> tuple[str, float | None, str]:
    """Реальная проверка в MyID. Возвращает (result, score, reason)."""
    payload = {"photo_from_camera": {"front": base64.b64encode(jpeg).decode()},
               "pinfl": pinfl, "birth_date": birth_date}
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(f"{settings.myid_base_url.rstrip('/')}/api/v1/authentication/simple-inplace",
                              json=payload, auth=(settings.myid_client_id, settings.myid_client_secret))
    if r.status_code >= 500:
        return "error", None, f"myid http {r.status_code}"
    data = r.json()
    score = data.get("comparison_value")
    ok = bool(data.get("result_code") in (1, "1", "success") or (score is not None and score >= 0.7))
    return ("verified" if ok else "rejected"), score, str(data.get("result_note") or "")[:120]


async def verify(jpeg: bytes, pinfl: str | None = None, birth_date: str | None = None) -> dict:
    """Главная функция. Возвращает {"result": verified|rejected|error, "source", "score", "reason"}."""
    if configured():
        try:
            result, score, reason = await _myid_request(jpeg, pinfl, birth_date)
            return {"result": result, "source": "myid", "score": score, "reason": reason}
        except (httpx.HTTPError, ValueError) as e:
            log.error("MyID request failed: %s", e)
            return {"result": "error", "source": "myid", "score": None, "reason": "myid unavailable"}
    n = _faces(jpeg)
    if n is None:
        return {"result": "verified", "source": "demo", "score": None, "reason": "no detector (demo)"}
    if n == 1:
        return {"result": "verified", "source": "demo", "score": None, "reason": "one face detected"}
    return {"result": "rejected", "source": "demo", "score": None,
            "reason": "no face detected" if n == 0 else "more than one face"}
