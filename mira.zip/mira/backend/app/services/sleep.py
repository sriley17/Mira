"""
sleep.py — АНАЛИЗ СНА ПО ДАННЫМ УСТРОЙСТВА
=========================================
Как браслет «понимает», что человек спит? Во сне пульс заметно ниже, чем днём, дыхание
реже, организм тратит меньше энергии. Алгоритм (для каждой ночи):

1. Берём измерения с 20:00 вечера до 12:00 следующего дня (местное время).
2. Считаем «дневную норму» пульса пациента — медиану за 12:00–20:00 того же дня.
3. Сглаживаем пульс (средние по 5 минут + скользящая медиана), чтобы убрать шум.
4. Интервал считается сном, если пульс ниже персонального порога (середина между дневной
   нормой и ночным минимумом, но минимум на 8 уд/мин ниже дневной нормы).
5. Засыпание — первый отрезок сна длиннее 20 минут; пробуждение — конец последнего такого отрезка.
   Между ними считаем время сна, эффективность (сон / время в кровати) и число пробуждений.
6. Во время сна собираем пульс, SpO₂, давление, сахар, температуру тела и комнаты.
7. Оценка качества 0–100 — сумма понятных составляющих (каждая объясняется в `factors`):
       длительность          до 35 баллов (идеал 7–9 ч)
       эффективность         до 20 (идеал ≥ 90 %)
       пробуждения           до 15 (0–1 — отлично)
       кислород (SpO₂ мин.)  до 15 (≥ 94 % — отлично)
       температура в комнате до 10 (18–24 °C)
       пульс во сне          до 5  (ниже дневного — норма)
8. Добавляем погоду и УФ-индекс за день (weather.py): жара ночью и высокий УФ днём
   объясняют плохой сон и попадают в советы ИИ.

Это оценка по домашнему устройству, а не полисомнография; итоговые выводы делает врач.
"""
from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

import pandas as pd

from ..config import get_settings
from ..models import User, utcnow
from ..routers.measurements import load_frame
from . import weather

settings = get_settings()
TZ = ZoneInfo(settings.timezone)

SLEEP_HR_MIN_DROP = 8      # порог сна минимум на 8 уд/мин ниже дневной нормы
MIN_SEGMENT_MIN = 20       # короче — это не сон, а просто спокойный отдых
WAKE_MIN = 10              # пробуждение короче 10 минут не считаем


def _to_local(ts: pd.Series) -> pd.Series:
    """UTC (как хранится в БД) -> местное время без пояса."""
    return ts.dt.tz_localize("UTC").dt.tz_convert(TZ).dt.tz_localize(None)


def _segments(mask: pd.Series) -> list[tuple[pd.Timestamp, pd.Timestamp]]:
    """Непрерывные отрезки True в булевом ряду -> список (начало, конец)."""
    out, start, prev = [], None, None
    step = mask.index.to_series().diff().median() if len(mask) > 1 else pd.Timedelta(minutes=5)
    for ts, val in mask.items():
        if val and start is None:
            start = ts
        if not val and start is not None:
            out.append((start, prev + step))
            start = None
        prev = ts
    if start is not None:
        out.append((start, prev + step))
    return out


def _score(hours: float, eff: float, wakes: int, spo2_min: float | None, room: float | None,
           hr_drop: float | None) -> tuple[int, list[dict]]:
    """Оценка качества сна и объяснение каждой составляющей (для интерфейса и ИИ)."""
    f = []
    # длительность: 7–9 ч = максимум; каждые полчаса отклонения — минус баллы
    if 7 <= hours <= 9:
        d = 35
    else:
        gap = 7 - hours if hours < 7 else hours - 9
        d = max(0, round(35 - gap * 12))
    f.append({"code": "duration", "points": d, "max": 35, "value": round(hours, 1)})
    e = 20 if eff >= 0.9 else max(0, round(20 - (0.9 - eff) * 100))
    f.append({"code": "efficiency", "points": e, "max": 20, "value": round(eff * 100)})
    w = {0: 15, 1: 15, 2: 10, 3: 6}.get(wakes, 2)
    f.append({"code": "awakenings", "points": w, "max": 15, "value": wakes})
    if spo2_min is not None:
        o = 15 if spo2_min >= 94 else 10 if spo2_min >= 92 else 4 if spo2_min >= 90 else 0
        f.append({"code": "spo2", "points": o, "max": 15, "value": round(spo2_min, 1)})
    if room is not None:
        r = 10 if 18 <= room <= 24 else 6 if 16 <= room <= 26 else 2
        f.append({"code": "room_temp", "points": r, "max": 10, "value": round(room, 1)})
    if hr_drop is not None:
        h = 5 if hr_drop >= 8 else 3 if hr_drop >= 4 else 0
        f.append({"code": "hr_dip", "points": h, "max": 5, "value": round(hr_drop, 1)})
    total_max = sum(x["max"] for x in f)
    score = round(sum(x["points"] for x in f) / total_max * 100) if total_max else 0
    return score, f


def analyze_night(df_local: pd.DataFrame, evening: date) -> dict | None:
    """Анализ одной ночи. df_local — измерения с колонкой ts в местном времени."""
    start = datetime.combine(evening, time(20, 0))
    end = datetime.combine(evening + timedelta(days=1), time(12, 0))
    night = df_local[(df_local["ts"] >= start) & (df_local["ts"] < end)].set_index("ts")
    day = df_local[(df_local["ts"] >= datetime.combine(evening, time(12, 0))) &
                   (df_local["ts"] < start)]
    if len(night) < 12:
        return None  # слишком мало данных (устройство было выключено)
    # дневная норма пульса; если дневных данных нет — берём верхний квартиль ночного окна
    day_hr = float(day["heart_rate"].median()) if len(day) >= 6 else float(night["heart_rate"].quantile(0.75))

    # Сетка по 5 минут. История хранится раз в 15 минут, «живые» данные — раз в 30 секунд;
    # interpolate заполняет пустые 5-минутки между соседними точками (не дальше 20 минут),
    # чтобы время сна считалось одинаково при любой частоте измерений.
    m5 = (night.resample("5min").mean(numeric_only=True)
          .interpolate(limit=4, limit_area="inside").dropna(subset=["heart_rate"]))
    # скользящая медиана за ~35 минут убирает случайные скачки пульса
    hr_smooth = m5["heart_rate"].rolling(7, center=True, min_periods=2).median()
    # Порог сна подбирается ПЕРСОНАЛЬНО: середина между дневной нормой и самым низким ночным
    # пульсом (10-й перцентиль). Так алгоритм одинаково работает и у спортсмена с пульсом 55,
    # и у пациента с пульсом 90. Но не ближе 8 уд/мин к дневной норме — иначе бессонную ночь
    # можно принять за сон.
    night_low = float(hr_smooth.quantile(0.10))
    threshold = min((night_low + day_hr) / 2, day_hr - SLEEP_HR_MIN_DROP)
    asleep = hr_smooth < threshold

    segs = [s for s in _segments(asleep) if (s[1] - s[0]) >= pd.Timedelta(minutes=MIN_SEGMENT_MIN)]
    if not segs:
        return {"date": evening.isoformat(), "detected": False}
    onset, wake = segs[0][0], segs[-1][1]
    in_bed = m5.loc[onset:wake - pd.Timedelta(seconds=1)]
    sleep_mask = asleep.loc[in_bed.index]
    step_min = 5
    slept_min = int(sleep_mask.sum()) * step_min
    total_min = max(step_min, len(in_bed) * step_min)
    gaps = _segments(~sleep_mask)
    wakes = sum(1 for a, b in gaps if (b - a) >= pd.Timedelta(minutes=WAKE_MIN))
    during = in_bed[sleep_mask]

    def avg(col, digits=1):
        return round(float(during[col].mean()), digits) if col in during and len(during) else None

    spo2_min = round(float(during["spo2"].min()), 1) if len(during) else None
    hr_sleep = avg("heart_rate", 0)
    hours = slept_min / 60
    eff = slept_min / total_min
    score, factors = _score(hours, eff, wakes, spo2_min, avg("room_temp"),
                            (day_hr - hr_sleep) if hr_sleep is not None else None)
    return {
        "date": evening.isoformat(), "detected": True,
        "onset": onset.strftime("%H:%M"), "wake": wake.strftime("%H:%M"),
        "hours": round(hours, 2), "efficiency": round(eff * 100), "awakenings": wakes,
        "score": score, "factors": factors,
        "vitals": {"heart_rate": hr_sleep, "heart_rate_day": round(day_hr), "spo2_avg": avg("spo2"),
                   "spo2_min": spo2_min, "systolic": avg("systolic", 0), "diastolic": avg("diastolic", 0),
                   "glucose": avg("glucose"), "body_temp": avg("body_temp"), "room_temp": avg("room_temp"),
                   "resp_rate": avg("resp_rate")},
        # почасовой пульс для графика «гипнограммы»
        "curve": [{"t": ts.strftime("%H:%M"), "hr": round(float(v)), "asleep": bool(asleep.get(ts, False))}
                  for ts, v in hr_smooth.resample("15min").mean().dropna().items()],
    }


async def analyze(patient: User, nights: int = 7) -> dict:
    """Анализ сна за последние `nights` ночей + погода + средние значения + тренд."""
    now = utcnow()
    df = load_frame(patient.id, now - timedelta(days=nights + 1, hours=12), now)
    if df.empty:
        return {"nights": [], "summary": None, "weather_source": None}
    df["ts"] = _to_local(df["ts"])
    today_local = now.replace(tzinfo=timezone.utc).astimezone(TZ).date()
    dev = patient.device
    wx = await weather.daily_weather(dev.lat if dev else 41.31, dev.lon if dev else 69.28, days_back=nights + 1)

    result = []
    for i in range(nights, 0, -1):
        evening = today_local - timedelta(days=i)
        n = analyze_night(df, evening)
        if not n:
            continue
        w = weather.for_day(wx, evening)             # погода вечера/ночи
        n["weather"] = {"night_min": w["t_min"], "day_max": w["t_max"], "uv_max": w["uv_max"],
                        "uv_level": w["uv_level"]}
        result.append(n)

    ok = [n for n in result if n.get("detected")]
    summary = None
    if ok:
        last = ok[-1]
        avg_h = sum(n["hours"] for n in ok) / len(ok)
        avg_s = sum(n["score"] for n in ok) / len(ok)
        summary = {"last": last, "avg_hours": round(avg_h, 2), "avg_score": round(avg_s),
                   "trend": ("up" if last["score"] > avg_s + 7 else "down" if last["score"] < avg_s - 7 else "stable"),
                   "short_nights": sum(1 for n in ok if n["hours"] < 6.5),
                   "weakest": min(last["factors"], key=lambda f: f["points"] / f["max"])["code"]}
    return {"nights": result, "summary": summary, "weather_source": wx["source"]}
