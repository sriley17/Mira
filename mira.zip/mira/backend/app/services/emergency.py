"""
emergency.py — КРИТИЧЕСКИЕ СИТУАЦИИ И ВЫЗОВ СКОРОЙ
=================================================
Что происходит, когда показатель выходит за критическую границу (thresholds.py):

1. Тревога сохраняется в таблицу alerts (с координатами GPS).
2. Один инцидент = одна тревога: пока показатель остаётся плохим (alert_incident_sec, 10 мин),
   новые тревоги не создаются — только при ухудшении warning -> critical. Никаких повторов.
3. При критическом уровне:
      • врач получает сообщение и push-уведомление через WebSocket (канал doctor:{id});
      • вызывается скорая: webhook экстренной службы и/или SMS на номер 103 через шлюз;
        не чаще одного вызова за alert_cooldown_sec (5 мин).
4. ПАЦИЕНТ ТРЕВОГУ НЕ ПОЛУЧАЕТ (ТЗ: «пациенты не уведомляются напрямую, чтобы избежать
   психологического стресса — критические сигналы видят только врачи»). Поэтому событие
   публикуется ТОЛЬКО в канал врача.
"""
import logging
from datetime import timedelta

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..models import Alert, Device, Message, User, utcnow
from ..security import decrypt, encrypt, mask_phone
from .sms import send_sms
from .ws_manager import doctor_channel, manager

log = logging.getLogger("mira.emergency")
settings = get_settings()


async def _call_ambulance(db: Session, patient: User, device: Device | None, metric: str, value: float) -> bool:
    """Отправка сигнала SOS. Телефон пациента расшифровывается только здесь, в момент вызова."""
    lat = device.lat if device else None
    lon = device.lon if device else None
    phone = decrypt(patient.phone_enc) if patient.phone_enc else ""
    text = (f"MIRA SOS: {patient.first_name} {patient.last_name}, {patient.age}y. "
            f"{metric}. GPS: {lat},{lon}. Phone: {phone or '-'}")
    payload = {"patient_id": patient.id, "name": f"{patient.first_name} {patient.last_name}",
               "age": patient.age, "metric": metric, "value": value, "lat": lat, "lon": lon,
               "phone": phone, "message": text}
    sent = False
    if settings.ambulance_webhook_url:
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                r = await client.post(settings.ambulance_webhook_url, json=payload)
            sent = r.is_success
        except httpx.HTTPError as e:
            log.error("Ambulance webhook failed: %s", e)
    if settings.sms_gateway_url:
        sent = (await send_sms(db, settings.ambulance_phone, text, "sos", patient.id) == "sent") or sent
    if not (settings.ambulance_webhook_url or settings.sms_gateway_url):
        # демо-режим: в лог пишем без полного телефона
        log.warning("[DEMO] Ambulance would be called now: patient %s, %s, GPS %s,%s, phone %s",
                    patient.id, metric, lat, lon, mask_phone(phone) or "-")
        sent = True
    return sent


LEVELS = {"warning": 1, "critical": 2}


async def handle_alerts(db: Session, patient: User, findings: list[tuple[str, float, str]]) -> list[Alert]:
    """One alert per incident: while a metric stays abnormal, no new alerts are created for it
    (only if it escalates warning -> critical). One doctor message and one SOS per incident."""
    if not findings:
        return []
    names = {m for m, _, _ in findings}
    if "systolic" in names:  # blood pressure = one signal, not two
        findings = [f for f in findings if f[0] != "diastolic"]
    device = patient.device
    now = utcnow()
    window = now - timedelta(seconds=settings.alert_incident_sec)
    created, fresh = [], []
    for metric, value, level in findings:
        last = db.scalar(select(Alert).where(Alert.user_id == patient.id, Alert.metric == metric, Alert.ts > window)
                         .order_by(Alert.ts.desc()).limit(1))
        if last and LEVELS[last.level] >= LEVELS[level]:
            continue  # same ongoing incident -> no duplicate
        fresh.append((metric, value, level))
    crit = [(m, v) for m, v, lvl in fresh if lvl == "critical"]
    ambulance = False
    if crit:
        last_call = db.scalar(
            select(Alert).where(Alert.user_id == patient.id, Alert.ambulance_called.is_(True),
                                Alert.ts > now - timedelta(seconds=settings.alert_cooldown_sec))
        )
        if not last_call:  # one SOS per incident, then cooldown
            summary = ", ".join(f"{m}={v:.1f}" for m, v in crit)
            ambulance = await _call_ambulance(db, patient, device, summary, crit[0][1])
        if patient.doctor_id:
            recent_msg = db.scalar(select(Message).where(
                Message.sender_id == patient.id, Message.receiver_id == patient.doctor_id,
                Message.kind == "alert", Message.created_at > window).limit(1))
            if not recent_msg:  # one message to the doctor per incident
                db.add(Message(sender_id=patient.id, receiver_id=patient.doctor_id, kind="alert",
                               body_enc=encrypt("CRITICAL: " + ", ".join(f"{m} = {v:.1f}" for m, v in crit))))
    for metric, value, level in fresh:
        alert = Alert(user_id=patient.id, metric=metric, value=value, level=level,
                      ambulance_called=ambulance and level == "critical",
                      lat=device.lat if device else None, lon=device.lon if device else None)
        db.add(alert)
        created.append(alert)
    db.commit()
    for a in created:
        msg = {"type": "alert", "patient_id": patient.id,
               "patient_name": f"{patient.first_name} {patient.last_name}",
               "data": {"id": a.id, "metric": a.metric, "value": a.value, "level": a.level,
                        "ambulance_called": a.ambulance_called, "ts": a.ts.isoformat()}}
        # только врачу! в канал пациента тревоги не публикуются
        if patient.doctor_id:
            await manager.publish(doctor_channel(patient.doctor_id), msg)
    return created
