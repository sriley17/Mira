"""
patients.py — АКТИВАЦИЯ ПАЦИЕНТА ПОСЛЕ ОДОБРЕНИЯ ВРАЧОМ
=====================================================
Когда врач нажимает «Одобрить», пациенту:
  1. выдаётся устройство MIRA (серийный номер + секретный ключ, ключ хранится зашифрованным);
  2. создаются стартовые цели (калории, сон, вода);
  3. (демо) генерируется история показателей за 30 дней, чтобы отчёты сразу были заполнены.
До одобрения ничего из этого не существует — pending-пациент не видит медицинских разделов.
"""
import secrets

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import Device, Goal, User
from ..security import encrypt
from .goals import default_goals
from .simulator import seed_history


def activate_patient(db: Session, patient: User, lat: float | None = None, lon: float | None = None,
                     battery: float = 100.0, with_history: bool = True) -> None:
    patient.status = "approved"
    if not patient.device:
        dev = Device(serial=f"MR-{patient.id:05d}", api_key_enc=encrypt(secrets.token_hex(16)), owner_id=patient.id,
                     battery=battery)
        if lat is not None:
            dev.lat, dev.lon = lat, lon
        db.add(dev)
    if not db.scalar(select(Goal.id).where(Goal.patient_id == patient.id).limit(1)):
        db.add_all(default_goals(patient.id))
    db.commit()
    db.refresh(patient)
    if with_history:
        seed_history(db, patient)
