"""
weather.py — ПОГОДА И УФ-ИНДЕКС ДЛЯ АНАЛИЗА СНА
==============================================
Сон зависит не только от организма: жаркая ночь, духота или сильное солнце днём
(УФ-индекс) влияют на качество сна и самочувствие. Поэтому анализ сна учитывает погоду.

Источник: Open-Meteo (https://open-meteo.com) — бесплатно, без ключа.
Приватность: отправляем ТОЛЬКО координаты, округлённые до 0.1° (~10 км — уровень района
города). Ни имени, ни id пациента, ни медицинских данных наружу не уходит.
Если WEATHER_ENABLED=false или интернета нет — используется встроенная оценка по
климатической норме Ташкента для текущего месяца (помечается source="climate").

Кэш: ответы запоминаются на 3 часа, чтобы не спрашивать одно и то же много раз.
"""
import logging
import time
from datetime import date

import httpx

from ..config import get_settings

log = logging.getLogger("mira.weather")
settings = get_settings()

CACHE_SEC = 3 * 3600
_cache: dict[tuple, tuple[float, dict]] = {}   # (lat, lon) -> (время записи, данные)
_fail_until = 0.0                               # после ошибки не пытаемся снова 10 минут

# Климатическая норма Ташкента по месяцам: (макс. дневная t°C, мин. ночная t°C, УФ-индекс макс.)
CLIMATE = {1: (7, -3, 2), 2: (10, -1, 3), 3: (16, 5, 5), 4: (23, 10, 7), 5: (29, 15, 9), 6: (34, 19, 10),
           7: (36, 21, 10), 8: (35, 19, 9), 9: (30, 13, 7), 10: (22, 7, 5), 11: (14, 2, 3), 12: (9, -1, 2)}


def uv_level(uv: float | None) -> str:
    """Шкала ВОЗ: low <3, moderate 3–5, high 6–7, very_high 8–10, extreme 11+."""
    if uv is None:
        return "unknown"
    if uv < 3:
        return "low"
    if uv < 6:
        return "moderate"
    if uv < 8:
        return "high"
    if uv < 11:
        return "very_high"
    return "extreme"


def _climate(day: date) -> dict:
    tmax, tmin, uv = CLIMATE[day.month]
    return {"source": "climate", "days": {day.isoformat(): {"t_max": tmax, "t_min": tmin, "uv_max": uv,
                                                              "uv_level": uv_level(uv)}}}


async def daily_weather(lat: float, lon: float, days_back: int = 7) -> dict:
    """Погода по дням: {"source": "open-meteo"|"climate", "days": {"2026-09-24": {...}}}."""
    global _fail_until
    key = (round(lat, 1), round(lon, 1), days_back)
    cached = _cache.get(key)
    if cached and time.time() - cached[0] < CACHE_SEC:
        return cached[1]
    if settings.weather_enabled and time.time() > _fail_until:
        params = {"latitude": key[0], "longitude": key[1], "timezone": settings.timezone,
                  "daily": "uv_index_max,temperature_2m_max,temperature_2m_min",
                  "past_days": days_back, "forecast_days": 1}
        try:
            async with httpx.AsyncClient(timeout=6) as client:
                r = await client.get("https://api.open-meteo.com/v1/forecast", params=params)
                r.raise_for_status()
                d = r.json()["daily"]
            out = {"source": "open-meteo", "days": {}}
            for i, day in enumerate(d["time"]):
                uv = d["uv_index_max"][i]
                out["days"][day] = {"t_max": d["temperature_2m_max"][i], "t_min": d["temperature_2m_min"][i],
                                    "uv_max": uv, "uv_level": uv_level(uv)}
            _cache[key] = (time.time(), out)
            return out
        except (httpx.HTTPError, KeyError, ValueError) as e:
            _fail_until = time.time() + 600
            log.info("Open-Meteo недоступен (%s) — используем климатическую норму", e)
    return _climate(date.today())


# Сезонная оценка качества воздуха в Ташкенте (US AQI): зимой из-за отопления воздух заметно хуже.
# Используется ТОЛЬКО если сервис недоступен, и помечается source="estimate".
SEASON_AQI = {1: 130, 2: 115, 3: 85, 4: 70, 5: 65, 6: 70, 7: 75, 8: 75, 9: 70, 10: 90, 11: 120, 12: 135}
_air_cache: dict[tuple, tuple[float, dict]] = {}
AIR_CACHE_SEC = 3600


def aqi_level(aqi: float | None) -> str:
    """Шкала US AQI: good ≤50, moderate ≤100, sensitive ≤150 (вредно для чувствительных), unhealthy >150."""
    if aqi is None:
        return "unknown"
    if aqi <= 50:
        return "good"
    if aqi <= 100:
        return "moderate"
    if aqi <= 150:
        return "sensitive"
    return "unhealthy"


async def current_conditions(lat: float, lon: float) -> dict:
    """Погода «сейчас» + качество воздуха — для совета «выходить ли на улицу и нужна ли маска».
    {"temp", "humidity", "wind", "uv", "aqi", "pm25", "aqi_level", "source"}"""
    global _fail_until
    key = (round(lat, 1), round(lon, 1))
    hit = _air_cache.get(key)
    if hit and time.time() - hit[0] < AIR_CACHE_SEC:
        return hit[1]
    if settings.weather_enabled and time.time() > _fail_until:
        try:
            async with httpx.AsyncClient(timeout=6) as client:
                w = await client.get("https://api.open-meteo.com/v1/forecast", params={
                    "latitude": key[0], "longitude": key[1], "timezone": settings.timezone,
                    "current": "temperature_2m,relative_humidity_2m,wind_speed_10m,uv_index"})
                a = await client.get("https://air-quality-api.open-meteo.com/v1/air-quality", params={
                    "latitude": key[0], "longitude": key[1], "current": "us_aqi,pm2_5"})
                w.raise_for_status()
                a.raise_for_status()
            cw, ca = w.json()["current"], a.json()["current"]
            out = {"temp": cw["temperature_2m"], "humidity": cw["relative_humidity_2m"], "wind": cw["wind_speed_10m"],
                   "uv": cw["uv_index"], "aqi": ca["us_aqi"], "pm25": ca["pm2_5"], "source": "open-meteo"}
            out["aqi_level"] = aqi_level(out["aqi"])
            _air_cache[key] = (time.time(), out)
            return out
        except (httpx.HTTPError, KeyError, ValueError) as e:
            _fail_until = time.time() + 600
            log.info("Погода/воздух недоступны (%s) — сезонная оценка", e)
    # запасной вариант: климатическая норма месяца и сезонная оценка воздуха
    from datetime import datetime
    now = datetime.now()
    tmax, tmin, uv = CLIMATE[now.month]
    hour = now.hour
    temp = tmin + (tmax - tmin) * max(0.0, 1 - abs(hour - 15) / 12)       # грубый суточный ход
    uv_now = round(uv * max(0.0, 1 - abs(hour - 13) / 6), 1)             # УФ максимален около 13:00
    aqi = SEASON_AQI[now.month]
    return {"temp": round(temp, 1), "humidity": None, "wind": None, "uv": uv_now, "aqi": aqi, "pm25": None,
            "aqi_level": aqi_level(aqi), "source": "estimate"}


def for_day(weather: dict, day: date) -> dict:
    """Погода за конкретный день; если такого дня нет — климатическая норма месяца."""
    return weather["days"].get(day.isoformat()) or _climate(day)["days"][day.isoformat()]
