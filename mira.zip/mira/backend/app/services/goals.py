"""
goals.py — ЗАДАЧИ И ЦЕЛИ ПАЦИЕНТА
================================
Цель = «что хочу достичь за день». Прогресс считается автоматически, где это возможно:

    calories — сумма калорий из измерений устройства за сегодняшний (местный) день;
    sleep    — длительность последней ночи из анализа сна (sleep.py).

По решению команды целей ровно ДВЕ — калории и сон. Обе считаются устройством автоматически,
пациенту ничего не нужно вводить вручную (воду, еду и т.п. не отслеживаем).

Результат для каждой цели: value (сколько сделано), pct (0–100), done (достигнута ли).
Эти же данные получает ИИ-ассистент, чтобы хвалить за выполненное и мягко подсказывать.
"""
from datetime import date, time, timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..models import Goal, Measurement, User, utcnow
from ..routers.measurements import load_frame
from .medications import _local_to_utc, _utc_to_local, local_today

KINDS = ("calories", "sleep")                # единственные виды целей
AUTO_KINDS = set(KINDS)                      # обе считаются устройством
UNITS = {"calories": "kcal", "sleep": "h"}
DEFAULT_TARGET = {"calories": 1800.0, "sleep": 7.5}


def calories_today(db: Session, patient_id: int) -> float:
    """Калории за сегодня по местному времени (сумма из таблицы measurements)."""
    start = _local_to_utc(local_today(), time(0, 0))
    total = db.scalar(select(func.sum(Measurement.calories)).where(Measurement.user_id == patient_id,
                                                                   Measurement.ts >= start))
    return round(float(total or 0), 0)


def progress(db: Session, patient: User, sleep_hours: float | None = None) -> list[dict]:
    """Все активные цели с прогрессом. sleep_hours передаёт роутер (из анализа сна)."""
    kcal = None
    out = []
    for g in db.scalars(select(Goal).where(Goal.patient_id == patient.id, Goal.active.is_(True),
                                           Goal.kind.in_(KINDS)).order_by(Goal.kind)):
        if g.kind == "calories":
            kcal = calories_today(db, patient.id) if kcal is None else kcal
            value = kcal
        else:
            value = round(sleep_hours or 0, 1)
        pct = min(100, round(value / g.target * 100)) if g.target else 0
        out.append({"id": g.id, "kind": g.kind, "title": g.title, "target": g.target, "unit": g.unit,
                    "value": value, "pct": pct, "done": pct >= 100, "auto": g.kind in AUTO_KINDS})
    return out


def set_target(db: Session, patient_id: int, kind: str, target: float) -> Goal:
    """Задать цель (одна на вид): если уже есть — меняем число, если нет — создаём."""
    g = db.scalar(select(Goal).where(Goal.patient_id == patient_id, Goal.kind == kind, Goal.active.is_(True)))
    if not g:
        g = Goal(patient_id=patient_id, kind=kind, title="", unit=UNITS[kind], target=target)
        db.add(g)
    g.target = target
    db.commit()
    return g


def history(db: Session, patient: User, nights: list[dict], days: int = 7) -> list[dict]:
    """Выполнение целей по дням: калории за местные сутки и сон за ночь, для графика «неделя»."""
    targets = {g.kind: g.target for g in db.scalars(select(Goal).where(Goal.patient_id == patient.id,
                                                                     Goal.active.is_(True)))}
    today = local_today()
    start = _local_to_utc(today - timedelta(days=days - 1), time(0, 0))
    df = load_frame(patient.id, start, utcnow())
    kcal = {}
    if not df.empty:
        df["d"] = df["ts"].map(lambda t: _utc_to_local(t.to_pydatetime()).date())
        kcal = df.groupby("d")["calories"].sum().to_dict()
    # сон «за ночь с D на D+1» относим к утру D+1 — так человек и думает: «сегодня я спал…»
    sleep = {}
    for n in nights:
        if n.get("detected"):
            sleep[date.fromisoformat(n["date"]) + timedelta(days=1)] = n["hours"]
    out = []
    for i in range(days - 1, -1, -1):
        d = today - timedelta(days=i)
        out.append({"date": d.isoformat(), "calories": round(float(kcal.get(d, 0))),
                    "calories_target": targets.get("calories"), "sleep": sleep.get(d),
                    "sleep_target": targets.get("sleep")})
    return out


def default_goals(patient_id: int) -> list[Goal]:
    """Стартовые цели нового пациента: калории и сон (врач или пациент может поменять числа)."""
    return [Goal(patient_id=patient_id, kind=k, title="", target=DEFAULT_TARGET[k], unit=UNITS[k]) for k in KINDS]
