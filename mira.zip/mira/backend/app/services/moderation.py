"""
moderation.py — «ЦЕНЗУРА» ДЛЯ ИИ-АССИСТЕНТА
==========================================
ТЗ: пациенты не должны использовать ИИ для чего угодно. Каждое сообщение пациента ПЕРЕД
ответом проходит проверку. Если запрос попадает в запрещённую категорию — ИИ не выполняет его,
а отвечает спокойным отказом и подсказывает, куда обратиться.

Категории (правила — корни слов на RU / UZ / EN, текст приводится к нижнему регистру):
  self_harm   — мысли о причинении себе вреда -> бережный ответ, совет срочно связаться
                с близким человеком и врачом, при опасности — 103. НЕ обычный отказ.
  overdose    — превышение доз, «сколько таблеток чтобы…», смешивание препаратов
  dosing      — «назначь / отмени / увеличь дозу» — это решает только врач
  jailbreak   — попытки сломать правила ИИ: «игнорируй инструкции», «ты теперь…», «system prompt»
  others_data — запросы чужих данных: «покажи данные другого пациента», пароли, ПИНФЛ
  weapons     — оружие, взрывчатка, яды
  sexual      — откровенный контент
  abuse       — грубые оскорбления (мат)
  offtopic    — домашние задания, код, политика и т.п.: ИИ MIRA только про здоровье и реабилитацию

Дополнительно: ограничение частоты — не более 20 сообщений за 5 минут (защита от спама и перебора).
Каждое срабатывание пишется в журнал аудита (без текста сообщения — только категория).
"""
import re
import time
from collections import defaultdict, deque

RULES: dict[str, list[str]] = {
    "self_harm": ["покончить с собой", "суицид", "убить себя", "не хочу жить", "порезать себя", "свести счеты",
                  "o'zimni o'ldir", "yashashni xohlamayman", "o'z joniga qasd", "kill myself", "suicide",
                  "end my life", "hurt myself", "self harm", "self-harm"],
    "overdose": ["передозир", "смертельн доз", "сколько таблеток чтобы", "выпить все таблетки", "летальн",
                 "смешать с алкогол", "o'ldiradigan doza", "hamma tabletkani", "overdose", "lethal dose",
                 "how many pills to"],
    "dosing": ["назначь мне", "назначь лекарств", "увеличь дозу", "увеличить дозу", "уменьшить дозу", "отменить лекарств",
               "бросить антибиот", "перестать пить таблет", "dozani oshir", "dorini to'xtat", "dori yozib ber",
               "prescribe me", "increase my dose", "stop taking my", "change my dose"],
    "jailbreak": ["игнорируй", "забудь инструкц", "забудь все правила", "system prompt", "системный промпт",
                  "ты теперь", "притворись", "режим разработчика", "developer mode", "ignore previous",
                  "ignore all", "ignore your", "you are now", "pretend to be", "jailbreak", "dan mode",
                  "ko'rsatmalarni unut", "qoidalarni unut"],
    "others_data": ["другого пациента", "чужие данные", "данные всех пациентов", "пароль врача", "пинфл другого",
                    "boshqa bemor", "hamma bemorlar", "another patient", "other patients", "doctor's password",
                    "all patients data"],
    "weapons": ["взрывчат", "бомб", "оружи", "яд для", "отравить", "portlovchi", "qurol", "zahar",
                "explosive", "bomb", "weapon", "poison someone"],
    "sexual": ["порно", "секс с", "эроти", "porn", "nude", "sexting"],
    "abuse": ["сука", "блять", "бля ", "нахуй", "пидор", "ебан", "дебил", "идиот", "fuck", "bitch", "asshole",
              "jalab", "qanjiq"],
    "offtopic": ["домашнее задание", "реши задачу", "напиши код", "напиши сочинение", "курс доллара", "выборы",
                 "президент", "ставки на спорт", "криптовалют", "uy vazifasi", "kod yoz", "homework", "write code",
                 "write an essay", "bitcoin", "election", "betting"],
}

REPLY = {
    "ru": {
        "self_harm": "Мне очень жаль, что вам сейчас так тяжело. Вы не одни. Пожалуйста, прямо сейчас свяжитесь "
                     "с близким человеком и напишите вашему врачу в разделе «Мой врач». Если есть угроза жизни — "
                     "звоните 103. Я рядом, если хотите просто поговорить о самочувствии.",
        "default": "Я не могу помочь с этим запросом. Я — медицинский ассистент MIRA и отвечаю только на вопросы "
                   "о вашем здоровье, показателях, сне, лекарствах по расписанию и реабилитации.",
        "dosing": "Назначать, отменять и менять дозы лекарств может только ваш врач — это важно для безопасности. "
                  "Напишите ему в разделе «Мой врач», а я могу рассказать, как не пропускать приёмы.",
        "overdose": "Я не могу давать такую информацию. Если вы приняли лишние таблетки или вам плохо — сразу "
                    "звоните 103 и сообщите врачу.",
        "rate": "Слишком много сообщений подряд. Сделайте небольшую паузу и напишите снова через пару минут.",
    },
    "uz": {
        "self_harm": "Hozir sizga og'ir ekanidan juda afsusdaman. Siz yolg'iz emassiz. Iltimos, hoziroq yaqin "
                     "insoningiz bilan bog'laning va «Mening shifokorim» bo'limida shifokorga yozing. Hayotga xavf "
                     "bo'lsa — 103 ga qo'ng'iroq qiling. Holatingiz haqida gaplashmoqchi bo'lsangiz, men shu yerdaman.",
        "default": "Bu so'rov bo'yicha yordam bera olmayman. Men MIRA tibbiy yordamchisiman va faqat sog'lig'ingiz, "
                   "ko'rsatkichlar, uyqu, dori jadvali va reabilitatsiya haqidagi savollarga javob beraman.",
        "dosing": "Dorilarni tayinlash, bekor qilish va dozani o'zgartirish faqat shifokoringizning ishi — bu xavfsizlik "
                  "uchun muhim. Unga «Mening shifokorim» bo'limida yozing.",
        "overdose": "Bunday ma'lumot bera olmayman. Ortiqcha dori ichgan bo'lsangiz yoki o'zingizni yomon his "
                    "qilsangiz — darhol 103 ga qo'ng'iroq qiling va shifokorga xabar bering.",
        "rate": "Juda ko'p xabar ketma-ket. Biroz tanaffus qiling va bir-ikki daqiqadan keyin yozing.",
    },
    "en": {
        "self_harm": "I'm really sorry you're going through this. You are not alone. Please reach out to someone "
                     "close to you right now and message your doctor in “My doctor”. If your life is in danger, call "
                     "emergency services. I'm here if you'd like to talk about how you feel.",
        "default": "I can't help with that request. I'm the MIRA medical assistant and only answer questions about "
                   "your health, readings, sleep, medication schedule and rehabilitation.",
        "dosing": "Only your doctor can prescribe, stop or change medicine doses — this matters for your safety. "
                  "Message them in “My doctor”.",
        "overdose": "I can't provide that information. If you took extra pills or feel unwell, call emergency "
                    "services right away and tell your doctor.",
        "rate": "Too many messages in a row. Please take a short break and write again in a couple of minutes.",
    },
}

RATE_N, RATE_WINDOW = 20, 300
_hits: dict[int, deque] = defaultdict(deque)


def _norm(text: str) -> str:
    return " " + re.sub(r"\s+", " ", text.lower().replace("ё", "е")).strip() + " "


def check(text: str) -> str | None:
    """Категория нарушения или None, если запрос допустим. self_harm проверяется первым."""
    t = _norm(text)
    for cat, words in RULES.items():
        if any(w in t for w in words):
            return cat
    return None


def rate_limited(user_id: int) -> bool:
    now = time.monotonic()
    q = _hits[user_id]
    while q and now - q[0] > RATE_WINDOW:
        q.popleft()
    if len(q) >= RATE_N:
        return True
    q.append(now)
    return False


def reply(category: str, lang: str) -> str:
    R = REPLY[lang]
    return R.get(category, R["default"])
