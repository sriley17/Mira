"""Clinical statistics for the doctor's AI analyst.
Everything is computed from the stored measurements: last value, 24 h / 7 d / 30 d averages, min/max,
variability, time in range (TIR), trend, day/night blood-pressure pattern, alerts, data completeness
and a simple risk score used to rank patients."""
from datetime import timedelta
from zoneinfo import ZoneInfo

import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..models import Alert, User, utcnow
from ..routers.measurements import load_frame

settings = get_settings()
METRICS = ["heart_rate", "systolic", "diastolic", "glucose", "resp_rate", "spo2", "body_temp", "room_temp"]
NORMAL = {"heart_rate": (60, 100), "systolic": (90, 140), "diastolic": (60, 90), "glucose": (3.9, 7.8),
          "resp_rate": (12, 20), "spo2": (95, 100), "body_temp": (36.1, 37.2), "room_temp": (20, 25)}
TREND_THR = {"heart_rate": 0.08, "systolic": 0.07, "diastolic": 0.07, "glucose": 0.10, "resp_rate": 0.12,
             "spo2": 0.02, "body_temp": 0.012, "room_temp": 0.08}


DIGITS = {"heart_rate": 0, "systolic": 0, "diastolic": 0, "glucose": 1, "resp_rate": 0, "spo2": 0,
          "body_temp": 1, "room_temp": 1}


def _r(v, d=1):
    if v is None or pd.isna(v):
        return None
    return int(round(float(v))) if d == 0 else round(float(v), d)


def patient_stats(db: Session, patient: User) -> dict:
    now = utcnow()
    df30 = load_frame(patient.id, now - timedelta(days=30), now)
    out = {"id": patient.id, "name": f"{patient.first_name} {patient.last_name}", "age": patient.age,
           "gender": patient.gender, "n_30d": len(df30), "metrics": {}, "flags": []}
    if df30.empty:
        return out
    df7 = df30[df30["ts"] >= now - timedelta(days=7)]
    df1 = df30[df30["ts"] >= now - timedelta(days=1)]
    last = df30.iloc[-1]
    out["last_ts"] = last["ts"].isoformat()

    for m in METRICS:
        s7, s1, s30 = df7[m].dropna(), df1[m].dropna(), df30[m].dropna()
        lo, hi = NORMAL[m]
        d = DIGITS[m]
        st = {"last": _r(last[m], d), "avg24": _r(s1.mean(), d), "avg7": _r(s7.mean(), d), "avg30": _r(s30.mean(), d),
              "min7": _r(s7.min(), d), "max7": _r(s7.max(), d), "sd7": _r(s7.std(), 1),
              "tir7": _r(((s7 >= lo) & (s7 <= hi)).mean() * 100, 0) if len(s7) else None,
              "below7": int((s7 < lo).sum()), "above7": int((s7 > hi).sum())}
        if len(s1) and len(s7):
            ch = (s1.mean() - s7.mean()) / s7.mean()
            st["trend_pct"] = _r(ch * 100, 0)
            st["trend"] = "up" if ch >= TREND_THR[m] else "down" if ch <= -TREND_THR[m] else "stable"
        out["metrics"][m] = st

    g = out["metrics"]["glucose"]
    if g["avg7"]:
        g["cv7"] = _r(df7["glucose"].std() / df7["glucose"].mean() * 100, 0)

    # day / night blood pressure (local time): normal nocturnal dip is 10–20 %
    tz = ZoneInfo(settings.timezone)
    loc = df7.assign(h=df7["ts"].dt.tz_localize("UTC").dt.tz_convert(tz).dt.hour)
    day_bp = loc[(loc.h >= 9) & (loc.h < 21)]["systolic"].mean()
    night_bp = loc[(loc.h >= 0) & (loc.h < 6)]["systolic"].mean()
    if not pd.isna(day_bp) and not pd.isna(night_bp):
        dip = (day_bp - night_bp) / day_bp * 100
        out["bp_dip"] = {"day": _r(day_bp, 0), "night": _r(night_bp, 0), "dip_pct": _r(dip, 0),
                         "type": "dipper" if 10 <= dip <= 20 else "non_dipper" if dip < 10 else "extreme"}

    # alerts over 7 days
    alerts = db.scalars(select(Alert).where(Alert.user_id == patient.id, Alert.ts > now - timedelta(days=7))
                        .order_by(Alert.ts.desc())).all()
    by = {}
    for a in alerts:
        k = (a.metric, a.level)
        by[k] = by.get(k, 0) + 1
    out["alerts7"] = [{"metric": m, "level": lvl, "count": c} for (m, lvl), c in sorted(by.items(), key=lambda x: -x[1])]
    out["alerts_crit7"] = sum(c for (m, lvl), c in by.items() if lvl == "critical")
    out["ambulance7"] = sum(1 for a in alerts if a.ambulance_called)
    if alerts:
        out["last_alert"] = {"metric": alerts[0].metric, "level": alerts[0].level, "value": _r(alerts[0].value),
                             "ts": alerts[0].ts.isoformat()}

    # data completeness: hours of the last 24 h that have at least one reading
    hours = df1["ts"].dt.floor("h").nunique()
    out["coverage24"] = int(min(100, hours / 24 * 100))
    d = patient.device
    if d:
        out["device"] = {"battery": _r(d.battery, 0), "online": (now - d.last_seen).total_seconds() < 60}

    out["flags"] = _flags(out)
    out["risk"] = _risk(out)
    return out


def _flags(s: dict) -> list[str]:
    """Machine-readable findings; texts are produced in doctor_ai.py."""
    m, f = s["metrics"], []
    sys7, dia7 = m["systolic"]["avg7"], m["diastolic"]["avg7"]
    if sys7 and dia7 and (sys7 >= 135 or dia7 >= 85):
        f.append("home_bp_high")
    if m["systolic"]["max7"] and m["systolic"]["max7"] >= 180:
        f.append("bp_crisis_episode")
    if s.get("bp_dip", {}).get("type") == "non_dipper":
        f.append("non_dipper")
    if m["systolic"].get("trend") == "up":
        f.append("bp_trend_up")
    hr = m["heart_rate"]
    if hr["avg7"] and hr["avg7"] > 100:
        f.append("tachycardia")
    elif hr["avg7"] and hr["avg7"] < 55:
        f.append("bradycardia")
    if hr["max7"] and hr["max7"] >= 140:
        f.append("hr_spikes")
    g = m["glucose"]
    if g["avg7"] and (g["avg7"] > 7.0 or (g["tir7"] is not None and g["tir7"] < 70)):
        f.append("glucose_control")
    if g["below7"]:
        f.append("hypoglycemia")
    if g.get("cv7") and g["cv7"] > 36:
        f.append("glucose_variability")
    if m["spo2"]["min7"] and m["spo2"]["min7"] < 92:
        f.append("desaturation")
    if m["body_temp"]["avg24"] and m["body_temp"]["avg24"] > 37.5:
        f.append("fever")
    if m["resp_rate"]["avg7"] and m["resp_rate"]["avg7"] > 22:
        f.append("tachypnea")
    if s.get("coverage24", 100) < 60:
        f.append("low_coverage")
    if s.get("device") and (s["device"]["battery"] < 20 or not s["device"]["online"]):
        f.append("device_issue")
    return f


WEIGHTS = {"bp_crisis_episode": 4, "desaturation": 4, "hypoglycemia": 3, "home_bp_high": 2, "tachycardia": 2,
           "hr_spikes": 2, "glucose_control": 2, "fever": 2, "tachypnea": 2, "non_dipper": 1, "bp_trend_up": 1,
           "bradycardia": 1, "glucose_variability": 1, "low_coverage": 0, "device_issue": 0}


def _risk(s: dict) -> int:
    score = sum(WEIGHTS.get(f, 0) for f in s["flags"]) + min(6, s.get("alerts_crit7", 0))
    return int(score)


def cohort(db: Session, doctor: User) -> list[dict]:
    pts = db.scalars(select(User).where(User.doctor_id == doctor.id)).all()
    rows = [patient_stats(db, p) for p in pts]
    return sorted(rows, key=lambda r: -r.get("risk", 0))
