"""
dmed.py — ИНТЕГРАЦИЯ С DMED (расширенная медицинская карта)
==========================================================
DMED — национальная электронная система здравоохранения Узбекистана. В ней хранятся
диагнозы, аллергии, прививки, результаты анализов и визиты пациента.

Доступ к реальному API выдаётся Минздравом по договору (у каждой клиники свои ключи
и спецификация), поэтому здесь сделан АДАПТЕР — единая точка, через которую MIRA получает данные:

    DmedClient.fetch_record(pinfl) -> dict в едином формате MIRA

Режимы:
  • DMED_BASE_URL и DMED_TOKEN заданы → реальный запрос GET {base}/patients/{pinfl}/record
    (путь и поля поправьте под официальную спецификацию — достаточно изменить _map_response);
  • не заданы → ДЕМО-режим: детерминированные тестовые данные с пометкой source="demo".
    Так на защите видно, как выглядит медкарта, и никто не спутает её с настоящей.

Безопасность:
  • идентификатор пациента — ПИНФЛ — хранится в базе зашифрованным (users.pinfl_enc);
  • запрос в Dmed может сделать только лечащий врач пациента (проверка в роутере),
    каждый просмотр пишется в журнал аудита.
"""
import logging
import random

import httpx

from ..config import get_settings

log = logging.getLogger("mira.dmed")
settings = get_settings()


class DmedError(Exception):
    """Ошибка связи с Dmed — роутер превратит её в понятный ответ 502."""


def _map_response(raw: dict) -> dict:
    """Перевод ответа Dmed в формат MIRA. Здесь единственное место, зависящее от их полей."""
    return {
        "source": "dmed",
        "blood_type": raw.get("bloodType"),
        "allergies": raw.get("allergies", []),
        "chronic": [d.get("name") for d in raw.get("diagnoses", []) if d.get("chronic")],
        "diagnoses": [{"code": d.get("icd10"), "name": d.get("name"), "date": d.get("date")}
                      for d in raw.get("diagnoses", [])],
        "vaccinations": raw.get("vaccinations", []),
        "labs": raw.get("labs", []),
        "visits": raw.get("visits", []),
    }


def _demo_record(patient_id: int, age: int, gender: str) -> dict:
    """Тестовая медкарта. random.Random(patient_id) — у каждого пациента своя, но всегда одинаковая."""
    rng = random.Random(patient_id * 31)
    diag_pool = [("I10", "Эссенциальная гипертензия"), ("E11.9", "Сахарный диабет 2 типа"),
                 ("J45.9", "Бронхиальная астма"), ("M54.5", "Боль внизу спины"),
                 ("I25.1", "ИБС, атеросклеротическая болезнь сердца"), ("E78.0", "Гиперхолестеринемия")]
    diags = rng.sample(diag_pool, k=2 if age > 50 else 1)
    labs = [
        {"name": "HbA1c", "value": round(rng.uniform(5.2, 8.4), 1), "unit": "%", "ref": "4.0–6.0"},
        {"name": "Холестерин общий", "value": round(rng.uniform(4.0, 6.8), 1), "unit": "ммоль/л", "ref": "< 5.2"},
        {"name": "Креатинин", "value": rng.randint(60, 115), "unit": "мкмоль/л",
         "ref": "53–97" if gender == "female" else "62–115"},
        {"name": "Гемоглобин", "value": rng.randint(115, 160), "unit": "г/л",
         "ref": "120–150" if gender == "female" else "130–170"},
    ]
    return {
        "source": "demo",
        "blood_type": rng.choice(["O(I) Rh+", "A(II) Rh+", "B(III) Rh+", "AB(IV) Rh+", "A(II) Rh-"]),
        "allergies": rng.sample(["Пенициллин", "Аспирин", "Пыльца", "Орехи"], k=rng.randint(0, 2)),
        "chronic": [d[1] for d in diags],
        "diagnoses": [{"code": c, "name": n, "date": f"20{rng.randint(15, 25)}-0{rng.randint(1, 9)}-1{rng.randint(0, 9)}"}
                      for c, n in diags],
        "vaccinations": [{"name": "COVID-19", "date": "2022-03-14"}, {"name": "Грипп", "date": "2025-10-02"}],
        "labs": [{**lab, "date": "2026-08-20"} for lab in labs],
        "visits": [{"date": "2026-08-20", "clinic": "Семейная поликлиника №12", "doctor": "Терапевт"},
                   {"date": "2026-05-11", "clinic": "Республиканский кардиоцентр", "doctor": "Кардиолог"}],
    }


class DmedClient:
    def __init__(self) -> None:
        self.base = settings.dmed_base_url.rstrip("/")
        self.token = settings.dmed_token

    @property
    def demo(self) -> bool:
        return not (self.base and self.token)

    async def fetch_record(self, pinfl: str | None, patient_id: int, age: int, gender: str) -> dict:
        if self.demo:
            return _demo_record(patient_id, age, gender)
        if not pinfl:
            raise DmedError("PINFL is not set for this patient")
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                r = await client.get(f"{self.base}/patients/{pinfl}/record",
                                     headers={"Authorization": f"Bearer {self.token}"})
            r.raise_for_status()
            return _map_response(r.json())
        except httpx.HTTPError as e:
            log.error("Dmed request failed: %s", e)   # ПИНФЛ в лог не пишем
            raise DmedError("Dmed is unavailable") from e


dmed = DmedClient()
