"""
appointments.py — ЗАПИСЬ К ВРАЧУ
===============================
Правила (легко поменять в константах ниже):
  • врач принимает с понедельника по пятницу, 09:00–17:00 (местное время), обед 13:00–14:00;
  • один приём = 30 минут;
  • записаться можно не раньше чем через 1 час и не позже чем через 30 дней.

Сценарий:
  1. Пациент выбирает время → статус "requested".
     Если время занято или нерабочее, API сразу отвечает 409 и присылает 3 ближайших свободных слота.
  2. Врач одобряет ("approved") или отклоняет ("declined").
     При отклонении система АВТОМАТИЧЕСКИ подбирает свободные слоты и пишет их пациенту
     в «Ответы врача» — пациенту остаётся выбрать удобное время.
"""
from datetime import date, datetime, time, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import Appointment, utcnow
from .medications import _local_to_utc, _utc_to_local, local_today

WORK_DAYS = {0, 1, 2, 3, 4}                   # пн–пт (0 = понедельник)
WORK_START, WORK_END = time(9, 0), time(17, 0)
LUNCH = (time(13, 0), time(14, 0))
SLOT_MIN = 30
MIN_LEAD = timedelta(hours=1)
MAX_AHEAD_DAYS = 30
BUSY = ("requested", "approved")             # эти статусы занимают время врача


def day_slots(d: date) -> list[time]:
    """Все рабочие слоты дня (без учёта занятости)."""
    if d.weekday() not in WORK_DAYS:
        return []
    out, cur = [], datetime.combine(d, WORK_START)
    end = datetime.combine(d, WORK_END)
    while cur + timedelta(minutes=SLOT_MIN) <= end:
        if not (LUNCH[0] <= cur.time() < LUNCH[1]):
            out.append(cur.time())
        cur += timedelta(minutes=SLOT_MIN)
    return out


def _busy(db: Session, doctor_id: int, start: datetime, end: datetime) -> set[datetime]:
    rows = db.scalars(select(Appointment.start).where(Appointment.doctor_id == doctor_id,
                                                      Appointment.status.in_(BUSY),
                                                      Appointment.start >= start, Appointment.start < end))
    return set(rows)


def free_slots(db: Session, doctor_id: int, d: date) -> list[dict]:
    """Свободные слоты на день: [{"start": UTC iso, "local": "10:30"}]."""
    earliest = utcnow() + MIN_LEAD
    day_start = _local_to_utc(d, time(0, 0))
    busy = _busy(db, doctor_id, day_start, day_start + timedelta(days=1))
    out = []
    for t in day_slots(d):
        utc = _local_to_utc(d, t)
        if utc >= earliest and utc not in busy:
            out.append({"start": utc.isoformat(), "local": t.strftime("%H:%M"), "date": d.isoformat()})
    return out


def suggest(db: Session, doctor_id: int, near_utc: datetime | None = None, n: int = 3) -> list[dict]:
    """n ближайших свободных слотов начиная с дня near_utc (или с сегодняшнего)."""
    d = _utc_to_local(near_utc).date() if near_utc else local_today()
    d = max(d, local_today())
    out: list[dict] = []
    for _ in range(MAX_AHEAD_DAYS):
        out += free_slots(db, doctor_id, d)
        if len(out) >= n:
            break
        d += timedelta(days=1)
    return out[:n]


def validate_slot(db: Session, doctor_id: int, start_utc: datetime) -> str | None:
    """None — слот можно бронировать; иначе код причины (для понятного сообщения на фронтенде)."""
    loc = _utc_to_local(start_utc)
    if start_utc < utcnow() + MIN_LEAD:
        return "too_soon"
    if loc.date() > local_today() + timedelta(days=MAX_AHEAD_DAYS):
        return "too_far"
    if loc.time() not in day_slots(loc.date()):
        return "off_hours"
    if start_utc in _busy(db, doctor_id, start_utc, start_utc + timedelta(minutes=1)):
        return "busy"
    return None
