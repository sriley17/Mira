"""
demo.py — ДЕМО-ДАННЫЕ ДЛЯ ПОКАЗА
===============================
Создаются один раз при первом запуске (если база пустая и DEMO_SEED=true):

  врач      doctor@mira.uz / doctor123
  пациенты  patient@mira.uz, aziz@mira.uz, nodira@mira.uz / patient123   (одобрены, есть история)
  заявка    kamola@mira.uz / patient123   (ждёт одобрения — чтобы показать этот сценарий)

Плюс: назначенные лекарства (у одного — антибиотик) с историей приёма за неделю,
заявка на приём, рекомендация врача.
"""
import json
import logging
import random
from datetime import datetime, timedelta

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..models import Appointment, Medication, MedicationIntake, Message, User, utcnow
from ..security import encrypt, hash_password
from .appointments import suggest
from .medications import doses_for_day, local_today
from .patients import activate_patient

log = logging.getLogger("mira.demo")

PATIENTS = [  # email, имя, фамилия, возраст, пол, lat, lon, телефон, ПИНФЛ
    ("patient@mira.uz", "Дилноза", "Юсупова", 62, "female", 41.3111, 69.2797, "+998901234560", "31505620120011"),
    ("aziz@mira.uz", "Азиз", "Рахимов", 54, "male", 41.3275, 69.2817, "+998901234561", "30208720140022"),
    ("nodira@mira.uz", "Нодира", "Саидова", 71, "female", 41.2995, 69.2401, "+998901234562", "41112550170033"),
]

# Анкеты демо-пациентов (вымышленные данные; хранятся зашифрованными в users.profile_enc)
PROFILES = [
    {"middle_name": "Рустамовна", "birth_date": "1964-03-15", "city": "Ташкент",
     "address": "Юнусабадский р-н, 4-й квартал", "workplace": "На пенсии (бывший преподаватель школы)",
     "position": "Пенсионер", "emergency_name": "Юсупов Бахтиёр (сын)", "emergency_phone": "+998901110001"},
    {"middle_name": "Шухратович", "birth_date": "1972-07-02", "city": "Ташкент",
     "address": "Мирзо-Улугбекский р-н, ул. Буюк Ипак Йули", "workplace": "Строительная компания",
     "position": "Инженер-прораб", "emergency_name": "Рахимова Малика (жена)", "emergency_phone": "+998901110002"},
    {"middle_name": "Алимовна", "birth_date": "1955-11-20", "city": "Ташкент",
     "address": "Чиланзарский р-н, 9-й квартал", "workplace": "На пенсии", "position": "Пенсионер",
     "emergency_name": "Саидов Жасур (сын)", "emergency_phone": "+998901110003"},
]
DOCTOR_PROFILE = {"specialty": "Кардиолог-реабилитолог", "clinic": "Центр реабилитации MIRA (демо)",
                  "room": "214", "experience_years": 18, "hours": "Пн–Пт 09:00–17:00"}

MEDS = [  # для каждого демо-пациента: (название, доза, время, антибиотик, дней курса, заметка)
    [("Лизиноприл", "10 мг", "08:00", False, None, "утром натощак"),
     ("Аторвастатин", "20 мг", "21:00", False, None, None)],
    [("Амлодипин", "5 мг", "08:00,20:00", False, None, None),
     ("Амоксициллин", "500 мг", "08:00,14:00,20:00", True, 7, "после еды")],
    [("Метформин", "850 мг", "08:00,20:00", False, None, "во время еды")],
]


def _seed_intakes(db: Session, med: Medication, rng: random.Random, days: int = 7) -> None:
    """История приёма: ~85 % доз отмечены «принято» — чтобы у врача была видна статистика соблюдения."""
    today = local_today()
    for i in range(1, days + 1):
        for sched in doses_for_day(med, today - timedelta(days=i)):
            taken = rng.random() < 0.85
            db.add(MedicationIntake(medication_id=med.id, patient_id=med.patient_id, scheduled_at=sched,
                                    reminded_at=sched, sms_status="demo",
                                    taken_at=sched + timedelta(minutes=rng.randint(2, 40)) if taken else None))


def seed_demo(db: Session) -> None:
    if db.scalar(select(func.count(User.id))):
        return  # база не пустая — ничего не делаем
    doc = User(email="doctor@mira.uz", password_hash=hash_password("doctor123"), first_name="Алишер",
               last_name="Каримов", age=45, gender="male", role="doctor", status="approved",
               identity_status="verified", identity_source="demo", consent_at=utcnow(), consent_version="2026-09",
               profile_enc=encrypt(json.dumps(DOCTOR_PROFILE, ensure_ascii=False)))
    db.add(doc)
    db.commit()
    rng = random.Random(42)
    for i, (email, fn, ln, age, g, lat, lon, phone, pinfl) in enumerate(PATIENTS):
        p = User(email=email, password_hash=hash_password("patient123"), first_name=fn, last_name=ln, age=age,
                 gender=g, role="patient", doctor_id=doc.id, status="pending",
                 identity_status="verified", identity_source="demo", consent_at=utcnow(), consent_version="2026-09",
                 phone_enc=encrypt(phone), pinfl_enc=encrypt(pinfl),
                 profile_enc=encrypt(json.dumps(PROFILES[i], ensure_ascii=False)))
        db.add(p)
        db.commit()
        activate_patient(db, p, lat=lat, lon=lon, battery=100 - i * 25)
        db.add(Message(sender_id=doc.id, receiver_id=p.id, kind="recommendation",
                       body_enc=encrypt("Измеряйте давление утром и вечером, ограничьте соль. "
                                        "Принимайте препараты по расписанию — MIRA напомнит по SMS.")))
        start = local_today() - timedelta(days=10)
        for name, dose, times, abx, course, note in MEDS[i]:
            m = Medication(patient_id=p.id, created_by=doc.id, name=name, dose=dose, times=times,
                           start_date=start if not abx else local_today() - timedelta(days=3),
                           end_date=(local_today() + timedelta(days=course - 4)) if abx else None,
                           is_antibiotic=abx, notes_enc=encrypt(note) if note else None)
            db.add(m)
            db.commit()
            _seed_intakes(db, m, rng, 7 if not abx else 3)
        db.commit()

    # пациентка, ожидающая одобрения врача
    db.add(User(email="kamola@mira.uz", password_hash=hash_password("patient123"), first_name="Камола",
                last_name="Турсунова", age=38, gender="female", role="patient", doctor_id=doc.id, status="pending",
                phone_enc=encrypt("+998901234563")))
    # заявка на приём от первого пациента на ближайшее свободное время
    first = db.scalar(select(User).where(User.email == "patient@mira.uz"))
    slot = suggest(db, doc.id, n=1)
    if slot:
        db.add(Appointment(patient_id=first.id, doctor_id=doc.id, start=datetime.fromisoformat(slot[0]["start"]),
                           reason_enc=encrypt("Плановый контроль давления")))
    db.commit()
    log.info("Demo data created: doctor@mira.uz / doctor123, patient@mira.uz / patient123, "
             "pending: kamola@mira.uz")

