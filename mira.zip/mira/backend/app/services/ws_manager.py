"""In-process WebSocket pub/sub. For horizontal scaling swap for Redis pub/sub (same interface)."""
import asyncio
import json
from collections import defaultdict

from fastapi import WebSocket


class ConnectionManager:
    def __init__(self) -> None:
        self.channels: dict[str, set[WebSocket]] = defaultdict(set)
        self.lock = asyncio.Lock()

    async def subscribe(self, channel: str, ws: WebSocket) -> None:
        async with self.lock:
            self.channels[channel].add(ws)

    async def unsubscribe(self, ws: WebSocket) -> None:
        async with self.lock:
            for subs in self.channels.values():
                subs.discard(ws)

    async def publish(self, channel: str, message: dict) -> None:
        subs = list(self.channels.get(channel, ()))
        if not subs:
            return
        text = json.dumps(message, default=str)
        dead = []
        for ws in subs:
            try:
                await ws.send_text(text)
            except Exception:
                dead.append(ws)
        for ws in dead:
            await self.unsubscribe(ws)


manager = ConnectionManager()


def patient_channel(patient_id: int) -> str:
    return f"patient:{patient_id}"


def doctor_channel(doctor_id: int) -> str:
    return f"doctor:{doctor_id}"
