"""Personal tips built from the patient's own analysis:
latest reading + 24 h average + 7-day average (trend). Cards are sorted by importance and
the advice inside each card is picked at random from the knowledge base, so the page changes
together with the readings and doesn't repeat itself."""
import random

from .ai import NORMAL, _state
from .ai_kb import METRIC_INFO, PHRASES, TOPIC_TITLES, TOPICS

GROUPS = {  # topic -> metrics it covers
    "pressure": ["systolic", "diastolic"],
    "pulse": ["heart_rate"],
    "sugar": ["glucose"],
    "breathing": ["spo2", "resp_rate"],
    "fever": ["body_temp"],
    "room": ["room_temp"],
}
TREND = {"systolic": 0.07, "diastolic": 0.07, "heart_rate": 0.08, "glucose": 0.10, "spo2": 0.02,
         "resp_rate": 0.12, "body_temp": 0.012, "room_temp": 0.08}
RANK = {"critical": 3, "warning": 2, "trend": 1, "ok": 0, "info": 0}
WELLNESS = ["sleep", "water", "food", "stress", "habits", "activity", "fatigue"]

TXT = {
    "ru": {"now": "Сейчас {label}: {value} {unit} — {state} (норма {norm}).",
           "day": "Среднее за сутки — {value} {unit}, {state}.",
           "up": "За сутки показатель выше вашего недельного среднего на {pct}% ({day} против {week}).",
           "down": "За сутки показатель ниже вашего недельного среднего на {pct}% ({day} против {week}).",
           "kcal_low": "За сутки израсходовано {day} ккал — меньше вашего обычного уровня ({week} ккал в день).",
           "kcal_ok": "За сутки израсходовано {day} ккал — вы держите хороший уровень активности.",
           "all_ok": "Все основные показатели в норме и стабильны. Советы ниже помогут сохранить этот результат.",
           "ok_title": "Показатели в норме", "wellness": "Для поддержания здоровья",
           "no_data": "Пока нет данных с устройства — советы появятся после первых измерений."},
    "uz": {"now": "Hozir {label}: {value} {unit} — {state} (me'yor {norm}).",
           "day": "Bir kunlik o'rtacha — {value} {unit}, {state}.",
           "up": "Bir kunda ko'rsatkich haftalik o'rtachangizdan {pct}% yuqori ({day} va {week}).",
           "down": "Bir kunda ko'rsatkich haftalik o'rtachangizdan {pct}% past ({day} va {week}).",
           "kcal_low": "Bir kunda {day} kkal sarflandi — odatdagidan kam (kuniga {week} kkal).",
           "kcal_ok": "Bir kunda {day} kkal sarflandi — faollik darajangiz yaxshi.",
           "all_ok": "Barcha asosiy ko'rsatkichlar me'yorda va barqaror. Quyidagi maslahatlar natijani saqlashga yordam beradi.",
           "ok_title": "Ko'rsatkichlar me'yorda", "wellness": "Salomatlikni saqlash uchun",
           "no_data": "Qurilmadan hali ma'lumot yo'q — maslahatlar birinchi o'lchovlardan keyin paydo bo'ladi."},
    "en": {"now": "Now {label}: {value} {unit} — {state} (normal {norm}).",
           "day": "24 h average — {value} {unit}, {state}.",
           "up": "Over 24 h this reading is {pct}% above your weekly average ({day} vs {week}).",
           "down": "Over 24 h this reading is {pct}% below your weekly average ({day} vs {week}).",
           "kcal_low": "You burned {day} kcal in 24 h — less than usual ({week} kcal a day).",
           "kcal_ok": "You burned {day} kcal in 24 h — a good activity level.",
           "all_ok": "All key readings are normal and stable. The tips below will help you keep it that way.",
           "ok_title": "Readings are normal", "wellness": "To stay healthy",
           "no_data": "No device data yet — tips will appear after the first measurements."},
}


def _val(metric: str, v: float) -> str:
    return f"{v:.{METRIC_INFO.get(metric, (0, 0, 0, 0))[3]}f}"


def _label(text: str) -> str:
    return text if text.startswith("SpO") else text[0].lower() + text[1:]


def _bp(src: dict, m: str, key: str | None = None) -> str:
    """Blood pressure is shown as systolic/diastolic."""
    get = (lambda k: src.get(k, {}).get(key)) if key else src.get
    v = get(m)
    if m == "systolic" and get("diastolic") is not None:
        return f"{v:.0f}/{get('diastolic'):.0f}"
    return _val(m, v)


def _tips(topic: str, lang: str, n: int) -> list[str]:
    pool = TOPICS[topic][lang]["tips"]
    return random.sample(pool, min(n, len(pool)))


def personal_tips(latest: dict | None, day: dict, week: dict, lang: str) -> list[dict]:
    T, P = TXT[lang], PHRASES[lang]
    if not latest:
        return [{"topic": "info", "level": "info", "title": T["wellness"], "reasons": [T["no_data"]],
                 "tips": _tips(random.choice(WELLNESS), lang, 3)}]
    cards = []
    for topic, metrics in GROUPS.items():
        level, reasons = "ok", []
        for m in metrics:
            if m not in latest:
                continue
            label, unit, norm, _ = METRIC_INFO.get(m, ({lang: m}, {lang: ""}, "", 1))
            lvl_now, st_now = _state(m, latest[m], P)
            if lvl_now != "normal" and m in METRIC_INFO:
                reasons.append(T["now"].format(label=_label(label[lang]),
                                               value=_bp(latest, m), unit=unit[lang], state=st_now, norm=norm))
                level = max(level, lvl_now, key=lambda x: RANK[x])
            d_avg, w_avg = day.get(m, {}).get("avg"), week.get(m, {}).get("avg")
            if d_avg is not None:
                lvl_day, st_day = _state(m, d_avg, P)
                if lvl_day != "normal" and m in METRIC_INFO:
                    reasons.append(T["day"].format(value=_bp(day, m, "avg"), unit=unit[lang], state=st_day))
                    level = max(level, lvl_day, key=lambda x: RANK[x])
                if w_avg:
                    change = (d_avg - w_avg) / w_avg
                    if abs(change) >= TREND[m] and m in METRIC_INFO:
                        key = "up" if change > 0 else "down"
                        reasons.append(T[key].format(pct=round(abs(change) * 100), day=_bp(day, m, "avg"),
                                                     week=_bp(week, m, "avg")))
                        level = max(level, "trend", key=lambda x: RANK[x])
        if level != "ok":
            cards.append({"topic": topic, "level": level, "title": TOPIC_TITLES[topic][lang],
                          "reasons": list(dict.fromkeys(reasons)),
                          "tips": _tips(topic, lang, 3 if level in ("critical", "warning") else 2)})

    # activity from calories: today vs weekly daily average
    d_kcal = day.get("calories", {}).get("total")
    w_kcal = week.get("calories", {}).get("total")
    if d_kcal and w_kcal:
        w_daily = w_kcal / 7
        if d_kcal < 0.85 * w_daily:
            cards.append({"topic": "activity", "level": "trend", "title": TOPIC_TITLES["activity"][lang],
                          "reasons": [T["kcal_low"].format(day=round(d_kcal), week=round(w_daily))],
                          "tips": _tips("activity", lang, 2)})

    cards.sort(key=lambda c: -RANK[c["level"]])
    if not any(c["level"] in ("critical", "warning") for c in cards):
        reasons = [T["all_ok"]]
        if d_kcal and w_kcal and d_kcal >= 0.85 * w_kcal / 7:
            reasons.append(T["kcal_ok"].format(day=round(d_kcal)))
        cards.insert(0, {"topic": "ok", "level": "ok", "title": T["ok_title"], "reasons": reasons, "tips": []})

    used = {c["topic"] for c in cards}
    for topic in random.sample([w for w in WELLNESS if w not in used], 2):
        cards.append({"topic": topic, "level": "info", "title": f"{T['wellness']}: {TOPIC_TITLES[topic][lang].lower()}",
                      "reasons": [], "tips": _tips(topic, lang, 2)})
    return cards
