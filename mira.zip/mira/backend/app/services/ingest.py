"""
ingest.py — ЕДИНАЯ ТОЧКА ПРИЁМА ИЗМЕРЕНИЙ
========================================
Любое новое измерение (с настоящего устройства через /api/device/ingest или из симулятора)
проходит через ingest_reading():
  1. проверка порогов (thresholds.evaluate);
  2. обновление устройства: батарея, «в сети», GPS — НЕ ЧАЩЕ РАЗА В ЧАС (gps_update_sec=3600),
     но при критическом событии координаты обновляются сразу (скорой нужна свежая точка);
  3. сохранение в БД (симулятор сохраняет каждое ~15-е измерение, чтобы не раздувать базу);
  4. рассылка в реальном времени через WebSocket: пациенту — показатели и состояние
     устройства, врачу — показатели его пациента;
  5. обработка тревог (emergency.handle_alerts) — тревоги уходят ТОЛЬКО врачу.
"""
from sqlalchemy.orm import Session

from ..config import get_settings
from ..models import Measurement, User, utcnow
from .emergency import handle_alerts
from .thresholds import evaluate
from .ws_manager import doctor_channel, manager, patient_channel

settings = get_settings()

VITALS = ["heart_rate", "systolic", "diastolic", "glucose", "resp_rate", "spo2",
          "calories", "body_temp", "room_temp"]


async def ingest_reading(db: Session, patient: User, reading: dict, persist: bool = True,
                         stored_calories: float | None = None) -> None:
    """stored_calories: kcal accumulated since last stored row (simulator stores every ~30 s)."""
    ts = reading.get("ts") or utcnow()
    device = patient.device
    findings = evaluate(reading)
    if device:
        if reading.get("lat") is not None:
            now = utcnow()
            prev = device.gps_updated
            critical = any(lvl == "critical" for _, _, lvl in findings)
            # GPS сохраняется раз в gps_update_sec (1 час); при критическом событии — сразу
            if prev is None or (now - prev).total_seconds() >= settings.gps_update_sec or critical:
                device.lat, device.lon = reading["lat"], reading["lon"]
                device.gps_updated = now
        if reading.get("battery") is not None:
            device.battery = reading["battery"]
        device.connected = True
        device.last_seen = utcnow()

    if persist:
        row = {k: reading[k] for k in VITALS}
        if stored_calories is not None:
            row["calories"] = stored_calories
        db.add(Measurement(user_id=patient.id, ts=ts, **row))
    db.commit()

    payload = {"type": "measurement", "patient_id": patient.id,
               "data": {"ts": ts.isoformat(), **{k: round(float(reading[k]), 2) for k in VITALS}}}
    await manager.publish(patient_channel(patient.id), payload)
    if device:
        dev = {"type": "device", "patient_id": patient.id,
               "data": {"battery": round(device.battery, 1), "connected": device.connected,
                        "lat": device.lat, "lon": device.lon, "last_seen": device.last_seen.isoformat(),
                        "gps_updated": device.gps_updated.isoformat() if device.gps_updated else None}}
        await manager.publish(patient_channel(patient.id), dev)
    if patient.doctor_id:
        await manager.publish(doctor_channel(patient.doctor_id), payload)

    await handle_alerts(db, patient, findings)
