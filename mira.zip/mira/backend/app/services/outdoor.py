"""
outdoor.py — «ВЫХОДИТЬ ЛИ НА УЛИЦУ И НУЖНА ЛИ МАСКА?»
====================================================
ИИ-ассистент советует, исходя из ДВУХ источников сразу:
  1) погода сейчас: температура, УФ-индекс, качество воздуха (US AQI и мелкая пыль PM2.5);
  2) состояние самого пациента: температура тела, SpO₂, дыхание, давление, возраст.

Итог — один из трёх вердиктов + отдельный флаг «маска»:
    go        — можно спокойно выходить;
    go_limit  — выходить можно, но ненадолго и в правильное время (жара, УФ, мороз, давление);
    stay      — сегодня лучше остаться дома (температура тела, низкий SpO₂, очень грязный воздух
                для чувствительных людей, сильная жара у пожилых);
    mask=True — на улице нужна маска FFP2/KN95 (грязный воздух или слабые дыхательные показатели).

Формулировки спокойные: пациенту не говорим «опасно/критично» — говорим, что лучше сделать.
Пороги ориентировочные (ВОЗ, шкала US AQI) и должны быть утверждены врачом.
"""

TXT = {
    "ru": {
        "title": {"go": "Можно выходить на улицу", "go_limit": "Выходить можно, но ненадолго",
                  "stay": "Сегодня лучше побыть дома"},
        "mask_title": " · возьмите маску",
        "r": {"fever": "температура тела {v} °C — организму нужен отдых",
              "spo2": "уровень кислорода {v} % ниже привычного",
              "resp": "дыхание учащено ({v} в минуту)",
              "bp": "давление повышено ({v})",
              "heat": "на улице жарко: {v} °C",
              "cold": "на улице холодно: {v} °C",
              "uv": "высокий УФ-индекс: {v}",
              "aqi": "качество воздуха: {lvl} (AQI {v})",
              "age": "в вашем возрасте жара и грязный воздух переносятся тяжелее"},
        "lvl": {"good": "хорошее", "moderate": "среднее", "sensitive": "плохое для чувствительных людей",
                "unhealthy": "плохое", "unknown": "нет данных"},
        "tips": {"mask": "Наденьте маску FFP2 или KN95 — обычная медицинская маска хуже задерживает мелкую пыль PM2.5.",
                 "heat": "Выходите до 10:00 или после 18:00, возьмите воду и головной убор.",
                 "uv": "Защитите кожу и глаза: одежда с рукавами, солнцезащитный крем SPF 30+, очки.",
                 "cold": "Оденьтесь слоями и прикрывайте нос и рот шарфом — холодный воздух раздражает бронхи.",
                 "short": "Ограничьте прогулку 20–30 минутами и идите в спокойном темпе.",
                 "stay": "Отдохните дома, пейте воду; проветривайте комнату, когда воздух чище (обычно рано утром).",
                 "window": "Если воздух грязный — держите окна закрытыми днём, проветривайте утром.",
                 "go": "Отличное время для прогулки 30–40 минут — это полезно для давления, сна и настроения.",
                 "estimate": "Данных о воздухе сейчас нет — совет основан на сезонной оценке для Ташкента."},
    },
    "uz": {
        "title": {"go": "Tashqariga chiqish mumkin", "go_limit": "Chiqish mumkin, lekin qisqa vaqtga",
                  "stay": "Bugun uyda qolgan ma'qul"},
        "mask_title": " · niqob oling",
        "r": {"fever": "tana harorati {v} °C — organizmga dam kerak",
              "spo2": "kislorod darajasi {v} % odatdagidan past",
              "resp": "nafas tezlashgan (daqiqasiga {v})",
              "bp": "bosim ko'tarilgan ({v})",
              "heat": "tashqarida issiq: {v} °C",
              "cold": "tashqarida sovuq: {v} °C",
              "uv": "UB-indeks yuqori: {v}",
              "aqi": "havo sifati: {lvl} (AQI {v})",
              "age": "sizning yoshingizda issiq va iflos havoni ko'tarish qiyinroq"},
        "lvl": {"good": "yaxshi", "moderate": "o'rtacha", "sensitive": "sezgir odamlar uchun yomon",
                "unhealthy": "yomon", "unknown": "ma'lumot yo'q"},
        "tips": {"mask": "FFP2 yoki KN95 niqob taqing — oddiy tibbiy niqob mayda PM2.5 changni yomonroq ushlaydi.",
                 "heat": "Soat 10:00 gacha yoki 18:00 dan keyin chiqing, suv va bosh kiyim oling.",
                 "uv": "Teri va ko'zni himoya qiling: yengli kiyim, SPF 30+ krem, ko'zoynak.",
                 "cold": "Qatlam-qatlam kiyining, burun va og'izni sharf bilan yoping — sovuq havo bronxlarni bezovta qiladi.",
                 "short": "Sayrni 20–30 daqiqa bilan cheklang va sokin yuring.",
                 "stay": "Uyda dam oling, suv iching; xonani havo tozaroq bo'lganda (odatda erta tongda) shamollating.",
                 "window": "Havo iflos bo'lsa — kunduzi derazalarni yopiq tuting, ertalab shamollating.",
                 "go": "30–40 daqiqalik sayr uchun ajoyib vaqt — bosim, uyqu va kayfiyat uchun foydali.",
                 "estimate": "Hozir havo haqida ma'lumot yo'q — maslahat Toshkent uchun mavsumiy baholashga asoslangan."},
    },
    "en": {
        "title": {"go": "Good time to go outside", "go_limit": "You can go out, but briefly",
                  "stay": "Better to stay home today"},
        "mask_title": " · take a mask",
        "r": {"fever": "body temperature {v} °C — your body needs rest",
              "spo2": "oxygen level {v} % is lower than usual",
              "resp": "breathing is faster than usual ({v} per minute)",
              "bp": "blood pressure is raised ({v})",
              "heat": "it is hot outside: {v} °C",
              "cold": "it is cold outside: {v} °C",
              "uv": "high UV index: {v}",
              "aqi": "air quality: {lvl} (AQI {v})",
              "age": "at your age heat and polluted air are harder on the body"},
        "lvl": {"good": "good", "moderate": "moderate", "sensitive": "poor for sensitive people",
                "unhealthy": "poor", "unknown": "no data"},
        "tips": {"mask": "Wear an FFP2 or KN95 mask — a regular surgical mask filters fine PM2.5 dust much less.",
                 "heat": "Go out before 10:00 or after 18:00, take water and a hat.",
                 "uv": "Protect skin and eyes: long sleeves, SPF 30+ sunscreen, sunglasses.",
                 "cold": "Dress in layers and cover nose and mouth with a scarf — cold air irritates the airways.",
                 "short": "Keep the walk to 20–30 minutes at a calm pace.",
                 "stay": "Rest at home and drink water; air the room when the air is cleaner (usually early morning).",
                 "window": "If the air is polluted, keep windows closed during the day and air rooms in the morning.",
                 "go": "A great time for a 30–40 minute walk — good for blood pressure, sleep and mood.",
                 "estimate": "No live air data right now — this advice uses a seasonal estimate for Tashkent."},
    },
}


def decide(ctx: dict, cond: dict, lang: str) -> dict:
    """ctx — контекст пациента (latest, avg, age), cond — weather.current_conditions()."""
    T = TXT[lang]
    v = {**(ctx.get("avg") or {}), **(ctx.get("latest") or {})}   # последние значения важнее средних
    age = ctx.get("age") or 0
    reasons, tips = [], []
    stay = limit = mask = False

    # ---- состояние пациента
    body = v.get("body_temp")
    spo2 = v.get("spo2")
    resp = v.get("resp_rate")
    sys_, dia = v.get("systolic"), v.get("diastolic")
    if body is not None and body >= 37.8:
        stay = True
        reasons.append(T["r"]["fever"].format(v=f"{body:.1f}"))
    if spo2 is not None and spo2 < 94:
        reasons.append(T["r"]["spo2"].format(v=f"{spo2:.0f}"))
        stay = stay or spo2 < 92
        mask = True
    if resp is not None and resp > 22:
        reasons.append(T["r"]["resp"].format(v=f"{resp:.0f}"))
        mask = True
    if sys_ is not None and sys_ >= 150:
        reasons.append(T["r"]["bp"].format(v=f"{sys_:.0f}/{dia or 0:.0f}"))
        limit = True
    sensitive = age >= 65 or mask   # пожилые и люди с «слабым дыханием» — чувствительная группа

    # ---- погода и воздух
    temp, uv, aqi = cond.get("temp"), cond.get("uv"), cond.get("aqi")
    if temp is not None and temp >= 33:
        limit = True
        reasons.append(T["r"]["heat"].format(v=f"{temp:.0f}"))
        tips.append(T["tips"]["heat"])
        if temp >= 38 and (age >= 65 or (sys_ or 0) >= 150):
            stay = True
            if age >= 65:
                reasons.append(T["r"]["age"])
    if temp is not None and temp <= -5:
        limit = True
        reasons.append(T["r"]["cold"].format(v=f"{temp:.0f}"))
        tips.append(T["tips"]["cold"])
    if uv is not None and uv >= 6:
        limit = True
        reasons.append(T["r"]["uv"].format(v=f"{uv:.0f}"))
        tips.append(T["tips"]["uv"])
    if aqi is not None:
        lvl = cond.get("aqi_level", "unknown")
        if aqi > 100 or (aqi > 50 and sensitive) or (cond.get("pm25") or 0) > 35:
            mask = True
            reasons.append(T["r"]["aqi"].format(lvl=T["lvl"][lvl], v=f"{aqi:.0f}"))
            tips.append(T["tips"]["window"])
        if aqi > 150 and sensitive:
            stay = True

    verdict = "stay" if stay else "go_limit" if (limit or mask) else "go"
    if mask and verdict != "stay":
        tips.insert(0, T["tips"]["mask"])
    if verdict == "stay":
        tips.insert(0, T["tips"]["stay"])
    elif verdict == "go_limit":
        tips.append(T["tips"]["short"])
    else:
        tips.append(T["tips"]["go"])
    if cond.get("source") == "estimate":
        tips.append(T["tips"]["estimate"])
    title = T["title"][verdict] + (T["mask_title"] if mask and verdict != "stay" else "")
    return {"verdict": verdict, "mask": mask, "title": title, "reasons": reasons,
            "tips": list(dict.fromkeys(tips)), "conditions": cond}
