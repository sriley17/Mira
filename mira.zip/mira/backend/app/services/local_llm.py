"""
local_llm.py — ЛОКАЛЬНАЯ ЯЗЫКОВАЯ МОДЕЛЬ (необязательно)
=======================================================
ТЗ: «ИИ-ассистент локальный (не глобальный) — для максимальной безопасности данных».

MIRA НЕ отправляет данные пациента ни в какие облачные ИИ (ChatGPT, Claude API и т.п.).
Есть два уровня:

1. Встроенный движок (ai.py + ai_kb.py) — работает ВСЕГДА, без интернета и без видеокарты.
   Он анализирует показатели и собирает ответ из базы знаний.
2. Локальная LLM через Ollama — если администратор поставил её на свой сервер:
       curl -fsSL https://ollama.com/install.sh | sh
       ollama pull qwen2.5:7b          # хорошо понимает русский и узбекский
       OLLAMA_URL=http://127.0.0.1:11434   (в .env)
   Тогда ответы становятся более «живыми», а факты (цифры пациента) модель получает
   из встроенного анализа — то есть не выдумывает их.

Защита «только локально»: адрес Ollama проверяется — разрешены только localhost и
частные сети (10.x, 172.16–31.x, 192.168.x). Публичный адрес будет отклонён, даже если
его случайно (или злонамеренно) прописали в настройках.
"""
import ipaddress
import logging
import socket
from urllib.parse import urlparse

import httpx

from ..config import get_settings

log = logging.getLogger("mira.llm")
settings = get_settings()


def _is_local_url(url: str) -> bool:
    """True, если хост — loopback или частная сеть."""
    host = urlparse(url).hostname
    if not host:
        return False
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        return False
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if not (ip.is_loopback or ip.is_private):
            return False
    return True


def available() -> bool:
    """Включена ли локальная LLM (задан адрес и он локальный)."""
    if not settings.ollama_url:
        return False
    if not _is_local_url(settings.ollama_url):
        log.error("OLLAMA_URL указывает на публичный адрес — LLM отключена ради приватности данных")
        return False
    return True


async def chat(system: str, history: list[dict], message: str) -> str:
    """Запрос к Ollama /api/chat. Любая ошибка -> исключение (вызывающий код вернётся к встроенному движку)."""
    msgs = [{"role": "system", "content": system}, *history[-8:], {"role": "user", "content": message}]
    async with httpx.AsyncClient(timeout=settings.ollama_timeout_sec) as client:
        r = await client.post(f"{settings.ollama_url.rstrip('/')}/api/chat",
                              json={"model": settings.ollama_model, "messages": msgs, "stream": False,
                                    "options": {"temperature": 0.7, "num_ctx": 4096}})
        r.raise_for_status()
        text = r.json().get("message", {}).get("content", "").strip()
    if not text:
        raise ValueError("empty LLM answer")
    return text
