"""
routers/notes.py — ЗАКРЫТЫЕ ЗАМЕТКИ ВРАЧА О ПАЦИЕНТЕ
===================================================
Какие сведения опасны для самого пациента (могут вызвать тревогу, самолечение или отказ от лечения)
и поэтому в MIRA видны ТОЛЬКО ВРАЧУ:
  • критические тревоги и история вызовов скорой        (routers/admin.py, measurements/alerts)
  • оценка риска и клинические находки ИИ-аналитика      (routers/ai.py -> /clinical)
  • закрытые заметки врача: прогноз, подозрения, план    (этот модуль)
  • журнал аудита
Пациент по закону имеет право на свою медицинскую карту, поэтому сама медкарта (диагнозы, анализы)
ему доступна; скрываются только интерпретации, прогнозы и сигналы тревоги.

GET    /api/notes?patient_id=5     заметки о пациенте (только его врач)
POST   /api/notes                  добавить заметку
DELETE /api/notes/{id}             удалить свою заметку
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import DoctorNote, User
from ..security import decrypt, encrypt, require_doctor, resolve_patient

router = APIRouter(prefix="/api/notes", tags=["doctor-notes"])


class NoteIn(BaseModel):
    patient_id: int
    body: str = Field(min_length=1, max_length=3000)


@router.get("")
def list_notes(patient_id: int, doctor: User = Depends(require_doctor), db: Session = Depends(get_db)):
    p = resolve_patient(doctor, patient_id, db)
    rows = db.scalars(select(DoctorNote).where(DoctorNote.patient_id == p.id).order_by(DoctorNote.created_at.desc()))
    return [{"id": n.id, "body": decrypt(n.body_enc), "created_at": n.created_at.isoformat(),
             "mine": n.doctor_id == doctor.id} for n in rows]


@router.post("")
def add_note(data: NoteIn, doctor: User = Depends(require_doctor), db: Session = Depends(get_db)):
    p = resolve_patient(doctor, data.patient_id, db)
    n = DoctorNote(patient_id=p.id, doctor_id=doctor.id, body_enc=encrypt(data.body.strip()))
    db.add(n)
    db.commit()
    return {"id": n.id}


@router.delete("/{note_id}")
def delete_note(note_id: int, doctor: User = Depends(require_doctor), db: Session = Depends(get_db)):
    n = db.get(DoctorNote, note_id)
    if not n or n.doctor_id != doctor.id:
        raise HTTPException(404, "Note not found")
    db.delete(n)
    db.commit()
    return {"ok": True}
