"""
routers/dmed.py — МЕДКАРТА ИЗ DMED
=================================
GET /api/dmed/record?patient_id=5   расширенные медданные пациента (диагнозы, аллергии, анализы...)
GET /api/dmed/status                включена ли реальная интеграция или демо-режим

Смотреть медкарту может врач (только своего пациента) и сам пациент.
Каждый просмотр записывается в журнал аудита — это требование медицинской безопасности.
"""
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import User
from ..security import audit, decrypt, get_current_user, resolve_patient
from ..services.dmed import DmedError, dmed

router = APIRouter(prefix="/api/dmed", tags=["dmed"])


@router.get("/status")
def status(user: User = Depends(get_current_user)):
    return {"mode": "demo" if dmed.demo else "live"}


@router.get("/record")
async def record(request: Request, patient_id: int | None = None, user: User = Depends(get_current_user),
                 db: Session = Depends(get_db)):
    p = resolve_patient(user, patient_id, db)
    pinfl = decrypt(p.pinfl_enc) if p.pinfl_enc else None
    try:
        data = await dmed.fetch_record(pinfl, p.id, p.age, p.gender)
    except DmedError as e:
        raise HTTPException(502, str(e))
    audit(db, "dmed_view", user.id, p.id, request, detail=data["source"])
    data["pinfl_set"] = bool(pinfl)
    return data
