"""
routers/ai.py — ЛОКАЛЬНЫЙ ИИ (чат + динамические инсайты)
========================================================
Кабинет пациента — ИИ-ассистент: советы на основе СВОИХ показателей, сна, целей, лекарств, погоды.
Кабинет врача   — ИИ-аналитик: статистика, тренды, риск, черновики по выбранному пациенту.

GET    /api/ai/insights      ПАЦИЕНТ: карточки «что важно сейчас» (заменяют раздел советов)
GET    /api/ai/clinical      ВРАЧ: клиническая сводка по пациенту (риск, находки, режим, сон)
GET    /api/ai/suggestions   быстрые вопросы-кнопки
GET    /api/ai/history       история чата (зашифрована в БД)
POST   /api/ai/chat          задать вопрос
DELETE /api/ai/history       очистить историю
GET    /api/ai/engine        какой движок работает: builtin или local-llm

Все вычисления — на нашем сервере. Облачные ИИ не используются.
"""
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..database import get_db
from ..models import ChatMessage, Measurement, User, utcnow
from ..schemas import ChatIn, ChatOut
from ..security import audit, decrypt, encrypt, get_current_user, require_doctor, resolve_patient
from ..services import ai, doctor_ai, goals as goals_svc, local_llm, medications as meds_svc, moderation, outdoor, \
    weather
from ..services.ai_kb import DOCTOR_QUICK_QUESTIONS, QUICK_QUESTIONS, TOPIC_TITLES
from ..services.clinical import cohort, patient_stats
from ..services.tips import personal_tips
from .measurements import build_report
from .wellbeing import sleep_for

router = APIRouter(prefix="/api/ai", tags=["ai-assistant"])
DOCTOR_BLOCKED = {"jailbreak", "weapons", "sexual", "abuse", "offtopic"}
settings = get_settings()
VITALS = ["heart_rate", "systolic", "diastolic", "glucose", "resp_rate", "spo2", "body_temp", "room_temp"]


def _history_q(user: User, patient_id: int | None):
    q = select(ChatMessage).where(ChatMessage.user_id == user.id)
    if user.role == "doctor":  # у врача отдельная переписка по каждому пациенту
        q = q.where(ChatMessage.patient_id.is_(None) if patient_id is None else ChatMessage.patient_id == patient_id)
    return q


async def patient_context(p: User, db: Session, lang: str = "ru") -> dict:
    """ВСЁ, что ассистент знает о пациенте. Собирается заново на каждый вопрос —
    поэтому советы всегда соответствуют текущей аналитике."""
    ctx: dict = {"name": p.first_name, "age": p.age, "gender": p.gender, "role": "patient"}
    m = db.scalar(select(Measurement).where(Measurement.user_id == p.id).order_by(Measurement.ts.desc()).limit(1))
    if m:
        ctx["latest"] = {k: round(getattr(m, k), 1) for k in VITALS}
        day = build_report(p.id, "day")["summary"]
        ctx["avg"] = {k: v["avg"] for k, v in day.items() if k in VITALS}
        ctx["kcal_total"] = day.get("calories", {}).get("total")
        ctx["_day"] = day
    sl = await sleep_for(p)
    ctx["sleep"] = sl.get("summary")
    ctx["goals"] = goals_svc.progress(db, p, ctx["sleep"]["last"]["hours"] if ctx["sleep"] else None)
    ctx["meds"] = {"today": meds_svc.day_schedule(db, p), "adherence": meds_svc.adherence(db, p, 7)}
    dev = p.device
    lat, lon = (dev.lat, dev.lon) if dev else (41.31, 69.28)
    wx = await weather.daily_weather(lat, lon, days_back=1)
    ctx["weather"] = weather.for_day(wx, meds_svc.local_today())
    # совет «выходить ли на улицу / нужна ли маска»: погода + воздух + состояние пациента
    ctx["outdoor"] = outdoor.decide(ctx, await weather.current_conditions(lat, lon), lang)
    return ctx


@router.get("/engine")
def engine(user: User = Depends(get_current_user)):
    return {"engine": "local-llm" if local_llm.available() else "builtin",
            "model": settings.ollama_model if local_llm.available() else None}


@router.get("/insights")
async def insights(lang: Literal["ru", "uz", "en"] = "ru", user: User = Depends(get_current_user),
                   db: Session = Depends(get_db)):
    """ПАЦИЕНТ: карточки «Что важно сейчас» — улица/маска, показатели (сейчас / сутки / тренд),
    сон, лекарства, погода, цели. Всё пересчитывается из свежих данных, поэтому советы не повторяются.
    Уровень 'critical' пациенту не показывается — только спокойное 'warning' (ТЗ)."""
    if user.role != "patient":
        raise HTTPException(403, "Patients only — doctors use /api/ai/clinical")
    ctx = await patient_context(user, db, lang)
    week = build_report(user.id, "week")["summary"]
    cards = personal_tips(ctx.get("latest"), ctx.get("_day", {}), week, lang)
    for issue in ai.context_issues(ctx):
        if issue == "outdoor":
            continue   # карточка «улица» добавляется ниже всегда
        block = {"sleep": ai._block_sleep, "medication": ai._block_meds, "heat_uv": ai._block_weather,
                 "goals": ai._block_goals}[issue](ctx, lang)
        if block:
            lines = [ln.lstrip("- ").replace("**", "") for ln in block.split("\n")[1:]]
            cards.insert(1, {"topic": issue, "level": "trend", "title": TOPIC_TITLES[issue][lang],
                             "reasons": lines, "tips": ai._pick_tips(issue, lang, 2, "")})
    o = ctx["outdoor"]
    cards.insert(0, {"topic": "outdoor", "level": "trend" if (o["verdict"] != "go" or o["mask"]) else "ok",
                     "title": o["title"], "reasons": o["reasons"], "tips": o["tips"][:3]})
    for c in cards:
        if c["level"] == "critical":
            c["level"] = "warning"
    return cards


CLIN = {
    "ru": {"risk": "Оценка риска", "risk_r": "{r} баллов · критических тревог за 7 дней: {c}",
           "findings": "Ключевые находки", "none": "Значимых отклонений за 7 дней нет",
           "adh": "Приём лекарств", "adh_r": "Соблюдение режима за 7 дней: {p} % ({t} из {n} доз)",
           "adh_none": "Лекарства не назначены", "sleep": "Сон", "sleep_r": "Последняя ночь {h} ч, качество {s}/100; "
           "в среднем за неделю {a} ч; коротких ночей (< 6.5 ч): {k}", "sleep_none": "Нет данных о сне",
           "out": "Рекомендация по выходу на улицу (видит пациент)", "check": "Что проверить"},
    "uz": {"risk": "Xavf bahosi", "risk_r": "{r} ball · 7 kunda kritik signallar: {c}",
           "findings": "Asosiy topilmalar", "none": "7 kunda sezilarli og'ishlar yo'q",
           "adh": "Dori qabul qilish", "adh_r": "7 kunlik rejimga rioya: {p} % ({n} dozadan {t})",
           "adh_none": "Dorilar tayinlanmagan", "sleep": "Uyqu", "sleep_r": "Oxirgi tun {h} soat, sifat {s}/100; "
           "haftalik o'rtacha {a} soat; qisqa tunlar (< 6.5 soat): {k}", "sleep_none": "Uyqu ma'lumotlari yo'q",
           "out": "Tashqariga chiqish tavsiyasi (bemor ko'radi)", "check": "Nimani tekshirish kerak"},
    "en": {"risk": "Risk score", "risk_r": "{r} points · critical alerts in 7 days: {c}",
           "findings": "Key findings", "none": "No significant deviations in 7 days",
           "adh": "Medication adherence", "adh_r": "Adherence over 7 days: {p} % ({t} of {n} doses)",
           "adh_none": "No medications prescribed", "sleep": "Sleep", "sleep_r": "Last night {h} h, quality {s}/100; "
           "weekly average {a} h; short nights (< 6.5 h): {k}", "sleep_none": "No sleep data",
           "out": "Going-outside advice (shown to the patient)", "check": "What to check"},
}


@router.get("/clinical")
async def clinical(patient_id: int, lang: Literal["ru", "uz", "en"] = "ru", doctor: User = Depends(require_doctor),
                   db: Session = Depends(get_db)):
    """ВРАЧ: клиническая сводка по пациенту вместо «советов пациенту».
    Риск, находки с рекомендациями что проверить, соблюдение режима, сон, совет по улице."""
    p = resolve_patient(doctor, patient_id, db)
    T = CLIN[lang]
    stats = patient_stats(db, p)
    ctx = await patient_context(p, db, lang)
    cards = [{"title": T["risk"], "level": "critical" if stats.get("risk", 0) >= 6 else
              "warning" if stats.get("risk", 0) >= 3 else "normal", "value": stats.get("risk", 0),
              "lines": [T["risk_r"].format(r=stats.get("risk", 0), c=stats.get("alerts_crit7", 0))]}]
    flags = stats.get("flags", [])
    cards.append({"title": T["findings"], "level": "warning" if flags else "normal", "value": len(flags),
                  "lines": [doctor_ai._flag_text(f, stats, lang, 0) for f in flags[:4]] or [T["none"]]})
    if flags:
        cards.append({"title": T["check"], "level": "info", "value": None,
                      "lines": [doctor_ai._flag_text(f, stats, lang, 1) for f in flags[:4]]})
    adh = ctx["meds"]["adherence"]
    cards.append({"title": T["adh"], "level": "warning" if (adh["pct"] is not None and adh["pct"] < 80) else "normal",
                  "value": adh["pct"], "lines": [T["adh_r"].format(p=adh["pct"], t=adh["taken"], n=adh["planned"])]
                  if adh["pct"] is not None else [T["adh_none"]]})
    s = ctx.get("sleep")
    cards.append({"title": T["sleep"], "level": "warning" if s and (s["last"]["score"] < 65 or s["short_nights"] >= 3)
                  else "normal", "value": s["last"]["score"] if s else None,
                  "lines": [T["sleep_r"].format(h=s["last"]["hours"], s=s["last"]["score"], a=s["avg_hours"],
                                                k=s["short_nights"])] if s else [T["sleep_none"]]})
    o = ctx["outdoor"]
    cards.append({"title": T["out"], "level": "info", "value": None, "lines": [o["title"], *o["reasons"][:3]]})
    return cards


@router.get("/history", response_model=list[ChatOut])
def chat_history(patient_id: int | None = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    rows = db.scalars(_history_q(user, patient_id).order_by(ChatMessage.created_at.desc()).limit(50)).all()[::-1]
    return [ChatOut(role=r.role, body=decrypt(r.body_enc), created_at=r.created_at) for r in rows]


@router.get("/suggestions")
def suggestions(lang: str = "ru", user: User = Depends(get_current_user)):
    src = DOCTOR_QUICK_QUESTIONS if user.role == "doctor" else QUICK_QUESTIONS
    return src.get(lang, src["ru"])


@router.delete("/history")
def clear_history(patient_id: int | None = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    ids = [r.id for r in db.scalars(_history_q(user, patient_id))]
    if ids:
        db.execute(delete(ChatMessage).where(ChatMessage.id.in_(ids)))
        db.commit()
    return {"ok": True}


async def _doctor_answer(data: ChatIn, doctor: User, history: list[dict], db: Session) -> str:
    """Врач: встроенный клинический аналитик; при наличии локальной LLM — она формулирует ответ."""
    stats = None
    if data.patient_id:
        p = resolve_patient(doctor, data.patient_id, db)
        stats = patient_stats(db, p)
        # врачу важны не только показатели, но и сон и соблюдение режима лекарств
        stats["sleep"] = (await sleep_for(p)).get("summary")
        stats["adherence"] = meds_svc.adherence(db, p, 7)
    wants_cohort = doctor_ai._intent(f" {data.message.lower()} ") == "cohort"
    rows = cohort(db, doctor) if (wants_cohort or local_llm.available()) else None
    reference = doctor_ai.builtin(data.message, stats, rows, data.lang)
    if local_llm.available():
        try:
            system = doctor_ai.llm_system(stats, rows, data.lang) + f"\n\nЧерновик встроенного аналитика:\n{reference}"
            return await local_llm.chat(system, history, data.message)
        except Exception as e:  # noqa: BLE001
            ai.log.warning("Local LLM failed, built-in analyst used: %s", e)
    return reference


@router.post("/chat", response_model=ChatOut)
async def chat(data: ChatIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    pid = data.patient_id if user.role == "doctor" else None
    # ---- «цензура»: проверяем запрос ДО ответа (services/moderation.py)
    if moderation.rate_limited(user.id):
        return ChatOut(role="assistant", body=moderation.reply("rate", data.lang), created_at=utcnow())
    cat = moderation.check(data.message)
    # врачу можно обсуждать дозы и препараты — для него фильтруются только злоупотребления
    if cat and (user.role == "patient" or cat in DOCTOR_BLOCKED):
        audit(db, "ai_blocked", user.id, detail=cat)       # текст сообщения в журнал НЕ пишем
        reply = moderation.reply(cat, data.lang)
        db.add(ChatMessage(user_id=user.id, patient_id=pid, role="user", body_enc=encrypt(data.message)))
        out = ChatMessage(user_id=user.id, patient_id=pid, role="assistant", body_enc=encrypt(reply))
        db.add(out)
        db.commit()
        return ChatOut(role="assistant", body=reply, created_at=out.created_at)
    rows = db.scalars(_history_q(user, pid).order_by(ChatMessage.created_at.desc()).limit(10)).all()[::-1]
    history = [{"role": r.role, "content": decrypt(r.body_enc)} for r in rows]
    while history and history[0]["role"] != "user":
        history.pop(0)
    if user.role == "doctor":
        reply = await _doctor_answer(data, user, history, db)
    else:
        reply = await ai.answer(data.message, history, await patient_context(user, db, data.lang), data.lang)
    db.add(ChatMessage(user_id=user.id, patient_id=pid, role="user", body_enc=encrypt(data.message)))
    out = ChatMessage(user_id=user.id, patient_id=pid, role="assistant", body_enc=encrypt(reply))
    db.add(out)
    db.commit()
    return ChatOut(role="assistant", body=reply, created_at=out.created_at)
