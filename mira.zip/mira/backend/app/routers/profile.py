"""
routers/profile.py — ЛИЧНЫЕ ДАННЫЕ И ФОТО
========================================
Анкета пациента: кто он, дата рождения, адрес, место работы, должность, контакт родственника,
серия паспорта. Анкета врача: специальность, клиника, кабинет, стаж, часы приёма.
Фото: у пациента — фото паспорта, у врача — фото в медицинской форме.

GET  /api/profile/{user_id}         анкета
PUT  /api/profile                   изменить СВОЮ анкету
PUT  /api/profile/{patient_id}      врач заполняет анкету СВОЕГО пациента (например, на приёме)
POST /api/profile/photo             загрузить своё фото (JPEG/PNG/WebP, до 5 МБ)
GET  /api/profile/{user_id}/photo   получить фото

КТО ЧТО ВИДИТ (главное правило раздела):
    • пациент — только свою анкету и карточку своего лечащего врача;
    • врач    — свою анкету и анкеты ТОЛЬКО своих пациентов;
    • чужие анкеты -> 404 (не подтверждаем даже существование человека).
Каждый просмотр чужой анкеты или фото пишется в журнал аудита.

Защита данных:
    • анкета — один зашифрованный JSON (users.profile_enc);
    • фото шифруется целиком; перед сохранением картинка ПЕРЕКОДИРУЕТСЯ через Pillow:
      удаляются метаданные (GPS из EXIF, модель телефона), а «картинка» с вредоносным
      содержимым просто не откроется и будет отклонена;
    • ответы с фото помечены no-store — браузер не оставляет их в кэше.
"""
import io
import json

from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile
from fastapi.responses import Response
from PIL import Image, UnidentifiedImageError
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import User, UserPhoto, utcnow
from ..security import audit, decrypt, decrypt_bytes, encrypt, encrypt_bytes, get_current_user, mask_phone

router = APIRouter(prefix="/api/profile", tags=["profile"])

MAX_PHOTO = 5 * 1024 * 1024        # 5 МБ
MAX_SIDE = 1200                    # длинная сторона после уменьшения, px


class PatientProfile(BaseModel):
    """Поля анкеты пациента. Все необязательные, длина ограничена — защита от мусора."""
    middle_name: str | None = Field(default=None, max_length=100)
    birth_date: str | None = Field(default=None, pattern=r"^\d{4}-\d{2}-\d{2}$")
    city: str | None = Field(default=None, max_length=100)
    address: str | None = Field(default=None, max_length=300)
    workplace: str | None = Field(default=None, max_length=200)
    position: str | None = Field(default=None, max_length=120)
    passport: str | None = Field(default=None, pattern=r"^[A-Z]{2}\d{7}$")   # AA1234567
    emergency_name: str | None = Field(default=None, max_length=120)
    emergency_phone: str | None = Field(default=None, max_length=32)
    notes: str | None = Field(default=None, max_length=500)


class DoctorProfile(BaseModel):
    specialty: str | None = Field(default=None, max_length=120)
    clinic: str | None = Field(default=None, max_length=200)
    room: str | None = Field(default=None, max_length=50)
    experience_years: int | None = Field(default=None, ge=0, le=70)
    hours: str | None = Field(default=None, max_length=100)
    phone: str | None = Field(default=None, max_length=32)


def _load(u: User) -> dict:
    if not u.profile_enc:
        return {}
    try:
        return json.loads(decrypt(u.profile_enc))
    except json.JSONDecodeError:
        return {}


def _can_view(viewer: User, target: User) -> bool:
    """Правило доступа к анкете и фото (см. описание модуля)."""
    if viewer.id == target.id:
        return True
    if viewer.role == "doctor":
        return target.role == "patient" and target.doctor_id == viewer.id
    return target.role == "doctor" and viewer.doctor_id == target.id   # пациент -> свой врач


def _target(db: Session, viewer: User, user_id: int) -> User:
    target = db.get(User, user_id)
    if not target or not _can_view(viewer, target):
        raise HTTPException(404, "Profile not found")
    return target


def _out(u: User, viewer: User, db: Session) -> dict:
    data = _load(u)
    if viewer.role == "patient" and u.id != viewer.id:
        # пациент видит у врача только рабочую карточку
        data = {k: v for k, v in data.items() if k in DoctorProfile.model_fields}
    return {"id": u.id, "role": u.role, "first_name": u.first_name, "last_name": u.last_name, "age": u.age,
            "gender": u.gender, "email": u.email if (viewer.id == u.id or viewer.role == "doctor") else None,
            "phone_masked": mask_phone(decrypt(u.phone_enc)) if u.phone_enc else None,
            "pinfl_set": bool(u.pinfl_enc), "created_at": u.created_at.isoformat(),
            "has_photo": db.get(UserPhoto, u.id) is not None, "fields": data}


@router.get("/{user_id}")
def get_profile(user_id: int, request: Request, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    target = _target(db, user, user_id)
    if target.id != user.id:
        audit(db, "view_profile", user.id, target.id, request)
    return _out(target, user, db)


def _save(db: Session, target: User, fields: dict) -> None:
    current = _load(target)
    current.update({k: v for k, v in fields.items() if v is not None})
    current = {k: v for k, v in current.items() if v != ""}   # пустая строка = удалить поле
    target.profile_enc = encrypt(json.dumps(current, ensure_ascii=False))
    db.commit()


@router.put("")
def update_own(body: dict, request: Request, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    model = DoctorProfile if user.role == "doctor" else PatientProfile
    fields = model(**body).model_dump()          # проверка по схеме; лишние ключи отбрасываются
    _save(db, user, fields)
    audit(db, "profile_update", user.id, request=request)
    return _out(user, user, db)


@router.put("/{patient_id}")
def update_patient(patient_id: int, body: PatientProfile, request: Request, user: User = Depends(get_current_user),
                   db: Session = Depends(get_db)):
    target = _target(db, user, patient_id)
    if user.role != "doctor" or target.role != "patient":
        raise HTTPException(403, "Doctors only")
    _save(db, target, body.model_dump())
    audit(db, "profile_update", user.id, target.id, request)
    return _out(target, user, db)


@router.post("/photo")
async def upload_photo(request: Request, file: UploadFile = File(...), user: User = Depends(get_current_user),
                       db: Session = Depends(get_db)):
    raw = await file.read(MAX_PHOTO + 1)
    if len(raw) > MAX_PHOTO:
        raise HTTPException(413, "Photo is larger than 5 MB")
    try:
        img = Image.open(io.BytesIO(raw))
        img.verify()                              # проверка целостности файла
        img = Image.open(io.BytesIO(raw))         # после verify() файл нужно открыть заново
        if img.format not in ("JPEG", "PNG", "WEBP"):
            raise HTTPException(415, "Only JPEG, PNG or WebP")
        img = img.convert("RGB")                  # убираем прозрачность и экзотические режимы
        img.thumbnail((MAX_SIDE, MAX_SIDE))
        buf = io.BytesIO()
        img.save(buf, "JPEG", quality=85)         # новый файл БЕЗ метаданных
    except (UnidentifiedImageError, OSError, ValueError):
        raise HTTPException(415, "File is not a valid image")
    photo = db.get(UserPhoto, user.id) or UserPhoto(user_id=user.id)
    photo.kind = "uniform" if user.role == "doctor" else "passport"
    photo.mime = "image/jpeg"
    photo.data_enc = encrypt_bytes(buf.getvalue())
    photo.updated_at = utcnow()
    db.add(photo)
    db.commit()
    audit(db, "photo_upload", user.id, request=request, detail=photo.kind)
    return {"ok": True}


@router.get("/{user_id}/photo")
def get_photo(user_id: int, request: Request, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    target = _target(db, user, user_id)
    photo = db.get(UserPhoto, target.id)
    if not photo:
        raise HTTPException(404, "No photo")
    if target.id != user.id:
        audit(db, "view_photo", user.id, target.id, request, detail=photo.kind)
    return Response(decrypt_bytes(photo.data_enc), media_type=photo.mime,
                    headers={"Cache-Control": "no-store"})
