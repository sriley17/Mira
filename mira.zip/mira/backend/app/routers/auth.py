"""
routers/auth.py — РЕГИСТРАЦИЯ, ВХОД, ВЫХОД, ПРОФИЛЬ
==================================================
POST /api/auth/register   регистрация (пациент -> статус pending, ждёт одобрения врача)
POST /api/auth/login      вход (форма OAuth2: username=email, password) -> JWT
POST /api/auth/logout     выход: токен попадает в чёрный список
GET  /api/auth/devices    мои устройства; POST .../{id}/approve — разрешить новое, .../{id}/revoke — отключить
GET  /api/auth/oneid/url  адрес входа через OneID;  POST /api/auth/oneid/callback — завершение входа

ОДИН АККАУНТ — ОДНО УСТРОЙСТВО. Браузер присылает заголовок X-Device-Id (случайный id из cookie).
  • первое устройство одобряется автоматически;
  • с нового устройства (телефон после ноутбука) войти МОЖНО, но кабинет пустой: устройство в статусе
    pending, медицинские данные не отдаются (403 device_pending). Подтвердить устройство можно
    двумя способами:
       1) в «Профиле» на новом устройстве — проверкой лица (MyID): POST /api/identity/verify-device;
       2) с первого устройства — «Уведомления» или «Настройки → Мои устройства» -> «Разрешить».
  • токен привязан к устройству: если устройство отозвать, его токен сразу перестаёт работать.
GET  /api/auth/me         кто я (работает и для pending — чтобы показать экран ожидания)
PUT  /api/auth/profile    телефон для SMS и ПИНФЛ для Dmed (хранятся зашифрованными)
POST /api/auth/password   смена пароля

Безопасность входа:
  • одинаковый ответ «неверный email или пароль» — не подсказываем, что именно неверно;
  • проверка пароля занимает одинаковое время, даже если email не существует;
  • 5 неудачных попыток -> блокировка на 5 минут (429 Too Many Requests);
  • каждый вход и неудачная попытка пишутся в журнал аудита.
"""
import hmac
import secrets

import httpx

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..database import get_db
from ..models import User, UserDevice, utcnow
from ..schemas import OneIDCallbackIn, PasswordChangeIn, ProfileIn, RegisterIn, TokenOut, UserOut
from ..security import (audit, client_ip, create_token, decode_token, decrypt, device_hash, encrypt,
                        get_current_user, get_user_any_status, hash_password, login_limiter, LoginLimiter,
                        require_approved_device, mask_phone,
                        oauth2_scheme, password_problems, revoke_token, verify_password, verify_password_or_dummy)
from ..services import oneid
from ..services.sms import normalize_phone

router = APIRouter(prefix="/api/auth", tags=["auth"])
settings = get_settings()
email_limiter = LoginLimiter(settings.login_max_attempts * 4, settings.login_lock_sec)


def user_out(user: User, device_status: str | None = None) -> UserOut:
    """Модель User -> ответ API. Телефон отдаём только маскированным.
    device_status — подтверждено ли устройство, с которого пришёл запрос (approved / pending)."""
    out = UserOut.model_validate(user)
    out.phone_masked = mask_phone(decrypt(user.phone_enc)) if user.phone_enc else None
    out.device_status = device_status or getattr(user, "device_status", "approved")
    return out


def _dev_status(db: Session, user: User, dh: str) -> str:
    d = db.scalar(select(UserDevice).where(UserDevice.user_id == user.id, UserDevice.device_hash == dh))
    return d.status if (d and settings.device_binding) else "approved"


def _least_loaded_doctor(db: Session) -> int | None:
    """Новый пациент попадает к врачу с наименьшим числом пациентов (врач может передать его позже)."""
    doctor_ids = db.scalars(select(User.id).where(User.role == "doctor", User.status == "approved")).all()
    if not doctor_ids:
        return None
    counts = {did: 0 for did in doctor_ids}
    for (did,) in db.execute(select(User.doctor_id).where(User.doctor_id.is_not(None))):
        if did in counts:
            counts[did] += 1
    return min(counts, key=counts.get)


def _device_label(request: Request) -> str:
    """Понятное имя устройства по User-Agent: «Chrome · Windows», «Safari · iPhone»."""
    # X-Device-Label — User-Agent браузера, который передаёт фронтенд (запрос к API делает сервер Streamlit)
    ua = request.headers.get("x-device-label") or request.headers.get("user-agent", "")
    browser = next((b for b in ("Edg", "OPR", "YaBrowser", "Chrome", "Firefox", "Safari") if b in ua), "Browser")
    browser = {"Edg": "Edge", "OPR": "Opera", "YaBrowser": "Yandex"}.get(browser, browser)
    system = next((o for o in ("Android", "iPhone", "iPad", "Windows", "Mac OS", "Linux") if o in ua), "")
    return f"{browser} · {system}".strip(" ·")[:120]


def _bind_device(db: Session, user: User, request: Request) -> str:
    """Проверка «одно устройство». Возвращает хэш устройства для токена или бросает 403 device_pending."""
    dh = device_hash(request.headers.get("x-device-id"))
    if not settings.device_binding:
        return dh
    devices = db.scalars(select(UserDevice).where(UserDevice.user_id == user.id)).all()
    mine = next((d for d in devices if d.device_hash == dh), None)
    approved = [d for d in devices if d.status == "approved"]
    if mine and mine.status == "approved":
        mine.last_seen = utcnow()
        db.commit()
        return dh
    if not approved:                      # самое первое устройство — одобряем сразу
        mine = mine or UserDevice(user_id=user.id, device_hash=dh)
        mine.status, mine.label, mine.last_seen = "approved", _device_label(request), utcnow()
        db.add(mine)
        db.commit()
        return dh
    if mine and mine.status == "revoked":
        raise HTTPException(403, "device_revoked")
    if not mine:                           # новое устройство -> вход в «ограниченном» режиме
        db.add(UserDevice(user_id=user.id, device_hash=dh, label=_device_label(request), status="pending"))
        db.commit()
        audit(db, "device_request", user.id, request=request)
    return dh


@router.post("/register", response_model=TokenOut)
def register(data: RegisterIn, request: Request, db: Session = Depends(get_db)):
    email = data.email.lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(409, "Email already registered")
    if data.role == "doctor":
        # hmac.compare_digest — сравнение кода за постоянное время
        if not data.invite_code or not hmac.compare_digest(data.invite_code, settings.doctor_invite_code):
            raise HTTPException(403, "Invalid doctor invite code")
    if settings.pinfl_required and data.role == "patient" and not data.pinfl:
        # в MVP ПИНФЛ необязателен; в рабочей версии (PINFL_REQUIRED=true) без него не регистрируем
        raise HTTPException(422, "PINFL is required")
    phone = normalize_phone(data.phone) if data.phone else None
    if data.phone and not phone:
        raise HTTPException(422, "Invalid phone number")

    user = User(email=email, password_hash=hash_password(data.password), first_name=data.first_name,
                last_name=data.last_name, age=data.age, gender=data.gender, role=data.role,
                # ТЗ: пациент после регистрации ЖДЁТ одобрения врача
                status="pending" if data.role == "patient" else "approved",
                phone_enc=encrypt(phone) if phone else None,
                pinfl_enc=encrypt(data.pinfl) if data.pinfl else None)
    if data.role == "patient":
        user.doctor_id = _least_loaded_doctor(db)
    db.add(user)
    db.commit()
    user.consent_at, user.consent_version = utcnow(), settings.consent_version
    db.commit()
    audit(db, "register", user.id, request=request, detail=data.role)
    audit(db, "consent", user.id, request=request, detail=settings.consent_version)
    # Устройство MIRA и история создаются при ОДОБРЕНИИ (routers/admin.py), а не сейчас
    dev = _bind_device(db, user, request)
    return TokenOut(access_token=create_token(user, dev), user=user_out(user, _dev_status(db, user, dev)))


@router.post("/login", response_model=TokenOut)
def login(request: Request, form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    """Форма OAuth2: username=email, password. Необязательный scope 'patient'/'doctor' проверяет роль."""
    email = form.username.lower().strip()
    key = f"{email}|{client_ip(request)}"
    # два счётчика: «email + IP» (5 попыток) и «только email» (20 попыток) — второй не даёт обойти
    # блокировку, подменяя IP
    wait = max(login_limiter.seconds_left(key), email_limiter.seconds_left(email))
    if wait:
        raise HTTPException(429, f"Too many attempts. Try again in {wait} s",
                            headers={"Retry-After": str(wait)})
    user = db.scalar(select(User).where(User.email == email))
    if not verify_password_or_dummy(form.password, user):
        login_limiter.fail(key)
        email_limiter.fail(email)
        audit(db, "login_fail", user.id if user else None, request=request, detail=email[:100])
        raise HTTPException(401, "Invalid email or password")
    if form.scopes and form.scopes[0] in ("patient", "doctor") and form.scopes[0] != user.role:
        raise HTTPException(403, f"This account is registered as {user.role}")
    login_limiter.reset(key)
    email_limiter.reset(email)
    dev = _bind_device(db, user, request)          # может бросить 403 device_pending
    user.last_login = utcnow()
    db.commit()
    audit(db, "login_ok", user.id, request=request)
    return TokenOut(access_token=create_token(user, dev), user=user_out(user, _dev_status(db, user, dev)))


# ======================================================================================
# Устройства
# ======================================================================================
@router.get("/devices")
def devices(request: Request, token: str = Depends(oauth2_scheme), user: User = Depends(get_user_any_status),
            db: Session = Depends(get_db)):
    cur = decode_token(token).get("dev")
    rows = db.scalars(select(UserDevice).where(UserDevice.user_id == user.id, UserDevice.status != "revoked")
                      .order_by(UserDevice.created_at))
    return [{"id": d.id, "label": d.label, "status": d.status, "current": d.device_hash == cur,
             "created_at": d.created_at.isoformat(), "last_seen": d.last_seen.isoformat()} for d in rows]


def _own_device(db: Session, user: User, device_id: int) -> UserDevice:
    d = db.get(UserDevice, device_id)
    if not d or d.user_id != user.id:
        raise HTTPException(404, "Device not found")
    return d


@router.post("/devices/{device_id}/approve")
def approve_device(device_id: int, request: Request, user: User = Depends(require_approved_device),
                   db: Session = Depends(get_db)):
    """Разрешить вход с нового устройства. Вызвать можно только С УЖЕ ПОДТВЕРЖДЁННОГО устройства
    (require_approved_device) — новое устройство не может одобрить само себя."""
    d = _own_device(db, user, device_id)
    d.status = "approved"
    db.commit()
    audit(db, "device_approve", user.id, request=request, detail=d.label)
    return {"ok": True}


@router.post("/devices/{device_id}/revoke")
def revoke_device(device_id: int, request: Request, token: str = Depends(oauth2_scheme),
                  user: User = Depends(require_approved_device), db: Session = Depends(get_db)):
    d = _own_device(db, user, device_id)
    if d.device_hash == decode_token(token).get("dev"):
        raise HTTPException(400, "Cannot revoke the current device")
    d.status = "revoked"
    db.commit()
    audit(db, "device_revoke", user.id, request=request, detail=d.label)
    return {"ok": True}


# ======================================================================================
# OneID
# ======================================================================================
@router.get("/oneid/url")
def oneid_url(role: str = "patient"):
    if not oneid.configured():
        return {"configured": False, "url": None}
    return {"configured": True, "url": oneid.authorize_url("doctor" if role == "doctor" else "patient")}


@router.post("/oneid/callback", response_model=TokenOut)
async def oneid_callback(data: OneIDCallbackIn, request: Request, db: Session = Depends(get_db)):
    """Завершение входа: проверяем state, меняем code на данные человека, находим или создаём аккаунт.
    Новый аккаунт через OneID — всегда ПАЦИЕНТ со статусом pending (врачом так стать нельзя)."""
    try:
        oneid.pop_state(data.state)
        info = await oneid.exchange(data.code)
    except (oneid.OneIDError, httpx.HTTPError) as e:
        audit(db, "oneid_fail", request=request, detail=str(e)[:100])
        raise HTTPException(400, "OneID sign-in failed")
    sub = oneid.subject(info["pin"])
    user = db.scalar(select(User).where(User.oneid_sub == sub))
    if not user:
        if not data.consent:
            raise HTTPException(422, "consent to personal data processing is required")
        email = info["email"] or f"oneid-{sub[:12]}@users.mira"
        if db.scalar(select(User).where(User.email == email)):
            raise HTTPException(409, "Email already registered — sign in with password and link OneID in settings")
        phone = normalize_phone(info["phone"]) if info["phone"] else None
        user = User(email=email, password_hash=hash_password(secrets.token_urlsafe(32)),   # пароль неизвестен никому
                    first_name=info["first_name"] or "—", last_name=info["last_name"] or "—", age=info["age"],
                    gender=info["gender"], role="patient", status="pending", oneid_sub=sub,
                    phone_enc=encrypt(phone) if phone else None, pinfl_enc=encrypt(info["pin"]),
                    consent_at=utcnow(), consent_version=settings.consent_version,
                    doctor_id=_least_loaded_doctor(db))
        db.add(user)
        db.commit()
        audit(db, "register_oneid", user.id, request=request)
    dev = _bind_device(db, user, request)
    user.last_login = utcnow()
    db.commit()
    audit(db, "login_oneid", user.id, request=request)
    return TokenOut(access_token=create_token(user, dev), user=user_out(user, _dev_status(db, user, dev)))


@router.post("/logout")
def logout(request: Request, token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    """Отзыв токена: даже если его украли, после выхода он бесполезен."""
    data = decode_token(token)
    revoke_token(db, data)
    audit(db, "logout", int(data["sub"]), request=request)
    return {"ok": True}


@router.get("/me", response_model=UserOut)
def me(user: User = Depends(get_user_any_status)):
    return user_out(user)


@router.put("/profile", response_model=UserOut)
def update_profile(data: ProfileIn, request: Request, user: User = Depends(require_approved_device),
                   db: Session = Depends(get_db)):
    if data.phone is not None:
        phone = normalize_phone(data.phone) if data.phone else None
        if data.phone and not phone:
            raise HTTPException(422, "Invalid phone number")
        user.phone_enc = encrypt(phone) if phone else None
    if data.pinfl is not None:
        user.pinfl_enc = encrypt(data.pinfl)
    db.commit()
    audit(db, "profile_update", user.id, request=request)
    return user_out(user)


@router.post("/password")
def change_password(data: PasswordChangeIn, request: Request, user: User = Depends(get_current_user),
                    db: Session = Depends(get_db)):
    if not verify_password(data.old_password, user.password_hash):
        raise HTTPException(400, "Old password is incorrect")
    problems = password_problems(data.new_password, user.email)
    if problems:
        raise HTTPException(422, "weak password: " + "; ".join(problems))
    user.password_hash = hash_password(data.new_password)
    db.commit()
    audit(db, "password_change", user.id, request=request)
    return {"ok": True}


def new_device_key() -> str:
    """Случайный ключ устройства (128 бит). secrets — криптографически стойкий генератор."""
    return secrets.token_hex(16)
