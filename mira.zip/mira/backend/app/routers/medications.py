"""
routers/medications.py — ЛЕКАРСТВА
=================================
GET    /api/medications            список назначений (+ расписание на сегодня + соблюдение режима)
POST   /api/medications            добавить лекарство/напоминание: врач — своему пациенту,
                                   пациент (или родственник с его аккаунта) — себе
PUT    /api/medications/{id}       изменить (врач — любое у своего пациента; пациент — только своё)
DELETE /api/medications/{id}       отменить — запись не удаляется, а деактивируется (история важна)

Зачем пациенту добавлять самому: у пожилых людей и людей с нарушениями памяти родственник
может сам завести напоминания — тогда SMS придёт на телефон пациента точно по времени.
POST   /api/medications/{id}/take  пациент отметил «принял» конкретную дозу
GET    /api/medications/sms-log    журнал SMS-напоминаний пациента (для врача и пациента)
"""
from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Medication, SmsLog, User
from ..schemas import MedicationIn, MedicationOut, TakeIn
from ..security import audit, decrypt, encrypt, get_current_user, require_patient, resolve_patient
from ..services import medications as svc

router = APIRouter(prefix="/api/medications", tags=["medications"])


def _out(m: Medication) -> MedicationOut:
    return MedicationOut(id=m.id, patient_id=m.patient_id, name=m.name, dose=m.dose, times=m.times,
                         start_date=m.start_date, end_date=m.end_date, is_antibiotic=m.is_antibiotic,
                         notes=decrypt(m.notes_enc) if m.notes_enc else None, sms_enabled=m.sms_enabled,
                         active=m.active, by_patient=m.created_by == m.patient_id)


def _own_med(db: Session, user: User, med_id: int) -> Medication:
    """Врач может менять назначения своих пациентов; пациент — только то, что добавил сам
    (назначение врача пациент отменить не может)."""
    m = db.get(Medication, med_id)
    if not m:
        raise HTTPException(404, "Medication not found")
    if user.role == "doctor":
        resolve_patient(user, m.patient_id, db)   # 404, если пациент не этого врача
    elif m.patient_id != user.id or m.created_by != user.id:
        raise HTTPException(403, "Only your doctor can change this prescription")
    return m


@router.get("")
def list_medications(patient_id: int | None = None, user: User = Depends(get_current_user),
                     db: Session = Depends(get_db)):
    p = resolve_patient(user, patient_id, db)
    meds = db.scalars(select(Medication).where(Medication.patient_id == p.id)
                      .order_by(Medication.active.desc(), Medication.created_at.desc())).all()
    return {"medications": [_out(m) for m in meds],
            "today": svc.day_schedule(db, p),
            "adherence": svc.adherence(db, p, 7)}


@router.post("", response_model=MedicationOut)
def create(data: MedicationIn, request: Request, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = resolve_patient(user, data.patient_id, db)
    doctor = user
    m = Medication(patient_id=p.id, created_by=user.id, name=data.name.strip(), dose=data.dose.strip(),
                   times=data.times, start_date=data.start_date or svc.local_today(), end_date=data.end_date,
                   is_antibiotic=data.is_antibiotic, notes_enc=encrypt(data.notes) if data.notes else None,
                   sms_enabled=data.sms_enabled)
    db.add(m)
    db.commit()
    audit(db, "med_prescribe", doctor.id, p.id, request, detail=m.name)
    return _out(m)


@router.put("/{med_id}", response_model=MedicationOut)
def update(med_id: int, data: MedicationIn, request: Request, doctor: User = Depends(get_current_user),
           db: Session = Depends(get_db)):
    m = _own_med(db, doctor, med_id)
    m.name, m.dose, m.times = data.name.strip(), data.dose.strip(), data.times
    m.start_date = data.start_date or m.start_date
    m.end_date, m.is_antibiotic, m.sms_enabled = data.end_date, data.is_antibiotic, data.sms_enabled
    m.notes_enc = encrypt(data.notes) if data.notes else None
    db.commit()
    audit(db, "med_update", doctor.id, m.patient_id, request, detail=m.name)
    return _out(m)


@router.delete("/{med_id}")
def deactivate(med_id: int, request: Request, doctor: User = Depends(get_current_user), db: Session = Depends(get_db)):
    m = _own_med(db, doctor, med_id)
    m.active = False
    if not m.end_date or m.end_date > svc.local_today():
        m.end_date = svc.local_today()
    db.commit()
    audit(db, "med_stop", doctor.id, m.patient_id, request, detail=m.name)
    return {"ok": True}


@router.post("/{med_id}/take")
def take(med_id: int, data: TakeIn, patient: User = Depends(require_patient), db: Session = Depends(get_db)):
    m = db.get(Medication, med_id)
    if not m or m.patient_id != patient.id:
        raise HTTPException(404, "Medication not found")
    sched = data.scheduled_at.replace(tzinfo=None, second=0, microsecond=0)
    # Отметить можно только реальную дозу из расписания (сегодня или вчера — если забыли отметить)
    today = svc.local_today()
    valid = set(svc.doses_for_day(m, today)) | set(svc.doses_for_day(m, date.fromordinal(today.toordinal() - 1)))
    if sched not in valid:
        raise HTTPException(422, "No such dose in the schedule")
    it = svc.mark_taken(db, patient, m, sched)
    return {"ok": True, "taken_at": it.taken_at.isoformat()}


@router.get("/sms-log")
def sms_log(patient_id: int | None = None, limit: int = 30, user: User = Depends(get_current_user),
            db: Session = Depends(get_db)):
    p = resolve_patient(user, patient_id, db)
    rows = db.scalars(select(SmsLog).where(SmsLog.user_id == p.id, SmsLog.purpose == "medication")
                      .order_by(SmsLog.ts.desc()).limit(min(limit, 200)))
    return [{"ts": r.ts.isoformat(), "status": r.status, "text": decrypt(r.body_enc)} for r in rows]

