"""
routers/notifications.py — ЕДИНЫЙ ЦЕНТР УВЕДОМЛЕНИЙ (колокольчик справа вверху)
=============================================================================
ТЗ: «сигналы и сообщения — в одном разделе, без повторов, чётко и структурированно».
Уведомления не хранятся отдельной таблицей — они СОБИРАЮТСЯ на лету из уже существующих
данных, поэтому не бывает рассинхронизации и дублей:

  ПАЦИЕНТ                               ВРАЧ
  • ответы и рекомендации врача         • тревоги пациентов (сгруппированы: пациент + показатель)
  • решения по записи к врачу           • новые заявки на регистрацию
  • напоминания о лекарствах сегодня    • заявки на приём
  • погода / воздух / совет «улица»     • новые сообщения от пациентов
  • устройство MIRA: батарея, связь     • запросы входа с нового устройства
  • запросы входа с нового устройства   • обновления MIRA
  • обновления MIRA
  Пациенту НИКОГДА не приходят тревоги о критическом состоянии (их видит только врач).

GET  /api/notifications?lang=ru   список (новые сверху) + число непрочитанных
POST /api/notifications/seen      отметить всё прочитанным
"""
from datetime import timedelta
from typing import Literal

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Alert, Appointment, MedicationIntake, Medication, Message, User, UserDevice, utcnow
from ..security import decrypt, get_user_any_status
from ..services import outdoor, weather
from ..services.medications import _utc_to_local

router = APIRouter(prefix="/api/notifications", tags=["notifications"])

RELEASE = ("2026-09-26T08:00:00", "2.2")    # последнее обновление портала (показывается как событие)

TXT = {
    "ru": {"msg": "Сообщение от врача", "rec": "Рекомендация врача", "sys": "Уведомление", "pmsg": "Сообщение от пациента",
           "rem": "Лекарство: {n} {d} в {t}", "rem_t": "Время приёма", "taken": "не отмечено",
           "bat": "Заряд устройства {v} % — поставьте на зарядку", "off": "Устройство не на связи",
           "dev": "Устройство", "sec": "Вход с нового устройства: {l}. Разрешить?", "sec_t": "Безопасность",
           "upd": "MIRA обновлена до версии {v}: уведомления, проверка личности, вход через OneID", "upd_t": "Обновление",
           "wx_t": "Погода сейчас", "wx": "{temp} °C, УФ {uv}, воздух AQI {aqi}. {adv}",
           "alert": "{p}: {m} = {v}", "alert_t": "Тревога", "appr": "Новых заявок на регистрацию: {n}",
           "appr_t": "Заявки", "appt": "{p} просит приём на {d}", "appt_t": "Запись к врачу"},
    "uz": {"msg": "Shifokordan xabar", "rec": "Shifokor tavsiyasi", "sys": "Bildirishnoma", "pmsg": "Bemordan xabar",
           "rem": "Dori: {n} {d}, soat {t}", "rem_t": "Qabul vaqti", "taken": "belgilanmagan",
           "bat": "Qurilma quvvati {v} % — zaryadlang", "off": "Qurilma aloqada emas",
           "dev": "Qurilma", "sec": "Yangi qurilmadan kirish: {l}. Ruxsat berasizmi?", "sec_t": "Xavfsizlik",
           "upd": "MIRA {v} versiyasiga yangilandi: bildirishnomalar, shaxsni tekshirish, OneID orqali kirish",
           "upd_t": "Yangilanish", "wx_t": "Hozirgi ob-havo", "wx": "{temp} °C, UB {uv}, havo AQI {aqi}. {adv}",
           "alert": "{p}: {m} = {v}", "alert_t": "Signal", "appr": "Ro'yxatdan o'tish arizalari: {n}",
           "appr_t": "Arizalar", "appt": "{p} {d} ga qabul so'ramoqda", "appt_t": "Qabulga yozilish"},
    "en": {"msg": "Message from your doctor", "rec": "Doctor's recommendation", "sys": "Notice",
           "pmsg": "Message from a patient", "rem": "Medicine: {n} {d} at {t}", "rem_t": "Time to take",
           "taken": "not marked", "bat": "Device battery {v} % — please charge", "off": "Device is offline",
           "dev": "Device", "sec": "Sign-in from a new device: {l}. Allow?", "sec_t": "Security",
           "upd": "MIRA updated to {v}: notifications, identity check, OneID sign-in", "upd_t": "Update",
           "wx_t": "Weather now", "wx": "{temp} °C, UV {uv}, air AQI {aqi}. {adv}",
           "alert": "{p}: {m} = {v}", "alert_t": "Alert", "appr": "New registration requests: {n}",
           "appr_t": "Approvals", "appt": "{p} requests an appointment on {d}", "appt_t": "Appointments"},
}
METRIC = {"heart_rate": "HR", "systolic": "SBP", "glucose": "Glu", "spo2": "SpO2", "resp_rate": "RR",
          "body_temp": "T", "diastolic": "DBP"}


def _item(key, kind, level, title, text, ts, page=None, action=None) -> dict:
    return {"key": key, "kind": kind, "level": level, "title": title, "text": text,
            "ts": ts.isoformat() if hasattr(ts, "isoformat") else ts, "page": page, "action": action}


async def _collect(db: Session, user: User, lang: str) -> list[dict]:
    T = TXT[lang]
    now = utcnow()
    since = now - timedelta(days=14)
    out: list[dict] = []

    # --- безопасность: запросы входа с нового устройства (у обеих ролей)
    for d in db.scalars(select(UserDevice).where(UserDevice.user_id == user.id, UserDevice.status == "pending")):
        out.append(_item(f"dev{d.id}", "security", "warning", T["sec_t"], T["sec"].format(l=d.label), d.created_at,
                         action={"type": "approve_device", "id": d.id}))

    if user.role == "patient":
        for m in db.scalars(select(Message).where(Message.receiver_id == user.id, Message.created_at > since,
                                                  Message.kind != "alert").order_by(Message.created_at.desc()).limit(20)):
            title = {"recommendation": T["rec"], "system": T["sys"]}.get(m.kind, T["msg"])
            out.append(_item(f"m{m.id}", "message", "info", title, decrypt(m.body_enc)[:220], m.created_at, "m_doctor"))
        # лекарства: напоминания, отправленные сегодня и ещё не отмеченные
        rows = db.execute(select(MedicationIntake, Medication).join(Medication, Medication.id == MedicationIntake.medication_id)
                          .where(MedicationIntake.patient_id == user.id, MedicationIntake.reminded_at.is_not(None),
                                 MedicationIntake.taken_at.is_(None),
                                 MedicationIntake.scheduled_at > now - timedelta(hours=12))).all()
        for it, med in rows:
            out.append(_item(f"r{it.id}", "reminder", "warning", T["rem_t"],
                             T["rem"].format(n=med.name, d=med.dose, t=_utc_to_local(it.scheduled_at).strftime("%H:%M")),
                             it.reminded_at, "m_meds"))
        # устройство
        dev = user.device
        if dev:
            if dev.battery < 20:
                out.append(_item("battery", "device", "warning", T["dev"], T["bat"].format(v=round(dev.battery)),
                                 dev.last_seen, "m_device"))
            if (now - dev.last_seen).total_seconds() > 300:
                out.append(_item("offline", "device", "warning", T["dev"], T["off"], dev.last_seen, "m_device"))
            # погода и совет «улица / маска» — один актуальный пункт, без повторов
            cond = await weather.current_conditions(dev.lat, dev.lon)
            adv = outdoor.decide({"age": user.age}, cond, lang)["title"]
            out.append(_item("weather", "weather", "info", T["wx_t"],
                             T["wx"].format(temp=round(cond["temp"]), uv=round(cond["uv"] or 0), aqi=cond["aqi"], adv=adv),
                             now.replace(minute=0, second=0, microsecond=0), "m_ai"))
    else:
        # тревоги пациентов за сутки — сгруппированы по (пациент, показатель): одна строка на инцидент
        rows = db.execute(select(Alert, User).join(User, User.id == Alert.user_id)
                          .where(User.doctor_id == user.id, Alert.ts > now - timedelta(hours=24),
                                 Alert.acknowledged.is_(False)).order_by(Alert.ts.desc())).all()
        seen = set()
        for a, p in rows:
            k = (p.id, a.metric)
            if k in seen:
                continue
            seen.add(k)
            out.append(_item(f"a{a.id}", "alert", a.level, T["alert_t"],
                             T["alert"].format(p=f"{p.first_name} {p.last_name}", m=METRIC.get(a.metric, a.metric),
                                               v=round(a.value, 1)), a.ts, "m_alerts"))
        pending = db.scalars(select(User).where(User.role == "patient", User.status == "pending",
                                                (User.doctor_id == user.id) | User.doctor_id.is_(None))).all()
        if pending:
            out.append(_item("approvals", "approval", "info", T["appr_t"], T["appr"].format(n=len(pending)),
                             max(p.created_at for p in pending), "m_approvals"))
        for ap, p in db.execute(select(Appointment, User).join(User, User.id == Appointment.patient_id)
                                .where(Appointment.doctor_id == user.id, Appointment.status == "requested")).all():
            out.append(_item(f"ap{ap.id}", "appointment", "info", T["appt_t"],
                             T["appt"].format(p=f"{p.first_name} {p.last_name}",
                                              d=_utc_to_local(ap.start).strftime("%d.%m %H:%M")), ap.created_at, "m_appts"))
        for m, p in db.execute(select(Message, User).join(User, User.id == Message.sender_id)
                               .where(Message.receiver_id == user.id, Message.kind == "message",
                                      Message.read.is_(False))).all():
            out.append(_item(f"m{m.id}", "message", "info", f"{T['pmsg']}: {p.first_name} {p.last_name}",
                             decrypt(m.body_enc)[:220], m.created_at, "m_messages"))

    out.append(_item("release", "update", "info", T["upd_t"], T["upd"].format(v=RELEASE[1]), RELEASE[0]))
    # уникальность по ключу + сортировка: новые сверху
    uniq = {i["key"]: i for i in out}
    return sorted(uniq.values(), key=lambda i: i["ts"], reverse=True)


@router.get("")
async def notifications(lang: Literal["ru", "uz", "en"] = "ru", user: User = Depends(get_user_any_status),
                        db: Session = Depends(get_db)):
    if user.device_status != "approved":
        # неподтверждённое устройство ничего не видит (ни сообщений врача, ни лекарств)
        return {"items": [], "unread": 0}
    items = await _collect(db, user, lang)
    seen = user.notif_seen_at.isoformat() if user.notif_seen_at else ""
    for i in items:
        i["unread"] = i["ts"] > seen
    return {"items": items, "unread": sum(i["unread"] for i in items)}


@router.post("/seen")
def mark_seen(user: User = Depends(get_user_any_status), db: Session = Depends(get_db)):
    user.notif_seen_at = utcnow()
    db.commit()
    return {"ok": True}
