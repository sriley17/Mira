"""
routers/measurements.py — ПОКАЗАТЕЛИ И ОТЧЁТЫ
============================================
GET /api/measurements/latest    последнее измерение
GET /api/measurements/history   сырые данные за период (для раздела «История»)
GET /api/measurements/report    отчёт за день / неделю / месяц (средние по часам или дням)
GET /api/measurements/alerts    тревоги пациента — ТОЛЬКО ДЛЯ ВРАЧА (пациенту 403, ТЗ: не пугать)

Отчёты строятся через pandas: resample("1h") группирует измерения по часам, ("1D") — по дням.
"""
from datetime import datetime, timedelta
from typing import Literal

import pandas as pd
from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import engine, get_db
from ..models import Alert, Measurement, User, utcnow
from ..schemas import AlertOut, MeasurementOut
from ..security import get_current_user, require_doctor, resolve_patient

router = APIRouter(prefix="/api/measurements", tags=["measurements"])

METRICS = ["heart_rate", "systolic", "diastolic", "glucose", "resp_rate", "spo2",
           "calories", "body_temp", "room_temp"]
PERIODS = {"day": (timedelta(days=1), "1h"), "week": (timedelta(days=7), "1D"),
           "month": (timedelta(days=30), "1D")}


def load_frame(patient_id: int, start: datetime, end: datetime) -> pd.DataFrame:
    q = (select(Measurement.ts, *[getattr(Measurement, m) for m in METRICS])
         .where(Measurement.user_id == patient_id, Measurement.ts >= start, Measurement.ts <= end)
         .order_by(Measurement.ts))
    with engine.connect() as conn:
        df = pd.read_sql(q, conn)
    df["ts"] = pd.to_datetime(df["ts"])
    return df


def build_report(patient_id: int, period: str) -> dict:
    span, freq = PERIODS[period]
    end = utcnow()
    df = load_frame(patient_id, end - span, end)
    if df.empty:
        return {"period": period, "rows": [], "summary": {}}
    g = df.set_index("ts").resample(freq)
    agg = g[[m for m in METRICS if m != "calories"]].mean().round(2)
    agg["calories"] = g["calories"].sum().round(0)
    agg = agg.dropna(how="all", subset=[m for m in METRICS if m != "calories"]).reset_index()
    summary = {}
    for m in METRICS:
        s = df[m]
        summary[m] = {"avg": round(float(s.mean()), 2), "min": round(float(s.min()), 2),
                      "max": round(float(s.max()), 2)}
    summary["calories"]["total"] = round(float(df["calories"].sum()), 0)
    agg["ts"] = agg["ts"].dt.strftime("%Y-%m-%dT%H:%M:%S")
    return {"period": period, "rows": agg.to_dict(orient="records"), "summary": summary}


@router.get("/latest", response_model=MeasurementOut | None)
def latest(patient_id: int | None = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = resolve_patient(user, patient_id, db)
    return db.scalar(select(Measurement).where(Measurement.user_id == p.id).order_by(Measurement.ts.desc()).limit(1))


@router.get("/history")
def history(start: datetime | None = None, end: datetime | None = None, limit: int = Query(2000, le=20000),
            patient_id: int | None = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = resolve_patient(user, patient_id, db)
    end = end or utcnow()
    start = start or end - timedelta(days=7)
    df = load_frame(p.id, start, end).tail(limit)
    df["ts"] = df["ts"].dt.strftime("%Y-%m-%dT%H:%M:%S")
    return df.round(2).to_dict(orient="records")


@router.get("/report")
def report(period: Literal["day", "week", "month"] = "day", patient_id: int | None = None,
           user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = resolve_patient(user, patient_id, db)
    return build_report(p.id, period)


@router.get("/alerts", response_model=list[AlertOut])
def alerts(patient_id: int, limit: int = Query(50, le=500), doctor: User = Depends(require_doctor),
           db: Session = Depends(get_db)):
    """Тревоги одного пациента. Пациент сюда не попадёт: require_doctor вернёт 403."""
    p = resolve_patient(doctor, patient_id, db)
    return db.scalars(select(Alert).where(Alert.user_id == p.id).order_by(Alert.ts.desc()).limit(limit)).all()
