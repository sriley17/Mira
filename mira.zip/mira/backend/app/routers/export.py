"""Export reports for the doctor: PDF and Excel."""
import io
from pathlib import Path
from typing import Literal

import pandas as pd
from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from fpdf import FPDF
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import User, utcnow
from ..security import get_current_user, resolve_patient
from .measurements import METRICS, build_report

router = APIRouter(prefix="/api/export", tags=["export"])
ASSETS = Path(__file__).resolve().parent.parent / "assets"

LABELS = {
    "ru": {"title": "Отчёт о здоровье MIRA", "patient": "Пациент", "age": "Возраст", "period": "Период",
           "generated": "Сформирован", "summary": "Сводка", "metric": "Показатель", "avg": "Среднее",
           "min": "Мин", "max": "Макс", "detail": "Детализация", "time": "Время",
           "day": "день", "week": "неделя", "month": "месяц",
           "m": {"heart_rate": "Пульс, уд/мин", "systolic": "Давл. сист.", "diastolic": "Давл. диаст.",
                 "glucose": "Сахар, ммоль/л", "resp_rate": "Дыхание, /мин", "spo2": "SpO₂, %",
                 "calories": "Калории, ккал", "body_temp": "Темп. тела, °C", "room_temp": "Темп. комнаты, °C"}},
    "uz": {"title": "MIRA salomatlik hisoboti", "patient": "Bemor", "age": "Yosh", "period": "Davr",
           "generated": "Tuzilgan", "summary": "Umumiy", "metric": "Ko'rsatkich", "avg": "O'rtacha",
           "min": "Min", "max": "Maks", "detail": "Batafsil", "time": "Vaqt",
           "day": "kun", "week": "hafta", "month": "oy",
           "m": {"heart_rate": "Puls, zarba/daq", "systolic": "Bosim sist.", "diastolic": "Bosim diast.",
                 "glucose": "Qand, mmol/l", "resp_rate": "Nafas, /daq", "spo2": "SpO₂, %",
                 "calories": "Kaloriya, kkal", "body_temp": "Tana harorati, °C", "room_temp": "Xona harorati, °C"}},
    "en": {"title": "MIRA Health Report", "patient": "Patient", "age": "Age", "period": "Period",
           "generated": "Generated", "summary": "Summary", "metric": "Metric", "avg": "Avg",
           "min": "Min", "max": "Max", "detail": "Details", "time": "Time",
           "day": "day", "week": "week", "month": "month",
           "m": {"heart_rate": "Heart rate, bpm", "systolic": "Systolic BP", "diastolic": "Diastolic BP",
                 "glucose": "Glucose, mmol/L", "resp_rate": "Respiration, /min", "spo2": "SpO₂, %",
                 "calories": "Calories, kcal", "body_temp": "Body temp, °C", "room_temp": "Room temp, °C"}},
}


@router.get("/xlsx")
def export_xlsx(period: Literal["day", "week", "month"] = "week", lang: Literal["ru", "uz", "en"] = "ru",
                patient_id: int | None = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = resolve_patient(user, patient_id, db)
    L = LABELS[lang]
    rep = build_report(p.id, period)
    detail = pd.DataFrame(rep["rows"]).rename(columns={"ts": L["time"], **L["m"]})
    summary = pd.DataFrame([{L["metric"]: L["m"][m], L["avg"]: v["avg"], L["min"]: v["min"], L["max"]: v["max"]}
                            for m, v in rep["summary"].items()])
    info = pd.DataFrame({"": [L["patient"], L["age"], L["period"], L["generated"]],
                         " ": [f"{p.first_name} {p.last_name}", p.age, L[period], utcnow().strftime("%Y-%m-%d %H:%M UTC")]})
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as xw:
        info.to_excel(xw, sheet_name=L["summary"], index=False)
        summary.to_excel(xw, sheet_name=L["summary"], index=False, startrow=6)
        detail.to_excel(xw, sheet_name=L["detail"], index=False)
        for ws in xw.book.worksheets:
            for col in ws.columns:
                ws.column_dimensions[col[0].column_letter].width = 20
    buf.seek(0)
    name = f"mira_{p.id}_{period}.xlsx"
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f'attachment; filename="{name}"'})


@router.get("/pdf")
def export_pdf(period: Literal["day", "week", "month"] = "week", lang: Literal["ru", "uz", "en"] = "ru",
               patient_id: int | None = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = resolve_patient(user, patient_id, db)
    L = LABELS[lang]
    rep = build_report(p.id, period)

    pdf = FPDF(orientation="L")
    pdf.add_font("DejaVu", "", str(ASSETS / "DejaVuSans.ttf"))
    pdf.add_font("DejaVu", "B", str(ASSETS / "DejaVuSans-Bold.ttf"))
    pdf.set_auto_page_break(True, margin=12)
    pdf.add_page()
    pdf.set_font("DejaVu", "B", 18)
    pdf.cell(0, 10, L["title"], new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("DejaVu", "", 10)
    pdf.cell(0, 6, f"{L['patient']}: {p.first_name} {p.last_name}   {L['age']}: {p.age}   "
                   f"{L['period']}: {L[period]}   {L['generated']}: {utcnow():%Y-%m-%d %H:%M} UTC",
             new_x="LMARGIN", new_y="NEXT")
    pdf.ln(4)

    pdf.set_font("DejaVu", "B", 12)
    pdf.cell(0, 8, L["summary"], new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("DejaVu", "", 9)
    with pdf.table(col_widths=(60, 30, 30, 30), width=150, align="LEFT", text_align=("LEFT", "RIGHT", "RIGHT", "RIGHT")) as t:
        t.row([L["metric"], L["avg"], L["min"], L["max"]])
        for m, v in rep["summary"].items():
            t.row([L["m"][m], str(v["avg"]), str(v["min"]), str(v["max"])])

    pdf.add_page()
    pdf.set_font("DejaVu", "B", 12)
    pdf.cell(0, 8, L["detail"], new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("DejaVu", "", 7)
    short = {m: L["m"][m].split(",")[0] for m in METRICS}
    with pdf.table(col_widths=(30,) + (20,) * len(METRICS), text_align="RIGHT") as t:
        t.row([L["time"]] + [short[m] for m in METRICS])
        for r in rep["rows"]:
            t.row([r["ts"].replace("T", " ")[:16]] + ["" if pd.isna(r.get(m)) else f"{r[m]:.1f}" for m in METRICS])

    data = bytes(pdf.output())
    name = f"mira_{p.id}_{period}.pdf"
    return StreamingResponse(io.BytesIO(data), media_type="application/pdf",
                             headers={"Content-Disposition": f'attachment; filename="{name}"'})
