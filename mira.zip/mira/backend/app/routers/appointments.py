"""
routers/appointments.py — ЗАПИСЬ К ВРАЧУ
======================================
GET  /api/appointments/slots?day=2026-09-28   свободное время врача на день
GET  /api/appointments                         мои записи (пациент) / все заявки (врач)
POST /api/appointments                         записаться (пациент). Занято -> 409 + варианты
POST /api/appointments/{id}/decision           врач: approved / declined (+ авто-предложения)
POST /api/appointments/{id}/cancel             пациент отменяет свою запись
"""
from datetime import date, timedelta

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Appointment, Message, User, utcnow
from ..schemas import AppointmentDecisionIn, AppointmentIn
from ..security import audit, decrypt, encrypt, get_current_user, require_doctor, require_patient
from ..services import appointments as svc
from ..services.medications import _utc_to_local
from ..services.ws_manager import doctor_channel, manager, patient_channel

router = APIRouter(prefix="/api/appointments", tags=["appointments"])


def _out(a: Appointment, names: dict[int, str]) -> dict:
    loc = _utc_to_local(a.start)
    return {"id": a.id, "patient_id": a.patient_id, "patient": names.get(a.patient_id, ""),
            "doctor_id": a.doctor_id, "doctor": names.get(a.doctor_id, ""),
            "start": a.start.isoformat(), "local_date": loc.date().isoformat(), "local_time": loc.strftime("%H:%M"),
            "minutes": a.minutes, "status": a.status,
            "reason": decrypt(a.reason_enc) if a.reason_enc else "",
            "doctor_note": decrypt(a.doctor_note_enc) if a.doctor_note_enc else ""}


def _doctor_of(user: User) -> int:
    if user.role == "doctor":
        return user.id
    if not user.doctor_id:
        raise HTTPException(400, "No doctor assigned yet")
    return user.doctor_id


@router.get("/slots")
def slots(day: date, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return {"day": day.isoformat(), "slots": svc.free_slots(db, _doctor_of(user), day)}


@router.get("")
def list_appointments(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    col = Appointment.doctor_id if user.role == "doctor" else Appointment.patient_id
    since = utcnow() - timedelta(days=30)
    rows = db.scalars(select(Appointment).where(col == user.id, Appointment.start >= since)
                      .order_by(Appointment.start)).all()
    ids = {r.patient_id for r in rows} | {r.doctor_id for r in rows}
    names = {u.id: f"{u.first_name} {u.last_name}" for u in db.scalars(select(User).where(User.id.in_(ids)))}
    out = [_out(r, names) for r in rows]
    if user.role == "patient":
        # рядом с отклонённой заявкой сразу показываем актуальное свободное время (ТЗ)
        for o, r in zip(out, rows):
            if r.status == "declined":
                o["suggestions"] = svc.suggest(db, r.doctor_id, r.start, n=3)
    return out


@router.post("")
async def book(data: AppointmentIn, request: Request, patient: User = Depends(require_patient),
               db: Session = Depends(get_db)):
    doctor_id = _doctor_of(patient)
    start = data.start.replace(tzinfo=None, second=0, microsecond=0)
    problem = svc.validate_slot(db, doctor_id, start)
    if problem:
        # 409 Conflict + сразу 3 свободных варианта — пациенту не нужно искать вручную
        return JSONResponse(status_code=409, content={"detail": problem,
                                                      "suggestions": svc.suggest(db, doctor_id, start)})
    a = Appointment(patient_id=patient.id, doctor_id=doctor_id, start=start, minutes=svc.SLOT_MIN,
                    reason_enc=encrypt(data.reason) if data.reason else None)
    db.add(a)
    db.commit()
    audit(db, "appt_request", patient.id, doctor_id, request)
    await manager.publish(doctor_channel(doctor_id), {"type": "appointment", "data": {"id": a.id}})
    return _out(a, {patient.id: f"{patient.first_name} {patient.last_name}"})


@router.post("/{appt_id}/decision")
async def decide(appt_id: int, data: AppointmentDecisionIn, request: Request,
                 doctor: User = Depends(require_doctor), db: Session = Depends(get_db)):
    a = db.get(Appointment, appt_id)
    if not a or a.doctor_id != doctor.id:
        raise HTTPException(404, "Appointment not found")
    if a.status != "requested":
        raise HTTPException(409, "Already decided")
    a.status = data.status
    a.doctor_note_enc = encrypt(data.note) if data.note else None
    suggestions = []
    loc = _utc_to_local(a.start)
    when = f"{loc:%d.%m.%Y %H:%M}"
    if data.status == "declined":
        db.flush()   # освобождаем слот, прежде чем искать свободное время
        suggestions = svc.suggest(db, doctor.id, a.start, n=3)
        alt = ", ".join(f"{s['date'][8:10]}.{s['date'][5:7]} {s['local']}" for s in suggestions) or "—"
        body = (f"Запись на {when} отклонена. Свободное время: {alt}. "
                f"/ {when} ga yozilish rad etildi. Bo'sh vaqt: {alt}.")
        if data.note:
            body += f"\n{data.note}"
    else:
        body = f"Запись на {when} подтверждена. / {when} ga yozilish tasdiqlandi."
    db.add(Message(sender_id=doctor.id, receiver_id=a.patient_id, kind="system", body_enc=encrypt(body)))
    db.commit()
    audit(db, f"appt_{data.status}", doctor.id, a.patient_id, request)
    await manager.publish(patient_channel(a.patient_id), {"type": "appointment", "data": {"id": a.id,
                                                                                            "status": a.status}})
    return {"ok": True, "status": a.status, "suggestions": suggestions}


@router.post("/{appt_id}/cancel")
def cancel(appt_id: int, patient: User = Depends(require_patient), db: Session = Depends(get_db)):
    a = db.get(Appointment, appt_id)
    if not a or a.patient_id != patient.id:
        raise HTTPException(404, "Appointment not found")
    if a.status in ("requested", "approved"):
        a.status = "cancelled"
        db.commit()
    return {"ok": True}
