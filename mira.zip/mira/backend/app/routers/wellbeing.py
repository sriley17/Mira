"""
routers/wellbeing.py — СОН, ЗАДАЧИ И ЦЕЛИ
========================================
GET    /api/sleep                  анализ сна за N ночей (+ погода и УФ)
GET    /api/goals                  цели (калории и сон) на сегодня + выполнение за неделю
PUT    /api/goals/{kind}           изменить цель: kind = calories | sleep

Анализ сна «тяжёлый» (pandas по тысячам строк), а за 5 минут последняя ночь не меняется,
поэтому результат кэшируется на 5 минут для каждого пациента — страница открывается мгновенно.
"""
import time
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import User
from ..schemas import GoalTargetIn
from ..security import get_current_user, resolve_patient
from ..services import goals as goals_svc
from ..services import sleep as sleep_svc

router = APIRouter(tags=["sleep-goals"])

_SLEEP_CACHE: dict[tuple[int, int], tuple[float, dict]] = {}
SLEEP_TTL = 300


async def sleep_for(patient: User, nights: int = 7) -> dict:
    """Анализ сна с кэшем. Используется и роутером, и ИИ-ассистентом."""
    key = (patient.id, nights)
    hit = _SLEEP_CACHE.get(key)
    if hit and time.time() - hit[0] < SLEEP_TTL:
        return hit[1]
    data = await sleep_svc.analyze(patient, nights)
    _SLEEP_CACHE[key] = (time.time(), data)
    return data


@router.get("/api/sleep")
async def sleep(nights: int = Query(7, ge=1, le=30), patient_id: int | None = None,
                user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = resolve_patient(user, patient_id, db)
    return await sleep_for(p, nights)


@router.get("/api/goals")
async def goals(patient_id: int | None = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Цели на сегодня + выполнение за 7 дней (для графика)."""
    p = resolve_patient(user, patient_id, db)
    sl = await sleep_for(p)
    s = sl.get("summary")
    return {"today": goals_svc.progress(db, p, s["last"]["hours"] if s else None),
            "history": goals_svc.history(db, p, sl.get("nights", []), 7)}


@router.put("/api/goals/{kind}")
def set_goal(kind: Literal["calories", "sleep"], data: GoalTargetIn, patient_id: int | None = None,
             user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Поменять целевое значение. Пациент — себе, врач — своему пациенту."""
    p = resolve_patient(user, patient_id, db)
    limits = {"calories": (200, 6000), "sleep": (4, 12)}      # разумные границы
    lo, hi = limits[kind]
    if not lo <= data.target <= hi:
        raise HTTPException(422, f"target must be between {lo} and {hi}")
    goals_svc.set_target(db, p.id, kind, data.target)
    return {"ok": True}
