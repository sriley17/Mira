"""
routers/ws.py — WEBSOCKET ДЛЯ ДАННЫХ В РЕАЛЬНОМ ВРЕМЕНИ
======================================================
Пациент:  ws://host/ws/live?token=JWT                 -> свои показатели, устройство, напоминания
Врач:     ws://host/ws/live?token=JWT&patient_id=5    -> показатели одного пациента
          ws://host/ws/live?token=JWT                 -> тревоги и события всех своих пациентов

Проверки при подключении (как и у обычных запросов):
  подпись и срок токена, токен не отозван (logout), пользователь одобрен,
  врач подписывается только на своих пациентов.
Код закрытия 4401 = «не авторизован» — фронтенд по нему понимает, что нужно войти заново.
"""
from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect

from ..database import SessionLocal
from ..models import User
from ..security import _user_from_token, decode_token, is_revoked, resolve_patient
from ..services.ws_manager import doctor_channel, manager, patient_channel

router = APIRouter()


@router.websocket("/ws/live")
async def live(ws: WebSocket, token: str, patient_id: int | None = None):
    try:
        data = decode_token(token)
        with SessionLocal() as db:
            if is_revoked(db, data):
                raise HTTPException(401)
            user, _ = _user_from_token(token, db)      # проверка устройства (отозвано -> 401)
            if user.device_status != "approved" or user.status != "approved" or user.identity_status != "verified":
                raise HTTPException(401)
            if user.role == "doctor" and patient_id is None:
                channel = doctor_channel(user.id)
            else:
                channel = patient_channel(resolve_patient(user, patient_id, db).id)
    except HTTPException:
        await ws.close(code=4401)
        return
    await ws.accept()
    await manager.subscribe(channel, ws)
    try:
        while True:
            await ws.receive_text()  # клиент шлёт ping, чтобы соединение не закрылось по таймауту
    except WebSocketDisconnect:
        pass
    finally:
        await manager.unsubscribe(ws)
