"""
routers/messages.py — «ОТВЕТЫ ВРАЧА»: переписка врач <-> пациент
Текст хранится зашифрованным (encrypt/decrypt). Пациент пишет только своему врачу,
врач — только своим пациентам. Новое сообщение сразу приходит по WebSocket.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Message, User
from ..schemas import MessageIn, MessageOut
from ..security import decrypt, encrypt, get_current_user
from ..services.ws_manager import manager, patient_channel, doctor_channel

router = APIRouter(prefix="/api/messages", tags=["messages"])


def _out(m: Message, names: dict[int, str]) -> MessageOut:
    return MessageOut(id=m.id, sender_id=m.sender_id, sender_name=names.get(m.sender_id, "?"),
                      receiver_id=m.receiver_id, body=decrypt(m.body_enc), kind=m.kind,
                      created_at=m.created_at, read=m.read)


@router.get("", response_model=list[MessageOut])
def list_messages(with_user: int | None = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    q = select(Message).where(or_(Message.receiver_id == user.id, Message.sender_id == user.id))
    if user.role == "patient":
        # сообщения kind="alert" система пишет врачу ОТ ИМЕНИ пациента — пациенту их не показываем
        q = q.where(Message.kind != "alert")
    if with_user:
        q = q.where(or_(Message.receiver_id == with_user, Message.sender_id == with_user))
    msgs = db.scalars(q.order_by(Message.created_at.desc()).limit(200)).all()
    ids = {m.sender_id for m in msgs}
    names = {u.id: f"{u.first_name} {u.last_name}" for u in db.scalars(select(User).where(User.id.in_(ids)))}
    changed = False
    for m in msgs:
        if m.receiver_id == user.id and not m.read:
            m.read = True
            changed = True
    out = [_out(m, names) for m in msgs]
    if changed:
        db.commit()
    return out


@router.post("", response_model=MessageOut)
async def send_message(data: MessageIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if user.role == "patient":
        receiver_id = user.doctor_id
        if not receiver_id:
            raise HTTPException(400, "No doctor assigned yet")
        kind = "message"
    else:
        patient = db.get(User, data.receiver_id) if data.receiver_id else None
        if not patient or patient.doctor_id != user.id:
            raise HTTPException(404, "Patient not found in your list")
        receiver_id, kind = patient.id, data.kind
    m = Message(sender_id=user.id, receiver_id=receiver_id, body_enc=encrypt(data.body), kind=kind)
    db.add(m)
    db.commit()
    channel = patient_channel(receiver_id) if user.role == "doctor" else doctor_channel(receiver_id)
    await manager.publish(channel, {"type": "message", "data": {"from": f"{user.first_name} {user.last_name}"}})
    return _out(m, {user.id: f"{user.first_name} {user.last_name}"})
