"""
routers/device.py — УСТРОЙСТВО MIRA И GPS
========================================
GET  /api/device               состояние устройства: батарея, связь, координаты, время обновления GPS
GET  /api/device/credentials   серийный номер и ключ — чтобы «прошить» настоящий браслет (только владелец)
POST /api/device/rotate-key    выпустить новый ключ (если старый мог утечь)
POST /api/device/ingest        приём измерений от настоящего устройства (ESP32 и т.п.)

Как устройство доказывает, что оно «своё»: в каждом запросе заголовки
    X-Device-Serial: MR-00002
    X-Device-Key:    <секретный ключ>
Ключ в базе хранится зашифрованным и сравнивается за постоянное время (device_key_matches).
Неверный ключ -> 401 и запись в журнал аудита.
"""
import secrets
from datetime import timedelta, timezone

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..database import get_db
from ..models import Device, User, utcnow
from ..schemas import DeviceOut, MeasurementIn
from ..security import (audit, decrypt, device_key_matches, encrypt, get_current_user, require_patient,
                        resolve_patient)
from ..services.ingest import ingest_reading

router = APIRouter(prefix="/api/device", tags=["device"])
settings = get_settings()
OFFLINE_AFTER = timedelta(seconds=60)   # нет сигнала минуту -> «не в сети»


@router.get("", response_model=DeviceOut | None)
def device_status(patient_id: int | None = None, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = resolve_patient(user, patient_id, db)
    d = p.device
    if not d:
        return None
    if d.connected and utcnow() - d.last_seen > OFFLINE_AFTER:
        d.connected = False
        db.commit()
    out = DeviceOut.model_validate(d)
    out.gps_interval_sec = settings.gps_update_sec
    return out


@router.get("/credentials")
def device_credentials(request: Request, user: User = Depends(require_patient), db: Session = Depends(get_db)):
    if not user.device:
        raise HTTPException(404, "No device")
    audit(db, "device_credentials", user.id, request=request)
    return {"serial": user.device.serial, "api_key": decrypt(user.device.api_key_enc)}


@router.post("/rotate-key")
def rotate_key(request: Request, user: User = Depends(require_patient), db: Session = Depends(get_db)):
    if not user.device:
        raise HTTPException(404, "No device")
    key = secrets.token_hex(16)
    user.device.api_key_enc = encrypt(key)
    db.commit()
    audit(db, "device_rotate_key", user.id, request=request)
    return {"serial": user.device.serial, "api_key": key}


@router.post("/ingest")
async def ingest(data: MeasurementIn, request: Request, x_device_serial: str = Header(max_length=50),
                 x_device_key: str = Header(max_length=128), db: Session = Depends(get_db)):
    """Эндпоинт для настоящего железа. Данные уже проверены схемой MeasurementIn (физические диапазоны)."""
    dev = db.scalar(select(Device).where(Device.serial == x_device_serial))
    if not dev or not device_key_matches(dev.api_key_enc, x_device_key):
        audit(db, "device_auth_fail", request=request, detail=x_device_serial[:50])
        raise HTTPException(401, "Unknown device")
    if dev.owner.status != "approved":
        raise HTTPException(403, "Patient is not approved yet")
    reading = data.model_dump()
    now = utcnow()
    # Время от устройства принимаем, только если оно правдоподобное (не из будущего и не старше суток)
    ts = reading["ts"]
    if ts is not None and ts.tzinfo is not None:
        ts = ts.astimezone(timezone.utc).replace(tzinfo=None)
    reading["ts"] = ts if ts and now - timedelta(days=1) <= ts <= now + timedelta(minutes=2) else now
    await ingest_reading(db, dev.owner, reading)
    return {"ok": True}
