"""
routers/identity.py — ПРОВЕРКА ЛИЧНОСТИ ПО ЛИЦУ (MyID) ПРИ ПЕРВОМ ВХОДЕ
=====================================================================
GET  /api/identity/status          пройдена ли проверка
POST /api/identity/verify          селфи с камеры (JPEG/PNG) -> MyID или демо-проверка (первый вход)
POST /api/identity/verify-device   подтвердить НОВОЕ устройство проверкой лица прямо на нём
                                   (раздел «Профиль» в ограниченном режиме)

Порядок в интерфейсе: сначала окно «Разрешите доступ к камере» с объяснением зачем,
затем браузер сам спрашивает разрешение, затем снимок -> этот эндпоинт.
Не более 5 попыток в час — защита от подбора чужим фото.
"""
import io
from datetime import timedelta

from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile
from PIL import Image, UnidentifiedImageError
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import IdentityCheck, User, UserDevice, utcnow
from ..security import audit, decrypt, encrypt_bytes, get_user_any_status
from ..services import myid

router = APIRouter(prefix="/api/identity", tags=["identity"])
MAX_ATTEMPTS_HOUR = 5


@router.get("/status")
def status(user: User = Depends(get_user_any_status)):
    return {"status": user.identity_status, "source": user.identity_source,
            "verified_at": user.identity_verified_at.isoformat() if user.identity_verified_at else None,
            "mode": "myid" if myid.configured() else "demo"}


async def _read_selfie(file: UploadFile) -> bytes:
    """Читает снимок, ограничивает размер и перекодирует в JPEG (без метаданных и «сюрпризов»)."""
    raw = await file.read(5 * 1024 * 1024 + 1)
    if len(raw) > 5 * 1024 * 1024:
        raise HTTPException(413, "Photo is larger than 5 MB")
    try:
        img = Image.open(io.BytesIO(raw)).convert("RGB")
        img.thumbnail((1024, 1024))
        buf = io.BytesIO()
        img.save(buf, "JPEG", quality=90)
    except (UnidentifiedImageError, OSError, ValueError):
        raise HTTPException(415, "File is not a valid image")
    return buf.getvalue()


def _check_attempts(db: Session, user: User) -> None:
    recent = db.scalar(select(func.count(IdentityCheck.id)).where(
        IdentityCheck.user_id == user.id, IdentityCheck.ts > utcnow() - timedelta(hours=1))) or 0
    if recent >= MAX_ATTEMPTS_HOUR:
        raise HTTPException(429, "Too many attempts, try again in an hour")


@router.post("/verify-device")
async def verify_device(request: Request, file: UploadFile = File(...), user: User = Depends(get_user_any_status),
                        db: Session = Depends(get_db)):
    """Новое устройство подтверждается лицом ВЛАДЕЛЬЦА аккаунта: кто просто узнал пароль,
    не пройдёт проверку MyID и ничего не увидит. Успех -> устройство становится approved."""
    if user.device_status == "approved":
        return {"result": "verified"}
    _check_attempts(db, user)
    jpeg = await _read_selfie(file)
    pinfl = decrypt(user.pinfl_enc) if user.pinfl_enc else None
    res = await myid.verify(jpeg, pinfl)
    db.add(IdentityCheck(user_id=user.id, source=res["source"], result=res["result"], score=res["score"],
                         reason=("device: " + (res["reason"] or ""))[:120], selfie_enc=encrypt_bytes(jpeg)))
    if res["result"] == "verified":
        dev = db.scalar(select(UserDevice).where(UserDevice.user_id == user.id,
                                                 UserDevice.device_hash == user.device_hash))
        if dev and dev.status == "pending":
            dev.status = "approved"
    db.commit()
    audit(db, f"device_face_{res['result']}", user.id, request=request, detail=res["source"])
    return {"result": res["result"], "source": res["source"], "reason": res["reason"]}


@router.post("/verify")
async def verify(request: Request, file: UploadFile = File(...), user: User = Depends(get_user_any_status),
                 db: Session = Depends(get_db)):
    if user.identity_status == "verified":
        return {"result": "verified", "source": user.identity_source}
    if user.device_status != "approved":
        raise HTTPException(403, "device_pending")   # первичную проверку — только с подтверждённого устройства
    _check_attempts(db, user)
    jpeg = await _read_selfie(file)
    pinfl = decrypt(user.pinfl_enc) if user.pinfl_enc else None
    res = await myid.verify(jpeg, pinfl)
    db.add(IdentityCheck(user_id=user.id, source=res["source"], result=res["result"], score=res["score"],
                         reason=res["reason"], selfie_enc=encrypt_bytes(jpeg)))
    if res["result"] == "verified":
        user.identity_status, user.identity_source, user.identity_verified_at = "verified", res["source"], utcnow()
    db.commit()
    audit(db, f"identity_{res['result']}", user.id, request=request, detail=res["source"])
    return {"result": res["result"], "source": res["source"], "reason": res["reason"]}
