"""
routers/admin.py — ПАНЕЛЬ ВРАЧА
==============================
Доступ только для врача (зависимость require_doctor).

GET    /api/admin/patients               мои пациенты + последние показатели + статус риска
GET    /api/admin/pending                 заявки пациентов, ожидающие одобрения
POST   /api/admin/patients/{id}/approve   одобрить (пациент получает устройство и доступ)
POST   /api/admin/patients/{id}/reject    отклонить
GET    /api/admin/unassigned              одобренные пациенты без врача
POST   /api/admin/patients/assign         взять пациента по email
DELETE /api/admin/patients/{id}           открепить пациента
GET    /api/admin/alerts                  тревоги всех моих пациентов (ТОЛЬКО врач их видит)
POST   /api/admin/alerts/{id}/ack         отметить тревогу «принято»
GET    /api/admin/audit                   журнал действий по моим пациентам
"""
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Alert, AuditLog, Measurement, Message, User, utcnow
from ..schemas import AssignIn, DecisionIn
from ..security import audit, encrypt, require_doctor
from ..services.patients import activate_patient
from ..services.thresholds import classify
from ..services.ws_manager import manager, patient_channel

router = APIRouter(prefix="/api/admin", tags=["doctor-admin"])


def _own_or_unassigned(db: Session, doctor: User, patient_id: int) -> User:
    """Заявку может рассмотреть врач, к которому пациент распределён, или любой врач, если врача нет."""
    p = db.get(User, patient_id)
    if not p or p.role != "patient" or p.doctor_id not in (None, doctor.id):
        raise HTTPException(404, "Patient not found")
    return p


@router.get("/patients")
def patients(doctor: User = Depends(require_doctor), db: Session = Depends(get_db)):
    out = []
    since = utcnow() - timedelta(hours=24)
    for p in db.scalars(select(User).where(User.doctor_id == doctor.id, User.status == "approved")
                        .order_by(User.last_name)):
        m = db.scalar(select(Measurement).where(Measurement.user_id == p.id).order_by(Measurement.ts.desc()).limit(1))
        crit = db.scalar(select(func.count(Alert.id)).where(Alert.user_id == p.id, Alert.level == "critical",
                                                             Alert.ts > since)) or 0
        status = "normal"
        if m:
            levels = [classify(k, getattr(m, k)) for k in ("heart_rate", "systolic", "glucose", "spo2", "body_temp")]
            status = "critical" if "critical" in levels else "warning" if "warning" in levels else "normal"
        d = p.device
        out.append({
            "id": p.id, "name": f"{p.first_name} {p.last_name}", "email": p.email, "age": p.age,
            "gender": p.gender, "status": status, "critical_24h": crit,
            "heart_rate": round(m.heart_rate) if m else None,
            "bp": f"{m.systolic:.0f}/{m.diastolic:.0f}" if m else None,
            "glucose": round(m.glucose, 1) if m else None,
            "last_reading": m.ts.isoformat() if m else None,
            "battery": round(d.battery) if d else None,
            "device_online": bool(d and utcnow() - d.last_seen < timedelta(seconds=60)),
        })
    return out


@router.get("/pending")
def pending(doctor: User = Depends(require_doctor), db: Session = Depends(get_db)):
    rows = db.scalars(select(User).where(User.role == "patient", User.status == "pending",
                                         or_(User.doctor_id == doctor.id, User.doctor_id.is_(None)))
                      .order_by(User.created_at))
    return [{"id": p.id, "name": f"{p.first_name} {p.last_name}", "email": p.email, "age": p.age,
             "gender": p.gender, "created_at": p.created_at.isoformat(), "has_phone": bool(p.phone_enc)} for p in rows]


@router.post("/patients/{patient_id}/approve")
async def approve(patient_id: int, request: Request, doctor: User = Depends(require_doctor),
                  db: Session = Depends(get_db)):
    p = _own_or_unassigned(db, doctor, patient_id)
    if p.status == "approved":
        return {"ok": True}
    p.doctor_id = doctor.id
    activate_patient(db, p)
    db.add(Message(sender_id=doctor.id, receiver_id=p.id, kind="system",
                   body_enc=encrypt("Регистрация подтверждена. Добро пожаловать в MIRA! / "
                                    "Ro'yxatdan o'tish tasdiqlandi. MIRA ga xush kelibsiz!")))
    db.commit()
    audit(db, "approve_patient", doctor.id, p.id, request)
    await manager.publish(patient_channel(p.id), {"type": "status", "data": {"status": "approved"}})
    return {"ok": True}


@router.post("/patients/{patient_id}/reject")
def reject(patient_id: int, data: DecisionIn, request: Request, doctor: User = Depends(require_doctor),
           db: Session = Depends(get_db)):
    p = _own_or_unassigned(db, doctor, patient_id)
    p.status = "rejected"
    db.commit()
    audit(db, "reject_patient", doctor.id, p.id, request, detail=(data.reason or "")[:200])
    return {"ok": True}


@router.get("/unassigned")
def unassigned(doctor: User = Depends(require_doctor), db: Session = Depends(get_db)):
    return [{"id": p.id, "name": f"{p.first_name} {p.last_name}", "email": p.email}
            for p in db.scalars(select(User).where(User.role == "patient", User.status == "approved",
                                                   User.doctor_id.is_(None)))]


@router.post("/patients/assign")
def assign(data: AssignIn, request: Request, doctor: User = Depends(require_doctor), db: Session = Depends(get_db)):
    p = db.scalar(select(User).where(User.email == data.email.lower(), User.role == "patient"))
    # Чужого пациента «перехватить» нельзя — только свободного
    if not p or p.doctor_id not in (None, doctor.id):
        raise HTTPException(404, "Patient with this email not found or already has a doctor")
    p.doctor_id = doctor.id
    db.commit()
    audit(db, "assign_patient", doctor.id, p.id, request)
    return {"ok": True, "id": p.id}


@router.delete("/patients/{patient_id}")
def unassign(patient_id: int, request: Request, doctor: User = Depends(require_doctor), db: Session = Depends(get_db)):
    p = db.get(User, patient_id)
    if not p or p.doctor_id != doctor.id:
        raise HTTPException(404, "Patient not found in your list")
    p.doctor_id = None
    db.commit()
    audit(db, "unassign_patient", doctor.id, p.id, request)
    return {"ok": True}


@router.get("/alerts")
def all_alerts(limit: int = 50, patient_id: int | None = None, doctor: User = Depends(require_doctor),
               db: Session = Depends(get_db)):
    q = select(Alert, User).join(User, User.id == Alert.user_id).where(User.doctor_id == doctor.id)
    if patient_id:
        q = q.where(User.id == patient_id)
    rows = db.execute(q.order_by(Alert.ts.desc()).limit(min(limit, 500))).all()
    return [{"id": a.id, "patient_id": u.id, "patient": f"{u.first_name} {u.last_name}", "ts": a.ts.isoformat(),
             "metric": a.metric, "value": round(a.value, 1), "level": a.level, "lat": a.lat, "lon": a.lon,
             "ambulance_called": a.ambulance_called, "acknowledged": a.acknowledged} for a, u in rows]


@router.post("/alerts/{alert_id}/ack")
def ack_alert(alert_id: int, request: Request, doctor: User = Depends(require_doctor), db: Session = Depends(get_db)):
    a = db.get(Alert, alert_id)
    p = db.get(User, a.user_id) if a else None
    if not a or not p or p.doctor_id != doctor.id:
        raise HTTPException(404, "Alert not found")
    a.acknowledged = True
    db.commit()
    audit(db, "ack_alert", doctor.id, p.id, request, detail=f"alert {a.id}")
    return {"ok": True}


@router.get("/audit")
def audit_log(limit: int = 100, doctor: User = Depends(require_doctor), db: Session = Depends(get_db)):
    """Журнал: действия самого врача и события его пациентов (входы и т.п.)."""
    ids = [doctor.id, *db.scalars(select(User.id).where(User.doctor_id == doctor.id))]
    rows = db.scalars(select(AuditLog).where(or_(AuditLog.user_id.in_(ids), AuditLog.target_id.in_(ids)))
                      .order_by(AuditLog.ts.desc()).limit(min(limit, 500)))
    names = {u.id: f"{u.first_name} {u.last_name}" for u in db.scalars(select(User).where(User.id.in_(ids)))}
    return [{"ts": r.ts.isoformat(), "user": names.get(r.user_id, r.user_id), "action": r.action,
             "target": names.get(r.target_id, r.target_id), "ip": r.ip, "detail": r.detail} for r in rows]
