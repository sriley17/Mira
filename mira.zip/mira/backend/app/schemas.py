"""
schemas.py — ФОРМАТЫ ДАННЫХ API (Pydantic)
=========================================
Схема описывает, какие поля принимает и отдаёт API и каких они типов.
FastAPI проверяет каждый входящий запрос по схеме АВТОМАТИЧЕСКИ: неверный email, слишком
короткий пароль, возраст 500 лет — вернётся ошибка 422 ещё до того, как код эндпоинта выполнится.
Это первая линия защиты от мусорных и вредоносных данных.

Схемы *In  — то, что присылает клиент.
Схемы *Out — то, что отдаёт сервер (лишние поля, например password_hash, наружу не попадают).
"""
from datetime import date, datetime
from typing import Literal

from pydantic import BaseModel, EmailStr, Field, field_validator, model_validator

from .security import password_problems

Lang = Literal["ru", "uz", "en"]


# ======================================================================================
# Регистрация и вход
# ======================================================================================
class RegisterIn(BaseModel):
    first_name: str = Field(min_length=1, max_length=100)
    last_name: str = Field(min_length=1, max_length=100)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    age: int = Field(ge=1, le=120)
    gender: Literal["male", "female"]
    role: Literal["patient", "doctor"]
    phone: str | None = Field(default=None, max_length=32)      # для SMS-напоминаний
    pinfl: str | None = Field(default=None, pattern=r"^\d{14}$")  # ПИНФЛ — 14 цифр (для Dmed)
    # Врачей нельзя регистрировать кому угодно: нужен код приглашения клиники (DOCTOR_INVITE_CODE)
    invite_code: str | None = Field(default=None, max_length=64)
    # Согласие на обработку персональных и медицинских данных (окно при регистрации). Без него — 422.
    consent: bool = Field(default=False, validate_default=True)

    @field_validator("consent")
    @classmethod
    def _consent_required(cls, v: bool) -> bool:
        if not v:
            raise ValueError("consent to personal data processing is required")
        return v

    @field_validator("first_name", "last_name")
    @classmethod
    def _clean_name(cls, v: str) -> str:
        """Убираем пробелы по краям и запрещаем символы разметки (<, >) — защита от XSS."""
        v = v.strip()
        if not v or any(ch in v for ch in "<>{}"):
            raise ValueError("invalid characters in name")
        return v

    @model_validator(mode="after")
    def _check_password(self):
        """Политика паролей из security.py: длина, буквы + цифры, не совпадает с email."""
        problems = password_problems(self.password, str(self.email))
        if problems:
            raise ValueError("weak password: " + "; ".join(problems))
        return self


class UserOut(BaseModel):
    """Данные пользователя для интерфейса. Телефон — только маскированный."""
    model_config = {"from_attributes": True}
    id: int
    email: str
    first_name: str
    last_name: str
    age: int
    gender: str
    role: str
    status: str
    doctor_id: int | None = None
    phone_masked: str | None = None
    identity_status: str = "none"          # none / verified — пройдена ли проверка лица (MyID)
    device_status: str = "approved"        # approved / pending — подтверждено ли ЭТО устройство


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class ProfileIn(BaseModel):
    """Пациент может обновить телефон (для SMS) и ПИНФЛ (для Dmed)."""
    phone: str | None = Field(default=None, max_length=32)
    pinfl: str | None = Field(default=None, pattern=r"^\d{14}$")


class PasswordChangeIn(BaseModel):
    old_password: str
    new_password: str = Field(min_length=8, max_length=128)


# ======================================================================================
# Измерения, сообщения, устройство
# ======================================================================================
class MeasurementIn(BaseModel):
    """Одно измерение от устройства. Диапазоны — физически возможные значения
    (защита от «мусора» и поддельных данных; клинические нормы — в thresholds.py)."""
    heart_rate: float = Field(ge=20, le=250)
    systolic: float = Field(ge=50, le=260)
    diastolic: float = Field(ge=30, le=180)
    glucose: float = Field(ge=1, le=35)
    resp_rate: float = Field(ge=4, le=60)
    spo2: float = Field(default=98, ge=50, le=100)
    calories: float = Field(default=0, ge=0, le=500)
    body_temp: float = Field(ge=30, le=43)
    room_temp: float = Field(ge=-20, le=50)
    ts: datetime | None = None
    lat: float | None = Field(default=None, ge=-90, le=90)
    lon: float | None = Field(default=None, ge=-180, le=180)
    battery: float | None = Field(default=None, ge=0, le=100)


class MeasurementOut(MeasurementIn):
    model_config = {"from_attributes": True}
    id: int
    user_id: int
    ts: datetime


class MessageIn(BaseModel):
    body: str = Field(min_length=1, max_length=4000)
    receiver_id: int | None = None  # врач -> пациент; пациент -> своему врачу (если не указано)
    kind: Literal["message", "recommendation"] = "message"


class MessageOut(BaseModel):
    id: int
    sender_id: int
    sender_name: str
    receiver_id: int
    body: str
    kind: str
    created_at: datetime
    read: bool


class DeviceOut(BaseModel):
    model_config = {"from_attributes": True}
    serial: str
    battery: float
    connected: bool
    lat: float
    lon: float
    firmware: str
    last_seen: datetime
    gps_updated: datetime | None = None
    gps_interval_sec: int = 3600


class AlertOut(BaseModel):
    model_config = {"from_attributes": True}
    id: int
    user_id: int
    ts: datetime
    metric: str
    value: float
    level: str
    ambulance_called: bool
    acknowledged: bool
    lat: float | None
    lon: float | None


# ======================================================================================
# ИИ
# ======================================================================================
class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=2000)
    lang: Lang = "ru"
    patient_id: int | None = None  # врач: по какому пациенту работает аналитик


class ChatOut(BaseModel):
    role: str
    body: str
    created_at: datetime


# ======================================================================================
# Врач: управление пациентами
# ======================================================================================
class AssignIn(BaseModel):
    email: EmailStr


class DecisionIn(BaseModel):
    reason: str | None = Field(default=None, max_length=500)


# ======================================================================================
# Лекарства
# ======================================================================================
class MedicationIn(BaseModel):
    patient_id: int | None = None   # врач указывает пациента; пациент добавляет напоминание себе
    name: str = Field(min_length=2, max_length=120)
    dose: str = Field(min_length=1, max_length=60)
    times: str = Field(min_length=4, max_length=120, examples=["08:00,20:00"])
    start_date: date | None = None
    end_date: date | None = None
    is_antibiotic: bool = False
    notes: str | None = Field(default=None, max_length=300)
    sms_enabled: bool = True

    @field_validator("times")
    @classmethod
    def _times(cls, v: str) -> str:
        """Проверяем и нормализуем формат: '8:0, 20:00' -> '08:00,20:00'."""
        from .services.medications import parse_times
        try:
            return ",".join(t.strftime("%H:%M") for t in parse_times(v))
        except (ValueError, TypeError):
            raise ValueError("times must look like 08:00,20:00")

    @model_validator(mode="after")
    def _dates(self):
        if self.is_antibiotic and not self.end_date:
            raise ValueError("antibiotic course needs end_date")
        if self.start_date and self.end_date and self.end_date < self.start_date:
            raise ValueError("end_date is before start_date")
        return self


class MedicationOut(BaseModel):
    id: int
    patient_id: int
    name: str
    dose: str
    times: str
    start_date: date
    end_date: date | None
    is_antibiotic: bool
    notes: str | None
    sms_enabled: bool
    active: bool
    by_patient: bool = False      # True — напоминание добавил сам пациент (или его родственник)


class TakeIn(BaseModel):
    scheduled_at: datetime  # UTC-время дозы (из расписания)


# ======================================================================================
# Цели
# ======================================================================================
class GoalTargetIn(BaseModel):
    """Новая цель: ккал в день (для calories) или часы сна (для sleep)."""
    target: float = Field(gt=0, le=10_000)


# ======================================================================================
# Запись к врачу
# ======================================================================================
class AppointmentIn(BaseModel):
    start: datetime                     # UTC (фронтенд переводит из местного времени)
    reason: str | None = Field(default=None, max_length=500)


class AppointmentDecisionIn(BaseModel):
    status: Literal["approved", "declined"]
    note: str | None = Field(default=None, max_length=500)


class OneIDCallbackIn(BaseModel):
    code: str = Field(min_length=4, max_length=512)
    state: str = Field(min_length=8, max_length=128)
    consent: bool = False
