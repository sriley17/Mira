"""
database.py — ПОДКЛЮЧЕНИЕ К БАЗЕ ДАННЫХ
======================================
engine        — «двигатель»: пул соединений с БД (PostgreSQL или SQLite).
SessionLocal  — фабрика сессий. Сессия = одна «беседа» с БД в рамках запроса.
Base          — базовый класс для всех таблиц (models.py).
get_db()      — зависимость FastAPI: открывает сессию на время запроса и гарантированно закрывает.
"""
from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from .config import get_settings

settings = get_settings()
IS_SQLITE = settings.database_url.startswith("sqlite")

# SQLite по умолчанию запрещает использовать соединение из другого потока,
# а FastAPI обрабатывает запросы в пуле потоков — поэтому снимаем ограничение.
connect_args = {"check_same_thread": False, "timeout": 30} if IS_SQLITE else {}

# pool_pre_ping — перед использованием соединения проверяем, что оно живое
# (PostgreSQL может закрыть простаивающее соединение).
engine = create_engine(settings.database_url, connect_args=connect_args, pool_pre_ping=True)

if IS_SQLITE:
    @event.listens_for(engine, "connect")
    def _sqlite_pragmas(conn, _):
        """Настройки SQLite для скорости и надёжности:
        WAL          — чтение не ждёт записи (симулятор пишет каждые 2 с, а интерфейс читает);
        synchronous  — NORMAL: быстрее FULL, при этом база не портится при сбое;
        foreign_keys — включаем проверку внешних ключей (в SQLite по умолчанию выключена)."""
        cur = conn.cursor()
        cur.execute("PRAGMA journal_mode=WAL")
        cur.execute("PRAGMA synchronous=NORMAL")
        cur.execute("PRAGMA foreign_keys=ON")
        cur.close()

# expire_on_commit=False — после commit объекты остаются читаемыми без нового запроса в БД
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


class Base(DeclarativeBase):
    """Все модели наследуются от Base — так SQLAlchemy знает, какие таблицы создавать."""


def get_db():
    """Зависимость FastAPI. `yield` отдаёт сессию в эндпоинт, `finally` закрывает её
    даже если в эндпоинте произошла ошибка — соединения не «утекают»."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
