"""
migrations.py — АВТОМАТИЧЕСКОЕ ОБНОВЛЕНИЕ СТРУКТУРЫ БАЗЫ
=======================================================
Проблема: у вас уже есть база mira.db от прошлой версии. В новой версии появились
новые колонки (status, phone_enc, api_key_enc...). create_all() создаёт только НОВЫЕ
таблицы, но не добавляет колонки в существующие.

Решение (простое и безопасное для демо):
1. Сравниваем колонки в моделях и в реальной базе; недостающие добавляем через ALTER TABLE.
2. «Переносим» старые данные: открытый телефон -> зашифрованный phone_enc,
   открытый ключ устройства -> api_key_enc. После переноса удаляем старые открытые колонки,
   чтобы в базе не оставалось незашифрованных данных.

Для большого продакшена используют Alembic (версионные миграции) — здесь та же идея,
только автоматически и без отдельных файлов.
"""
import logging

from sqlalchemy import inspect, text

from .database import IS_SQLITE, Base, engine
from .security import encrypt

log = logging.getLogger("mira.migrate")


def _sql_default(column) -> str:
    """DEFAULT для новой колонки: берём простое значение из модели (строка/число/bool)."""
    d = column.default
    if d is None or not getattr(d, "is_scalar", False):
        return ""
    v = d.arg
    if isinstance(v, bool):
        return f" DEFAULT {1 if v else 0}"
    if isinstance(v, (int, float)):
        return f" DEFAULT {v}"
    if isinstance(v, str):
        return " DEFAULT '" + v.replace("'", "''") + "'"
    return ""


def add_missing_columns() -> list[str]:
    """Шаг 1: для каждой таблицы из моделей добавляет колонки, которых нет в базе."""
    insp = inspect(engine)
    existing_tables = set(insp.get_table_names())
    added = []
    with engine.begin() as conn:
        for table in Base.metadata.sorted_tables:
            if table.name not in existing_tables:
                continue  # новую таблицу целиком создаст create_all()
            have = {c["name"] for c in insp.get_columns(table.name)}
            for col in table.columns:
                if col.name in have:
                    continue
                col_type = col.type.compile(dialect=engine.dialect)
                # Колонку добавляем как допускающую NULL — иначе ALTER не сработает на
                # таблице, где уже есть строки. Значение по умолчанию подставляется сразу.
                conn.execute(text(f'ALTER TABLE {table.name} ADD COLUMN "{col.name}" {col_type}{_sql_default(col)}'))
                added.append(f"{table.name}.{col.name}")
    if added:
        log.info("Добавлены колонки: %s", ", ".join(added))
    return added


def _drop_column(conn, table: str, column: str) -> None:
    """Удаление старой колонки. SQLite умеет DROP COLUMN с версии 3.35 (2021)."""
    try:
        conn.execute(text(f'ALTER TABLE {table} DROP COLUMN "{column}"'))
    except Exception as e:  # noqa: BLE001
        # Если СУБД слишком старая — очищаем значения, чтобы открытых данных не осталось
        log.warning("Не удалось удалить %s.%s (%s) — значения очищены", table, column, e)
        conn.execute(text(f'UPDATE {table} SET "{column}" = NULL'))


def migrate_legacy_plaintext() -> None:
    """Шаг 2: шифруем данные, которые старая версия хранила открыто."""
    insp = inspect(engine)
    tables = set(insp.get_table_names())
    with engine.begin() as conn:
        if "users" in tables and "phone" in {c["name"] for c in insp.get_columns("users")}:
            rows = conn.execute(text("SELECT id, phone FROM users WHERE phone IS NOT NULL AND phone <> ''")).all()
            for uid, phone in rows:
                conn.execute(text("UPDATE users SET phone_enc = :p WHERE id = :i"), {"p": encrypt(phone), "i": uid})
            _drop_column(conn, "users", "phone")
            log.info("Телефоны зашифрованы: %d", len(rows))
        if "devices" in tables and "api_key" in {c["name"] for c in insp.get_columns("devices")}:
            rows = conn.execute(text("SELECT id, api_key FROM devices")).all()
            for did, key in rows:
                conn.execute(text("UPDATE devices SET api_key_enc = :k WHERE id = :i"), {"k": encrypt(key), "i": did})
            _drop_column(conn, "devices", "api_key")
            log.info("Ключи устройств зашифрованы: %d", len(rows))
        # Версия 2.1: целей только две — калории и сон; прочие (вода, шаги) отключаем
        if "goals" in tables:
            conn.execute(text("UPDATE goals SET active = 0 WHERE kind NOT IN ('calories', 'sleep')"))
        # Старые пользователи создавались без статуса — считаем их одобренными
        if "users" in tables:
            conn.execute(text("UPDATE users SET status = 'approved' WHERE status IS NULL"))


def run() -> None:
    """Точка входа: вызывается при старте сервера (main.lifespan) ДО create_all."""
    added = add_missing_columns()
    if "users.identity_status" in added:
        # Пользователи, зарегистрированные ДО появления проверки личности, не должны внезапно
        # потерять доступ: помечаем их как проверенных «по старым правилам» (legacy).
        with engine.begin() as conn:
            conn.execute(text("UPDATE users SET identity_status = 'verified', identity_source = 'legacy'"))
    migrate_legacy_plaintext()
    Base.metadata.create_all(engine)
    if IS_SQLITE:
        with engine.begin() as conn:
            conn.execute(text("PRAGMA optimize"))
