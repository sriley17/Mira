"""
conftest.py — ОБЩАЯ ПОДГОТОВКА ДЛЯ ТЕСТОВ (pytest)
=================================================
Каждый запуск тестов получает СВОЮ временную базу данных, симулятор выключен
(тесты должны быть предсказуемыми), демо-данные создаются заново.

Запуск (из папки backend/):
    python -m pytest -q
"""
import os
import sys
import tempfile
from pathlib import Path

# Настройки должны быть заданы ДО импорта приложения (get_settings кэширует их при первом вызове)
_tmp = tempfile.mkdtemp(prefix="mira-test-")
os.environ["DATABASE_URL"] = f"sqlite:///{_tmp}/test.db"
os.environ["SIMULATOR_ENABLED"] = "false"
os.environ["WEATHER_ENABLED"] = "false"
os.environ["DEMO_SEED"] = "true"
os.environ["LOGIN_MAX_ATTEMPTS"] = "3"
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402


@pytest.fixture(scope="session")
def client():
    # with — запускает lifespan: миграции + демо-данные
    with TestClient(app) as c:
        yield c


def login(client, email: str, password: str) -> dict:
    r = client.post("/api/auth/login", data={"username": email, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["access_token"]}


@pytest.fixture(scope="session")
def doctor(client):
    return login(client, "doctor@mira.uz", "doctor123")


@pytest.fixture(scope="session")
def patient(client):
    return login(client, "patient@mira.uz", "patient123")
