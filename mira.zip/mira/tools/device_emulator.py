"""Emulates a physical MIRA device pushing readings over HTTP (like an ESP32 would).
Usage: python tools/device_emulator.py <SERIAL> <API_KEY> [--critical]
Serial and key: Portal -> Устройство -> «Ключи для подключения реального устройства».
Set SIMULATOR_ENABLED=false in .env to see only these readings.
"""
import random
import sys
import time

import httpx

API = "http://localhost:8000/api/device/ingest"
serial, key = sys.argv[1], sys.argv[2]
critical = "--critical" in sys.argv

while True:
    reading = {
        "heart_rate": random.gauss(150 if critical else 75, 3), "systolic": random.gauss(185 if critical else 120, 3),
        "diastolic": random.gauss(80, 2), "glucose": random.gauss(5.5, 0.2), "resp_rate": random.gauss(15, 1),
        "spo2": random.gauss(97.5, 0.4), "calories": 0.05, "body_temp": random.gauss(36.6, 0.05),
        "room_temp": random.gauss(23, 0.2), "battery": 87, "lat": 41.3111, "lon": 69.2797,
    }
    r = httpx.post(API, json=reading, headers={"X-Device-Serial": serial, "X-Device-Key": key})
    print(r.status_code, {k: round(v, 1) for k, v in reading.items() if k in ("heart_rate", "systolic")})
    time.sleep(2)
