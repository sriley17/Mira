@echo off
REM MIRA — Medical Intelligent Rehabilitation Assistant — запуск на Windows (нужен Python 3.10+)
REM 1) Останавливаем СТАРЫЕ копии сервера на портах 8000 и 8501. Иначе новый сервер не сможет
REM    занять порт, а в браузере будет работать старая версия (ошибки «Not Found»).
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":8000 " ^| findstr LISTENING') do taskkill /F /PID %%a >nul 2>&1
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":8501 " ^| findstr LISTENING') do taskkill /F /PID %%a >nul 2>&1
REM 2) Устанавливаем зависимости и запускаем backend (API) и frontend (интерфейс) в отдельных окнах
python -m pip install -r backend\requirements.txt -r frontend\requirements.txt
start "MIRA API" cmd /k "cd backend && python -m uvicorn app.main:app --port 8000"
timeout /t 6 >nul
start "MIRA UI" cmd /k "cd frontend && python -m streamlit run app.py"
